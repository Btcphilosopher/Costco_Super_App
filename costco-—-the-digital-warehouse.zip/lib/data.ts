// COSTCO — THE DIGITAL WAREHOUSE — DATASET COSTCO-DESIGN-DEMO-001

export interface Product {
  id: string;
  name: string;
  brand: string;
  description: string;
  packSize: string;
  unitQuantity: string;
  memberPrice: number;
  previousPrice?: number;
  savings?: number;
  rating: number;
  reviewsCount: number;
  availability: 'IN STOCK' | 'LOW STOCK' | 'OUT OF STOCK';
  deliveryIndicator: string;
  warehouseAvailability: boolean;
  warehouseAisle: string;
  category: string;
  isKirkland: boolean;
  isTreasureHunt: boolean;
  image: string;
  specs: Record<string, string>;
  warranty?: string;
  deliveryDetails?: string;
}

export interface MembershipTier {
  id: string;
  name: string;
  price: string;
  period: string;
  subTitle: string;
  features: string[];
  rewardPercentage?: string;
  badge: string;
  bgColor: string;
  textColor: string;
  borderColor: string;
}

export interface Warehouse {
  id: string;
  name: string;
  number: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
  distance?: string;
  hours: {
    weekdays: string;
    saturday: string;
    sunday: string;
  };
  services: {
    gasStation: boolean;
    pharmacy: boolean;
    optical: boolean;
    hearingAids: boolean;
    foodCourt: boolean;
    tireCenter: boolean;
  };
}

export interface FoodCourtItem {
  id: string;
  name: string;
  price: number;
  calories: string;
  description: string;
  image: string;
}

export interface TravelPackage {
  id: string;
  destination: string;
  title: string;
  description: string;
  duration: string;
  price: number;
  savingNotes: string;
  image: string;
  includes: string[];
}

export interface CostcoService {
  id: string;
  name: string;
  shortDescription: string;
  longDescription: string;
  benefits: string[];
  ctaText: string;
}

export const MEMBERSHIP_TIERS: MembershipTier[] = [
  {
    id: 'gold-star',
    name: 'Gold Star',
    price: '$65',
    period: 'Annual fee',
    subTitle: 'Shop at all Costco locations worldwide and online.',
    features: [
      'Two Membership Cards included (one for Primary, one for spouse/household)',
      'Shop at Costco warehouses worldwide',
      'Access to Costco.com online shopping',
      'Purchase Costco Travel packages',
      'Access to Costco Optical, Hearing Aid, and Pharmacy services',
      'Exclusive member-only instant savings'
    ],
    badge: 'Standard',
    bgColor: 'bg-white',
    textColor: 'text-slate-900',
    borderColor: 'border-slate-300'
  },
  {
    id: 'executive',
    name: 'Executive',
    price: '$130',
    period: 'Annual fee ($65 membership + $65 upgrade)',
    subTitle: 'Our most premium tier with maximum value and rewards.',
    features: [
      'Annual 2% Reward on qualified Costco purchases (up to $1,250)',
      'Two premium-design Membership Cards',
      'Greater savings on Costco Services (Auto Insurance, Pet, Payment Processing)',
      'Extra benefits on select Costco Travel packages',
      'Exclusive Executive-only promotional mailers',
      'Shop at Costco warehouses worldwide and online',
      'Priority access and expert advice'
    ],
    rewardPercentage: '2%',
    badge: 'Most Popular',
    bgColor: 'bg-slate-900',
    textColor: 'text-white',
    borderColor: 'border-yellow-600'
  },
  {
    id: 'business',
    name: 'Business',
    price: '$65',
    period: 'Annual fee',
    subTitle: 'For business owners to purchase for resale or business use.',
    features: [
      'Two Business Cards included',
      'Purchase for resale (must provide resale certificate)',
      'Add additional Affiliate Members for $65 each',
      'Shop at Costco warehouses worldwide and online',
      'Access to Costco Business Centers and wholesale delivery',
      'Business-friendly payment and tax exemption support'
    ],
    badge: 'Commercial',
    bgColor: 'bg-slate-100',
    textColor: 'text-slate-800',
    borderColor: 'border-slate-400'
  }
];

export const PRODUCTS: Product[] = [
  {
    id: '1',
    brand: 'KIRKLAND SIGNATURE',
    name: 'Organic Extra Virgin Olive Oil',
    description: 'First cold-pressed extra virgin olive oil of exceptional purity. Certified organic. Sourced from cold-pressed Mediterranean olives to deliver a smooth, buttery texture with a peppery finish.',
    packSize: '2 × 1 L',
    unitQuantity: '2 Bottles',
    memberPrice: 24.99,
    previousPrice: 29.99,
    savings: 5.00,
    rating: 4.8,
    reviewsCount: 1420,
    availability: 'IN STOCK',
    deliveryIndicator: '2-Day Delivery available',
    warehouseAvailability: true,
    warehouseAisle: 'Aisle 14 · Grocery Pantry',
    category: 'Grocery',
    isKirkland: true,
    isTreasureHunt: false,
    image: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=600&auto=format&fit=crop&q=60', // Sourced or simulated with beautiful styling
    specs: {
      'Volume': '2 Liters (total)',
      'Origin': 'Mediterranean (Spain, Italy, Greece)',
      'Extraction Method': 'Cold pressed, first extraction',
      'Certifications': 'USDA Organic, Non-GMO'
    },
    warranty: 'Costco 100% Satisfaction Guarantee',
    deliveryDetails: 'Shipped in heavy-duty protective packaging. Standard 2-day delivery.'
  },
  {
    id: '2',
    brand: 'KIRKLAND SIGNATURE',
    name: 'Colombian Supreme Coffee Beans',
    description: '100% Arabica whole bean coffee. Medium-dark roast with a rich, full-bodied flavour and a balanced finish. Sourced directly from premier Colombian coffee cooperatives.',
    packSize: '1.36 kg',
    unitQuantity: '3 lbs bag',
    memberPrice: 18.99,
    previousPrice: 21.99,
    savings: 3.00,
    rating: 4.9,
    reviewsCount: 948,
    availability: 'IN STOCK',
    deliveryIndicator: '2-Day Delivery available',
    warehouseAvailability: true,
    warehouseAisle: 'Aisle 12 · Coffee & Tea',
    category: 'Grocery',
    isKirkland: true,
    isTreasureHunt: false,
    image: 'https://images.unsplash.com/photo-1559056199-641a0ac8b55e?w=600&auto=format&fit=crop&q=60',
    specs: {
      'Roast': 'Medium-Dark (Supreme)',
      'Bean Type': '100% Arabica Colombian',
      'Weight': '1.36 kg (3 lbs)',
      'Grind Type': 'Whole Bean'
    },
    warranty: 'Costco 100% Satisfaction Guarantee'
  },
  {
    id: '3',
    brand: 'KIRKLAND SIGNATURE',
    name: 'Premium Ultra-Soft Bath Tissue',
    description: 'Our signature double-ply bath tissue. Engineered with premium soft-weave fibers for superior strength, absorbency, and comfort. Biodegradable and septic safe.',
    packSize: '30 Rolls · 380 Sheets per roll',
    unitQuantity: '30 Rolls Pack',
    memberPrice: 22.99,
    rating: 4.7,
    reviewsCount: 4210,
    availability: 'IN STOCK',
    deliveryIndicator: 'Standard Shipping',
    warehouseAvailability: true,
    warehouseAisle: 'Aisle 4 · Paper Goods',
    category: 'Home & Household',
    isKirkland: true,
    isTreasureHunt: false,
    image: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?w=600&auto=format&fit=crop&q=60',
    specs: {
      'Ply': '2-Ply Soft Weave',
      'Total Rolls': '30 Rolls',
      'Sheets per Roll': '380 Sheets',
      'Septic Safe': 'Yes, 100% Biodegradable'
    },
    warranty: 'Costco 100% Satisfaction Guarantee'
  },
  {
    id: '4',
    brand: 'LG',
    name: '65" Class OLED C4 Series 4K Smart TV',
    description: 'Experience pure black and infinite contrast with self-lit OLED pixels. Powered by the α9 AI Processor Gen7 for unmatched clarity, 144Hz refresh rate, and advanced webOS smart system.',
    packSize: 'Each',
    unitQuantity: '1 Unit',
    memberPrice: 1499.99,
    previousPrice: 1799.99,
    savings: 300.00,
    rating: 4.9,
    reviewsCount: 312,
    availability: 'IN STOCK',
    deliveryIndicator: 'Free Delivery & Setup available',
    warehouseAvailability: true,
    warehouseAisle: 'Aisle 1 · Electronics',
    category: 'Electronics',
    isKirkland: false,
    isTreasureHunt: false,
    image: 'https://images.unsplash.com/photo-1593305841991-05c297ba4575?w=600&auto=format&fit=crop&q=60',
    specs: {
      'Screen Size': '64.5 inches',
      'Display Type': 'OLED (Self-lit Pixels)',
      'Resolution': '4K UHD (3,840 x 2,160)',
      'Refresh Rate': '144Hz (G-Sync & FreeSync Compatible)',
      'HDMI Ports': '4 x HDMI 2.1'
    },
    warranty: 'Costco Concierge 2-Year Warranty included',
    deliveryDetails: 'Includes White Glove Delivery, unboxing, and basic setup. Returns within 90 days.'
  },
  {
    id: '5',
    brand: 'APPLE',
    name: 'MacBook Air 13" (M3 Chip, 16GB, 512GB SSD)',
    description: 'The superlight, supercharged MacBook Air with Apple M3 chip. Built for work, play, and incredible multitasking. Up to 18 hours of battery life with silent, fanless operation.',
    packSize: 'Each',
    unitQuantity: '1 Unit',
    memberPrice: 899.99,
    previousPrice: 999.99,
    savings: 100.00,
    rating: 4.8,
    reviewsCount: 189,
    availability: 'LOW STOCK',
    deliveryIndicator: 'Express Delivery available',
    warehouseAvailability: false,
    warehouseAisle: 'Aisle 2 · Computers',
    category: 'Electronics',
    isKirkland: false,
    isTreasureHunt: false,
    image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=600&auto=format&fit=crop&q=60',
    specs: {
      'Processor': 'Apple M3 (8-core CPU, 10-core GPU)',
      'Memory': '16GB Unified RAM',
      'Storage': '512GB Ultra-Fast SSD',
      'Battery Life': 'Up to 18 Hours',
      'Color': 'Space Gray'
    },
    warranty: 'Costco Concierge 2-Year Technical Support & Warranty'
  },
  {
    id: '6',
    brand: 'KIRKLAND SIGNATURE',
    name: "Men's Premium Pima Cotton Tee",
    description: 'Woven with extra-long staple Pima cotton for premium softness, durability, and color retention. Classic crew neck styling with reinforced double-stitched seams.',
    packSize: '3-Pack',
    unitQuantity: '3 Shirts',
    memberPrice: 16.99,
    rating: 4.5,
    reviewsCount: 532,
    availability: 'IN STOCK',
    deliveryIndicator: 'Standard Shipping',
    warehouseAvailability: true,
    warehouseAisle: 'Center Court · Apparel',
    category: 'Apparel',
    isKirkland: true,
    isTreasureHunt: false,
    image: 'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=600&auto=format&fit=crop&q=60',
    specs: {
      'Material': '100% Premium Pima Cotton',
      'Package Qty': '3 Crewneck Tees',
      'Care': 'Machine wash cold, tumble dry low'
    },
    warranty: 'Costco 100% Satisfaction Guarantee'
  },
  {
    id: '7',
    brand: 'LA PAVONI',
    name: 'Professional Lever Stainless Espresso Machine',
    description: 'An unexpected, artisanal masterpiece. Designed for espresso purists. This chrome-finished level-piston espresso maker lets you authoritative-control the extraction speed to pull the ultimate shot.',
    packSize: 'Each',
    unitQuantity: '1 Unit',
    memberPrice: 599.99,
    previousPrice: 749.99,
    savings: 150.00,
    rating: 4.7,
    reviewsCount: 64,
    availability: 'LOW STOCK',
    deliveryIndicator: 'Treasure Hunt Exclusive',
    warehouseAvailability: true,
    warehouseAisle: 'Treasure Row · Endcap 3',
    category: 'Treasure Hunt',
    isKirkland: false,
    isTreasureHunt: true,
    image: 'https://images.unsplash.com/photo-1517142089942-ba376ce32a2e?w=600&auto=format&fit=crop&q=60',
    specs: {
      'Boiler Capacity': '1.6 Liters (16 Cups)',
      'Steam Delivery': '10 minutes continuous',
      'Material': 'Solid Brass & Chrome-Plated Stainless Steel',
      'Made In': 'Milan, Italy'
    },
    warranty: 'Manufacturer 3-Year Limited Warranty'
  },
  {
    id: '8',
    brand: 'KIRKLAND SIGNATURE',
    name: 'Luxury Handcrafted Leather Duffle',
    description: 'Woven and stitched by multi-generational leather artisans in Florence. Made from 100% full-grain Italian calfskin leather that will develop a gorgeous patina over time. Solid brass hardware.',
    packSize: 'Each',
    unitQuantity: '1 Bag',
    memberPrice: 129.99,
    rating: 4.9,
    reviewsCount: 114,
    availability: 'LOW STOCK',
    deliveryIndicator: 'Treasure Hunt Exclusive',
    warehouseAvailability: true,
    warehouseAisle: 'Treasure Row · Endcap 5',
    category: 'Treasure Hunt',
    isKirkland: true,
    isTreasureHunt: true,
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=600&auto=format&fit=crop&q=60',
    specs: {
      'Material': '100% Full-grain Italian Calfskin Leather',
      'Hardware': 'Genuine Burnished Solid Brass',
      'Dimensions': '22" L x 11" W x 12" H',
      'Weight': '4.2 lbs'
    },
    warranty: 'Costco 100% Satisfaction Guarantee'
  },
  {
    id: '9',
    brand: 'OUTDOOR LIVING',
    name: 'Enormous 7-Piece Outdoor Modular Sectional Set',
    description: 'High-end comfort for large gatherings. Hand-woven all-weather resin wicker wrapped around heavy-duty rust-free aluminum frames. Premium Sunbrella cushions resistant to stains, mold, and UV fading.',
    packSize: '7-Piece Set',
    unitQuantity: '7 Pieces',
    memberPrice: 1899.99,
    previousPrice: 2399.99,
    savings: 500.00,
    rating: 4.6,
    reviewsCount: 82,
    availability: 'IN STOCK',
    deliveryIndicator: 'Freight Delivery included',
    warehouseAvailability: false,
    warehouseAisle: 'Outdoor Court · Seasonal',
    category: 'Outdoor & Patio',
    isKirkland: false,
    isTreasureHunt: true,
    image: 'https://images.unsplash.com/photo-1600210492486-724fe5c67fb0?w=600&auto=format&fit=crop&q=60',
    specs: {
      'Fabric': 'Sunbrella® Premium performance fabric',
      'Frame Material': 'Powder-coated rust-proof aluminum',
      'Included': '4 Sectional Armless Chairs, 2 Corner Chairs, 1 Fire Pit Table',
      'Wicker': 'Hand-woven multi-toned gray polyethylene wicker'
    },
    warranty: 'Sunbrella Fabric 5-Year Limited Warranty, Frame 2-Year Warranty'
  },
  {
    id: '10',
    brand: 'KIRKLAND SIGNATURE',
    name: 'Super Premium Dog Food · Chicken, Rice & Vegetable',
    description: 'Formulated with fresh chicken as the primary ingredient to support lean muscle development. Enriched with active probiotics for sound digestive health, and Omega fatty acids for a glossy coat.',
    packSize: '18.1 kg',
    unitQuantity: '40 lbs bag',
    memberPrice: 45.99,
    rating: 4.8,
    reviewsCount: 2210,
    availability: 'IN STOCK',
    deliveryIndicator: 'Standard Shipping',
    warehouseAvailability: true,
    warehouseAisle: 'Aisle 8 · Pet Supplies',
    category: 'Pet Supplies',
    isKirkland: true,
    isTreasureHunt: false,
    image: 'https://images.unsplash.com/photo-1589722244358-f0ec9c378510?w=600&auto=format&fit=crop&q=60',
    specs: {
      'First Ingredient': 'Fresh Chicken (never meal)',
      'Weight': '18.1 kg (40 lbs)',
      'Life Stage': 'Adult Dog formula',
      'Probiotics': 'Active Live Yeast culture'
    },
    warranty: 'Costco 100% Satisfaction Guarantee'
  },
  {
    id: '11',
    brand: 'KIRKLAND SIGNATURE',
    name: 'Daily Multi Vitamins & Minerals',
    description: 'Scientifically balanced nutrition containing 28 essential vitamins and minerals. Formulated specifically to support heart health, immune defense, eye health, and cellular energy production.',
    packSize: '500 Tablets',
    unitQuantity: '500 Count',
    memberPrice: 14.99,
    rating: 4.7,
    reviewsCount: 1045,
    availability: 'IN STOCK',
    deliveryIndicator: '2-Day Delivery available',
    warehouseAvailability: true,
    warehouseAisle: 'Pharmacy Department · Vitamins',
    category: 'Health & Pharmacy',
    isKirkland: true,
    isTreasureHunt: false,
    image: 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=600&auto=format&fit=crop&q=60',
    specs: {
      'Quantity': '500 Tablets',
      'Dosage': '1 tablet daily',
      'USP Verified': 'Yes, USP Dietary Supplement certified',
      'Gluten Free': 'Yes'
    },
    warranty: 'Costco 100% Satisfaction Guarantee'
  },
  {
    id: '12',
    brand: 'KIRKLAND SIGNATURE',
    name: 'Organic Red Quinoa',
    description: '100% organic, whole grain red quinoa. Thoroughly pre-washed and ready to cook. Exceptionally rich in complete plant-based proteins, dietary fibers, and essential amino acids.',
    packSize: '2.04 kg',
    unitQuantity: '4.5 lbs bag',
    memberPrice: 11.49,
    previousPrice: 13.49,
    savings: 2.00,
    rating: 4.6,
    reviewsCount: 654,
    availability: 'IN STOCK',
    deliveryIndicator: '2-Day Delivery available',
    warehouseAvailability: true,
    warehouseAisle: 'Aisle 15 · Organic Pantry',
    category: 'Grocery',
    isKirkland: true,
    isTreasureHunt: false,
    image: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?w=600&auto=format&fit=crop&q=60',
    specs: {
      'Weight': '2.04 kg (4.5 lbs)',
      'Type': 'Organic Pre-Washed Red Quinoa',
      'Dietary': 'Gluten-Free, Vegan, Kosher'
    },
    warranty: 'Costco 100% Satisfaction Guarantee'
  }
];

export const WAREHOUSES: Warehouse[] = [
  {
    id: 'wh-001',
    name: 'Seattle Downtown',
    number: '#001',
    address: '4401 4th Ave S',
    city: 'Seattle',
    state: 'WA',
    zipCode: '98134',
    phone: '(206) 622-1108',
    distance: '1.2 miles',
    hours: {
      weekdays: '10:00 AM - 8:30 PM',
      saturday: '9:30 AM - 6:00 PM',
      sunday: '10:00 AM - 6:00 PM'
    },
    services: {
      gasStation: true,
      pharmacy: true,
      optical: true,
      hearingAids: true,
      foodCourt: true,
      tireCenter: true
    }
  },
  {
    id: 'wh-122',
    name: 'Portland Airport',
    number: '#122',
    address: '4849 NE 138th Ave',
    city: 'Portland',
    state: 'OR',
    zipCode: '97230',
    phone: '(503) 252-2243',
    distance: '8.4 miles',
    hours: {
      weekdays: '10:00 AM - 8:30 PM',
      saturday: '9:30 AM - 6:00 PM',
      sunday: '10:00 AM - 6:00 PM'
    },
    services: {
      gasStation: true,
      pharmacy: true,
      optical: true,
      hearingAids: false,
      foodCourt: true,
      tireCenter: true
    }
  },
  {
    id: 'wh-550',
    name: 'San Francisco SOMA',
    number: '#550',
    address: '450 10th St',
    city: 'San Francisco',
    state: 'CA',
    zipCode: '94103',
    phone: '(415) 626-4470',
    distance: '15.1 miles',
    hours: {
      weekdays: '9:00 AM - 8:30 PM',
      saturday: '9:00 AM - 7:00 PM',
      sunday: '10:00 AM - 6:00 PM'
    },
    services: {
      gasStation: false,
      pharmacy: true,
      optical: true,
      hearingAids: true,
      foodCourt: true,
      tireCenter: true
    }
  }
];

export const FOOD_COURT_ITEMS: FoodCourtItem[] = [
  {
    id: 'fc-1',
    name: '1/4 lb. Plus All-Beef Hot Dog & 20 oz. Drink',
    price: 1.50,
    calories: '580-850 Cal',
    description: 'The legendary Costco hot dog combo. A 100% kosher-style all-beef hot dog served in a warm sesame bun with an ice-cold 20 oz. soda (includes free refills). Price unchanged since 1985.',
    image: 'https://images.unsplash.com/photo-1541232972175-34191b65313d?w=300&auto=format&fit=crop&q=60'
  },
  {
    id: 'fc-2',
    name: 'Whole 18" Freshly Baked Pizza',
    price: 9.95,
    calories: '3800-4200 Cal',
    description: 'Gigantic, hand-stretched 18-inch pizza baked fresh in our high-temperature ovens. Choose between classic Cheese, Pepperoni, or half-and-half.',
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?w=300&auto=format&fit=crop&q=60'
  },
  {
    id: 'fc-3',
    name: 'Individual Pizza Slice (Cheese or Pepperoni)',
    price: 1.95,
    calories: '650-710 Cal',
    description: 'An enormous slice of our freshly baked 18" warehouse pizza.',
    image: 'https://images.unsplash.com/photo-1534308983496-4fabb1a015ee?w=300&auto=format&fit=crop&q=60'
  },
  {
    id: 'fc-4',
    name: 'Baked Chicken Bake',
    price: 3.99,
    calories: '770 Cal',
    description: 'Savory bread dough filled with white breast chicken meat, crumbled bacon, melted mozzarella, provolone, and creamy Caesar dressing, baked to golden perfection.',
    image: 'https://images.unsplash.com/photo-1619535860434-ba1d8fa12536?w=300&auto=format&fit=crop&q=60'
  },
  {
    id: 'fc-5',
    name: 'Double Chocolate Chunk Cookie',
    price: 2.49,
    calories: '750 Cal',
    description: 'Baked fresh daily in the warehouse bakery, served warm with rich, gooey double chocolate chunks.',
    image: 'https://images.unsplash.com/photo-1499636136210-6f4ee915583e?w=300&auto=format&fit=crop&q=60'
  }
];

export const TRAVEL_PACKAGES: TravelPackage[] = [
  {
    id: 'tr-01',
    destination: 'EUROPE',
    title: 'Rome, Florence & Venice Courier',
    description: 'Embark on an iconic, curated tour of Italy. Travel seamlessly between cities via high-speed rail with luxury hotel stays, guided Vatican tours, and a private gondola ride included.',
    duration: '9 Nights with First Class Rail',
    price: 2199.00,
    savingNotes: 'Executive members earn a $200 Costco Shop Card on this package.',
    image: 'https://images.unsplash.com/photo-1529260830199-4458210214c6?w=600&auto=format&fit=crop&q=60',
    includes: [
      'Luxury hotel accommodations (3 nights per city)',
      'First-Class high-speed train tickets between cities',
      'Daily authentic hot Italian buffet breakfast',
      'Skip-the-line Vatican & Colosseum private tours',
      'Costco member-exclusive travel assistance hotline'
    ]
  },
  {
    id: 'tr-02',
    destination: 'CARIBBEAN',
    title: 'Riviera Maya All-Inclusive Retreat',
    description: 'An expansive family sanctuary in Riviera Maya. Immerse yourself in five-star beachfront luxury. Unlimited fine dining, private beach club access, and non-motorized water sports included.',
    duration: '5 Nights All-Inclusive with Flights',
    price: 1349.00,
    savingNotes: 'Costco member rates save up to $450 compared to public booking.',
    image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?w=600&auto=format&fit=crop&q=60',
    includes: [
      'Round-trip airfare from major hubs',
      'All meals, premium snacks, and beverages',
      'Private round-trip airport transfers',
      'Kids Club & family activity programming',
      'Complementary $100 spa credit per room'
    ]
  },
  {
    id: 'tr-03',
    destination: 'HAWAII',
    title: 'Maui Oceanfront Luxury Escape',
    description: 'Bask in the tropical splendor of Wailea beach. Stay at an exceptional oceanfront resort. Includes a rental SUV, standard valet parking, and daily resort fee waivers.',
    duration: '6 Nights with Full Size SUV',
    price: 1899.00,
    savingNotes: 'Includes $150 resort credit and guaranteed room upgrade.',
    image: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e?w=600&auto=format&fit=crop&q=60',
    includes: [
      'Partial Ocean View room (upgraded)',
      '6-day full-size SUV rental from Alamo',
      'Resort fee and daily valet parking fully covered',
      'Sunset Catamaran Sail tour with dinner',
      '2% Executive Reward applicable'
    ]
  }
];

export const SERVICES_DIRECTORY: CostcoService[] = [
  {
    id: 'srv-1',
    name: 'Costco Auto Program',
    shortDescription: 'Pre-arranged low pricing on brand new and certified pre-owned vehicles.',
    longDescription: 'Take the stress out of car shopping. We negotiate with certified partner dealerships to secure an exceptional, pre-arranged discount for Costco members on cars, trucks, RVs, and powersports.',
    benefits: [
      'Pre-arranged Costco member pricing (save thousands)',
      '15% discount on parts, service, and apparel at participating dealers',
      'Dedicated member advocacy team to support your buying process',
      'Zero-haggle, low-stress dealership experience'
    ],
    ctaText: 'Find Your Next Vehicle'
  },
  {
    id: 'srv-2',
    name: 'Costco Pharmacy',
    shortDescription: 'Value on prescription medications, flu shots, and pet prescriptions.',
    longDescription: 'Get premium savings on your health. Costco Pharmacies offer transparent pricing, reliable prescription fulfillment, online mail-order services, and easy walk-in immunization clinics for flu and travel.',
    benefits: [
      'Major discounts on generic and brand-name prescriptions',
      'Costco Member Prescription Program (CMPP) for uninsured savings',
      'Convenient, free home delivery with online prescription management',
      'Pet medications at traditional low warehouse pricing'
    ],
    ctaText: 'Transfer & Refill Prescriptions'
  },
  {
    id: 'srv-3',
    name: 'Costco Optical Center',
    shortDescription: 'Comprehensive eye exams, designer frames, and high-tech lenses.',
    longDescription: 'See the value clearly. Visit our in-warehouse optical centers for fully licensed optometrists, precision eye examinations, and an extraordinary selection of designer frames, contacts, and custom lenses.',
    benefits: [
      'Comprehensive eye examinations with state-of-the-art diagnostic equipment',
      'Extremely affordable designer and everyday prescription frames',
      'Premium digital progressive and anti-reflective lenses at a fraction of retail',
      'All major brands of contact lenses in bulk packs'
    ],
    ctaText: 'Schedule Eye Exam'
  },
  {
    id: 'srv-4',
    name: 'Costco Tire Center',
    shortDescription: 'Unbeatable value on Michelin, Bridgestone, and Pirelli tires.',
    longDescription: 'Drive with total confidence. Purchase tires from our curated warehouse inventory. Installation fees include lifetime balancing, pressure checks, nitrogen inflation, and flat repairs at no extra cost.',
    benefits: [
      'Exclusive manufacturer rebates (up to $150 off a set of 4)',
      'Free lifetime maintenance (rotation, balancing, flat repairs, air pressure)',
      'Nitrogen inflation (holds pressure longer, extends tire life) included free',
      'Industry-leading Road Hazard Warranty'
    ],
    ctaText: 'Search Tires By Vehicle'
  }
];

// Kirkland Signature Editorial Stories
export const KIRKLAND_STORIES = [
  {
    title: 'THE RULE OF EQUALITY OR BETTER',
    subtitle: 'Inside Costco’s Private Label Standard',
    content: `To become Kirkland Signature, a product must meet a strict, uncompromising standard: it must be equal to or better in quality than the leading national brand in its category, while being offered at a significantly lower price.

If we cannot build a product that matches or beats the brand leader, we simply won't put our name on it. This single rule is why members trust Kirkland Signature implicitly.`
  },
  {
    title: 'THE STORY OF MEDITERRANEAN OLIVE OIL',
    subtitle: 'From Olive Grove to Warehouse Shelf',
    content: `For our Kirkland Signature Organic Extra Virgin Olive Oil, we work directly with multi-generational agricultural cooperatives in Spain, Italy, and Greece. 

By managing our own logistics—employing high-volume container shipping, avoiding traditional middlemen, and utilizing minimalist container designs—we reduce retail markup by up to 40% while preserving authentic, cold-pressed quality.`
  },
  {
    title: 'COFFEE WITH AN IMPACT',
    subtitle: 'Colombian cooperatives and fair pricing',
    content: `We purchase our Colombian Supreme Arabica beans directly from smallholders and cooperatives. 

By paying a guaranteed premium above market rates, we support localized community infrastructure (water, education, farming equipment) while securing first-selection priority on the absolute finest premium beans harvested each season.`
  }
];
