'use client';

import React from 'react';
import { Product, MEMBERSHIP_TIERS } from '@/lib/data';
import { CreditCard, History, Clock, Award, Bookmark, ArrowRight, ShieldAlert, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AccountSectionProps {
  orders: {
    id: string;
    date: string;
    items: { name: string; quantity: number; price: number }[];
    total: number;
    status: 'PLACED' | 'CONFIRMED' | 'PROCESSING' | 'PICKED' | 'PACKED' | 'SHIPPED' | 'OUT FOR DELIVERY' | 'DELIVERED';
    type: 'ONLINE' | 'FOOD_COURT';
  }[];
  appointments: {
    serviceName: string;
    date: string;
    time: string;
    warehouseName: string;
  }[];
  activeCategory: string;
  onNavigateToShop: () => void;
}

export default function AccountSection({
  orders,
  appointments,
  onNavigateToShop,
}: AccountSectionProps) {
  
  // Calculate total Executive Rewards mock calculation
  const totalSpend = orders
    .filter(o => o.type === 'ONLINE')
    .reduce((sum, o) => sum + o.total, 0);
  const rewardEarned = totalSpend * 0.02;

  // Let's create a beautiful, structured Membership Card widget
  const mockCardNumber = "WHS-104-928-301";
  
  return (
    <div className="bg-[#F2F2F2] py-14 px-6 border-b border-slate-200 text-left">
      <div className="max-w-7xl mx-auto">
        
        {/* Title / Description */}
        <div className="border-b border-slate-300 pb-4 mb-10">
          <span className="text-xs font-black uppercase tracking-widest text-slate-500 block mb-1">
            Institutional Customer Portal
          </span>
          <h2 className="text-3xl font-black uppercase tracking-tight text-slate-900">
            MY COSTCO DASHBOARD
          </h2>
          <p className="text-slate-500 text-xs mt-1">
            Access your membership cards, active order states, appointment schedules, and 2% Reward accumulations.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left Column: Membership Card & Rewards */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            
            {/* Visual Membership Card */}
            <div className="bg-slate-950 text-white p-6 border-l-8 border-yellow-600 shadow-xl relative overflow-hidden flex flex-col justify-between aspect-[1.6/1]">
              {/* Card Background Branding */}
              <div className="absolute top-0 right-0 w-44 h-44 bg-yellow-600/10 rounded-full blur-2xl pointer-events-none" />
              
              <div className="flex justify-between items-start">
                <div>
                  <span className="text-[10px] font-black uppercase text-yellow-600 tracking-widest block">
                    Executive Membership Card
                  </span>
                  <span className="text-xl font-serif font-black uppercase text-white mt-1 block">
                    COSTCO
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[9px] font-bold text-slate-400 uppercase tracking-wider block">
                    Validated Status
                  </span>
                  <span className="text-xs font-bold text-green-400 font-mono">
                    ✓ ACTIVE
                  </span>
                </div>
              </div>

              <div className="mt-8">
                <span className="text-[10px] text-slate-500 font-bold uppercase block tracking-wider">
                  Member Number
                </span>
                <span className="text-base font-mono font-bold text-white tracking-widest">
                  {mockCardNumber}
                </span>
              </div>

              <div className="border-t border-slate-800/80 pt-4 flex justify-between items-end">
                <div>
                  <span className="text-[9px] text-slate-500 font-bold uppercase block tracking-wider">
                    Primary Cardholder
                  </span>
                  <span className="text-xs font-bold text-white uppercase font-sans">
                    Tom Costco Member
                  </span>
                </div>
                <div className="text-right">
                  <span className="text-[9px] text-slate-400 font-bold uppercase block tracking-wider">
                    Renews Date
                  </span>
                  <span className="text-xs font-semibold text-slate-200 font-mono">
                    10/2027
                  </span>
                </div>
              </div>
            </div>

            {/* Executive Rewards tracker widget */}
            <div className="bg-white border border-slate-300 p-6 shadow-sm">
              <div className="flex items-start gap-3">
                <Award className="w-8 h-8 text-yellow-600 shrink-0 mt-1" />
                <div className="text-left">
                  <h3 className="text-sm font-black uppercase text-slate-900 tracking-tight">
                    2% EXECUTIVE REWARDS ACCUMULATION
                  </h3>
                  <p className="text-[11px] text-slate-500 leading-normal mt-0.5">
                    Accumulated on qualified pre-tax purchases. Certificates are mailed prior to your renewal.
                  </p>
                </div>
              </div>

              <div className="bg-slate-50 border border-slate-200 p-4 rounded-none text-center mt-4">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">
                  Active Reward Balance
                </span>
                <span className="text-3xl font-black font-mono text-slate-900 mt-1 block">
                  ${rewardEarned.toFixed(2)}
                </span>
                <span className="text-[10px] text-slate-500 font-medium block mt-1">
                  Based on ${totalSpend.toFixed(2)} online/warehouse qualifying purchases.
                </span>
              </div>
            </div>

          </div>

          {/* Right Column: Active Tracker & Appointment schedule */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            
            {/* Active Appointments schedule */}
            <div className="bg-white border border-slate-300 p-6 shadow-sm text-left">
              <h3 className="text-sm font-black uppercase text-slate-900 tracking-tight mb-4 flex items-center gap-2">
                <Clock className="w-4.5 h-4.5 text-[#005691]" />
                UPCOMING WAREHOUSE APPOINTMENTS ({appointments.length})
              </h3>

              {appointments.length === 0 ? (
                <div className="text-center py-6 text-slate-400 text-xs">
                  No active optical, auto, or pharmacy sessions scheduled. Use our Services tab to secure a slot.
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  {appointments.map((appt, idx) => (
                    <div key={idx} className="bg-slate-50 border border-slate-200 p-4 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 text-xs">
                      <div>
                        <strong className="text-sm font-extrabold text-slate-900 uppercase">
                          {appt.serviceName}
                        </strong>
                        <p className="text-slate-500 text-xs mt-0.5">
                          Location: <span className="text-slate-800 font-semibold">{appt.warehouseName} Warehouse</span>
                        </p>
                      </div>

                      <div className="flex gap-4 items-center font-mono">
                        <div className="bg-white border border-slate-300 px-3 py-1 text-center min-w-[100px]">
                          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">DATE</span>
                          <span className="text-slate-900 font-bold">{appt.date}</span>
                        </div>
                        <div className="bg-white border border-slate-300 px-3 py-1 text-center min-w-[100px]">
                          <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest block">TIME</span>
                          <span className="text-slate-900 font-bold">{appt.time}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Active Orders Tracker */}
            <div className="bg-white border border-slate-300 p-6 shadow-sm text-left">
              <h3 className="text-sm font-black uppercase text-slate-900 tracking-tight mb-4 flex items-center gap-2">
                <History className="w-4.5 h-4.5 text-[#E31B23]" />
                ACTIVE WAREHOUSE ORDERS ({orders.length})
              </h3>

              {orders.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-xs">
                  You have no placed orders. Browse our catalog and fill your pallet!
                  <button
                    onClick={onNavigateToShop}
                    className="text-[#005691] hover:underline font-bold block mx-auto mt-2 cursor-pointer"
                  >
                    Go Shop Pallets →
                  </button>
                </div>
              ) : (
                <div className="flex flex-col gap-6">
                  {orders.map((order) => {
                    
                    // State pipeline list
                    const states = ['PLACED', 'CONFIRMED', 'PROCESSING', 'PICKED', 'PACKED', 'SHIPPED', 'OUT FOR DELIVERY', 'DELIVERED'];
                    const activeIndex = states.indexOf(order.status);
                    
                    return (
                      <div key={order.id} className="border border-slate-200 p-6 bg-slate-50/50">
                        
                        {/* Order info summary */}
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-slate-200 pb-3 mb-4">
                          <div>
                            <strong className="text-slate-900 font-bold text-sm uppercase">
                              Order #{order.id} ({order.type === 'ONLINE' ? 'ONLINE SHIPMENT' : 'FOOD COURT PICKUP'})
                            </strong>
                            <p className="text-slate-500 text-xs font-mono mt-0.5">
                              Placed Date: {order.date}
                            </p>
                          </div>

                          <div className="text-right">
                            <span className="text-xs text-slate-500 uppercase font-semibold">Total Invoice:</span>
                            <strong className="text-sm font-mono font-black text-slate-900 ml-1.5">${order.total.toFixed(2)}</strong>
                          </div>
                        </div>

                        {/* Order item details */}
                        <div className="flex flex-col gap-1.5 mb-6 text-xs text-slate-600">
                          {order.items.map((item, idx) => (
                            <div key={idx} className="flex justify-between font-medium">
                              <span>{item.quantity}x {item.name}</span>
                              <span className="font-mono font-bold text-slate-900">${(item.price * item.quantity).toFixed(2)}</span>
                            </div>
                          ))}
                        </div>

                        {/* Active order pipeline visualizer */}
                        <div className="border-t border-slate-200/80 pt-4">
                          <span className="text-[10px] font-black uppercase text-slate-400 tracking-widest block mb-4 text-center sm:text-left">
                            Fulfilment Dispatch Pipeline
                          </span>

                          <div className="grid grid-cols-4 md:grid-cols-8 gap-2">
                            {states.map((st, sIdx) => {
                              const isCompleted = sIdx <= activeIndex;
                              const isCurrent = sIdx === activeIndex;
                              return (
                                <div key={st} className="flex flex-col items-center">
                                  <div className={cn(
                                    "w-3.5 h-3.5 rounded-full border-2 transition-all duration-300",
                                    isCurrent ? "bg-[#E31B23] border-[#E31B23] scale-110 ring-4 ring-red-200" :
                                    isCompleted ? "bg-[#005691] border-[#005691]" : "bg-white border-slate-300"
                                  )} />
                                  <span className={cn(
                                    "text-[9px] font-bold uppercase tracking-wider text-center mt-1.5 line-clamp-1 leading-none font-mono",
                                    isCurrent ? "text-slate-950 font-black" :
                                    isCompleted ? "text-slate-600" : "text-slate-400"
                                  )}>
                                    {st}
                                  </span>
                                </div>
                              );
                            })}
                          </div>
                        </div>

                      </div>
                    );
                  })}
                </div>
              )}
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
