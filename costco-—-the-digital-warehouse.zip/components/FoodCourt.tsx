'use client';

import React, { useState } from 'react';
import { FOOD_COURT_ITEMS, FoodCourtItem } from '@/lib/data';
import { ShoppingBag, Check, Plus, Minus, Tag, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface FoodCourtProps {
  onPlaceFoodCourtOrder: (items: { name: string; quantity: number; price: number }[], total: number) => void;
}

export default function FoodCourt({ onPlaceFoodCourtOrder }: FoodCourtProps) {
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [ticketNumber, setTicketNumber] = useState<string | null>(null);

  const updateQuantity = (itemId: string, delta: number) => {
    const current = quantities[itemId] || 0;
    const next = Math.max(0, current + delta);
    setQuantities({ ...quantities, [itemId]: next });
  };

  const activeItems = FOOD_COURT_ITEMS.filter(item => (quantities[item.id] || 0) > 0);
  const total = activeItems.reduce((sum, item) => sum + item.price * (quantities[item.id] || 0), 0);

  const handlePlaceOrder = () => {
    if (activeItems.length === 0) return;
    
    const formattedItems = activeItems.map(item => ({
      name: item.name,
      quantity: quantities[item.id],
      price: item.price,
    }));

    onPlaceFoodCourtOrder(formattedItems, total);

    // Generate a beautiful pickup ticket
    const num = Math.floor(Math.random() * 900) + 100;
    setTicketNumber(`FC-${num}`);
    
    // Reset quantities
    setQuantities({});
  };

  return (
    <div className="bg-[#F2F2F2] py-14 px-6 border-b border-slate-200 text-left">
      <div className="max-w-7xl mx-auto">
        
        {/* Title / Hero */}
        <div className="bg-white border border-slate-300 p-8 mb-10 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="text-left">
            <div className="inline-flex items-center gap-1.5 bg-[#E31B23] text-white px-2 py-0.5 text-[9px] font-black uppercase tracking-widest mb-2">
              Unchanged Price Since 1985
            </div>
            <h2 className="text-3xl font-black uppercase tracking-tight text-slate-900 leading-none">
              THE WAREHOUSE FOOD COURT
            </h2>
            <p className="text-slate-500 text-xs mt-1.5 max-w-xl">
              Our food court is a core pillar of Costco culture. By selling high-quality hot dogs and fresh baked pizzas at near-zero margins, we make the warehouse journey rewarding.
            </p>
          </div>

          <div className="bg-[#005691] text-white p-4 shrink-0 text-center flex flex-col justify-center">
            <span className="text-[10px] font-bold text-slate-300 uppercase tracking-widest">
              Hot Dog + Soda Combo Price
            </span>
            <span className="text-2xl font-black font-mono text-white mt-1">
              $1.50
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left column: Menu cards */}
          <div className="lg:col-span-8 flex flex-col gap-4">
            <h3 className="text-sm font-bold uppercase tracking-wider text-slate-400 mb-2">
              Costco Warehouse Menu
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {FOOD_COURT_ITEMS.map((item) => {
                const qty = quantities[item.id] || 0;
                return (
                  <div
                    key={item.id}
                    className="bg-white border border-slate-300 p-6 flex flex-col justify-between hover:shadow-md transition-shadow relative"
                  >
                    <div>
                      {/* Thumbnail photo */}
                      <div className="h-44 w-full bg-slate-50 border border-slate-100 overflow-hidden mb-4 relative">
                        <img
                          src={item.image}
                          alt={item.name}
                          className="w-full h-full object-cover"
                          referrerPolicy="no-referrer"
                        />
                        <div className="absolute top-2 right-2 bg-slate-900/95 text-white font-mono text-xs font-bold px-2 py-0.5 border border-slate-700">
                          ${item.price.toFixed(2)}
                        </div>
                      </div>

                      <h4 className="font-extrabold text-base text-slate-900 uppercase tracking-tight leading-snug">
                        {item.name}
                      </h4>
                      <span className="text-[10px] font-mono font-bold text-slate-400 block mt-1 uppercase">
                        {item.calories}
                      </span>
                      <p className="text-slate-500 text-xs mt-2 leading-relaxed">
                        {item.description}
                      </p>
                    </div>

                    {/* Quantity selectors */}
                    <div className="border-t border-slate-100 pt-4 mt-6 flex justify-between items-center">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                        Configure Quantity
                      </span>
                      
                      <div className="flex items-center gap-3">
                        <button
                          onClick={() => updateQuantity(item.id, -1)}
                          className="w-8 h-8 rounded-full border border-slate-300 flex items-center justify-center hover:bg-slate-100 text-slate-700 text-sm font-bold cursor-pointer"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="font-mono font-extrabold text-sm text-slate-900 w-4 text-center">
                          {qty}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.id, 1)}
                          className="w-8 h-8 rounded-full border border-slate-300 flex items-center justify-center hover:bg-slate-100 text-slate-700 text-sm font-bold cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                  </div>
                );
              })}
            </div>
          </div>

          {/* Right column: Ticket / Active Cart */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            
            {/* Ticket receipt tracker if order placed */}
            {ticketNumber && (
              <div className="bg-white border-2 border-[#E31B23] p-6 text-center shadow-lg relative">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 bg-[#E31B23] text-white text-[9px] font-black uppercase tracking-widest px-4 py-0.5">
                  Counter Ticket
                </div>
                <div className="w-12 h-12 bg-red-50 text-[#E31B23] rounded-full flex items-center justify-center mx-auto mb-3">
                  <Clock className="w-6 h-6" />
                </div>
                <h4 className="font-extrabold text-sm uppercase text-slate-900">ORDER SECURED</h4>
                <div className="text-3xl font-black font-mono text-[#E31B23] my-3">
                  {ticketNumber}
                </div>
                <p className="text-xs text-slate-500 max-w-xs mx-auto leading-relaxed">
                  Please proceed directly to the Food Court pickup counter. Present this ticket screen or recite your code. 
                  <strong className="block text-slate-900 mt-1 uppercase">ESTIMATED PREPARATION TIME: 8 MINS</strong>
                </p>

                <button
                  onClick={() => setTicketNumber(null)}
                  className="mt-4 text-xs font-bold text-[#005691] hover:underline uppercase cursor-pointer"
                >
                  Order Something Else
                </button>
              </div>
            )}

            {/* Simulated order cart */}
            <div className="bg-white border border-slate-300 p-6 shadow-sm flex flex-col justify-between text-left h-full min-h-[300px]">
              <div>
                <h3 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-4 border-b border-slate-100 pb-2">
                  Food Court Express Tray
                </h3>

                {activeItems.length === 0 ? (
                  <div className="text-center py-10 text-slate-400 text-xs">
                    Your tray is empty. Add a legendary $1.50 combo above to secure a ticket.
                  </div>
                ) : (
                  <div className="flex flex-col gap-3 max-h-60 overflow-y-auto">
                    {activeItems.map((item) => {
                      const qty = quantities[item.id];
                      return (
                        <div key={item.id} className="flex justify-between items-center text-xs">
                          <div className="text-slate-800 font-semibold pr-4">
                            <span className="font-mono text-slate-400 font-bold mr-1.5">{qty}x</span>
                            {item.name}
                          </div>
                          <span className="font-mono text-slate-900 font-bold shrink-0">
                            ${(item.price * qty).toFixed(2)}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

              {activeItems.length > 0 && (
                <div className="border-t border-slate-200 pt-4 mt-6">
                  <div className="flex justify-between items-baseline mb-4">
                    <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                      Express Total
                    </span>
                    <span className="text-2xl font-black font-mono text-slate-900">
                      ${total.toFixed(2)}
                    </span>
                  </div>

                  <button
                    onClick={handlePlaceOrder}
                    className="w-full bg-[#E31B23] hover:bg-red-700 text-white font-extrabold uppercase tracking-widest text-xs py-3 text-center cursor-pointer transition-colors"
                  >
                    Place Express Pickup Order
                  </button>
                  <p className="text-center text-[9px] text-slate-400 mt-2 font-medium">
                    No payment details required here. Settle at checkout counters during pickup.
                  </p>
                </div>
              )}
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
