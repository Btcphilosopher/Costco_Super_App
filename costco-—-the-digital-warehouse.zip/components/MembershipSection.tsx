'use client';

import React from 'react';
import { MEMBERSHIP_TIERS, MembershipTier } from '@/lib/data';
import { ShieldCheck, HelpCircle, CheckCircle, Award, CreditCard, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

interface MembershipSectionProps {
  onJoinTier: (tier: MembershipTier) => void;
}

export default function MembershipSection({ onJoinTier }: MembershipSectionProps) {
  return (
    <div className="bg-[#F2F2F2] py-14 px-6 border-b border-slate-200 text-left">
      <div className="max-w-7xl mx-auto">
        
        {/* Title Block */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-black uppercase tracking-widest text-[#005691] block mb-2">
            The Foundation of Our Value Model
          </span>
          <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tight text-slate-900 mb-4">
            COSTCO MEMBERSHIP
          </h2>
          <p className="text-slate-600 text-sm md:text-base text-wrap-balance">
            We are a members-only warehouse. By operating a membership model, we offset traditional retail overheads to procure merchandise in bulk quantities at the lowest margins.
          </p>
        </div>

        {/* Highlight Executive Value Callout banner */}
        <div className="bg-white border-2 border-yellow-600 p-8 mb-12 flex flex-col lg:flex-row items-center justify-between gap-6 shadow-md relative overflow-hidden">
          <div className="absolute top-0 right-0 bg-yellow-600 text-white text-[9px] font-black uppercase tracking-widest px-4 py-1">
            Institutional Standard
          </div>
          <div className="flex items-start gap-4">
            <Award className="w-12 h-12 text-yellow-600 shrink-0 mt-1" />
            <div>
              <h3 className="text-xl font-extrabold uppercase text-slate-900 tracking-tight">
                THE 2% REWARD ADVANTAGE
              </h3>
              <p className="text-slate-600 text-xs md:text-sm max-w-xl mt-1 leading-relaxed">
                As an Executive Member, you earn a 2% Annual Reward on qualified Costco purchases worldwide and online. If you spend $250 a month at Costco, your upgrade is fully paid for. Anything more is pure cash returned straight to you.
              </p>
            </div>
          </div>
          
          <div className="bg-slate-50 border border-slate-200 p-4 shrink-0 text-center flex flex-col justify-center">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-widest">
              Maximum Executive Reward Limit
            </span>
            <span className="text-2xl font-black font-mono text-slate-900 mt-1">
              $1,250 / year
            </span>
          </div>
        </div>

        {/* Tiers Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch mb-14">
          {MEMBERSHIP_TIERS.map((tier) => {
            const isExecutive = tier.id === 'executive';
            return (
              <div
                key={tier.id}
                className={cn(
                  "bg-white border p-8 flex flex-col justify-between h-full shadow-sm relative transition-all",
                  isExecutive ? "border-yellow-600 shadow-lg scale-102 ring-1 ring-yellow-600/30" : "border-slate-300"
                )}
              >
                {isExecutive && (
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-yellow-600 text-white px-4 py-0.5 text-[9px] font-black uppercase tracking-widest">
                    Recommended Executive Upgrade
                  </div>
                )}

                {/* Top Section */}
                <div>
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-2xl font-black uppercase tracking-tight text-slate-900 leading-none">
                        {tier.name}
                      </h3>
                      <span className="bg-slate-100 text-slate-600 text-[9px] font-bold uppercase px-2 py-0.5 rounded-sm inline-block mt-2 font-mono">
                        {tier.badge}
                      </span>
                    </div>

                    <div className="text-right">
                      <div className="text-3xl font-black font-mono text-slate-900 tracking-tight">
                        {tier.price}
                      </div>
                      <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                        {tier.period}
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-500 mb-6 font-medium leading-relaxed">
                    {tier.subTitle}
                  </p>

                  <div className="border-t border-slate-100 pt-6 mb-6">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-4">
                      TIER BENEFITS INCLUDED
                    </h4>
                    <ul className="flex flex-col gap-3 text-xs">
                      {tier.features.map((feat, idx) => (
                        <li key={idx} className="flex items-start gap-2.5">
                          <CheckCircle className="w-4 h-4 text-[#005691] shrink-0 mt-0.5" />
                          <span className="text-slate-700 leading-normal">{feat}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Join CTA button */}
                <div className="mt-8">
                  <button
                    onClick={() => onJoinTier(tier)}
                    className={cn(
                      "w-full font-extrabold uppercase tracking-widest py-3 text-center text-xs cursor-pointer transition-colors",
                      isExecutive
                        ? "bg-yellow-600 text-white hover:bg-yellow-700 font-black"
                        : "bg-slate-900 text-white hover:bg-slate-800"
                    )}
                  >
                    Join {tier.name} Now
                  </button>
                  <p className="text-center text-[10px] text-slate-400 mt-2 font-medium">
                    Fully refundable annual guarantee. cancel anytime.
                  </p>
                </div>

              </div>
            );
          })}
        </div>

        {/* Frequently Asked Institutional Questions */}
        <div className="bg-white border border-slate-200 p-8">
          <h3 className="text-lg font-black uppercase text-slate-900 tracking-tight mb-6 border-b border-slate-100 pb-3 flex items-center gap-2">
            <HelpCircle className="w-5 h-5 text-slate-500" />
            MEMBERSHIP QUESTIONS & ANSWERS
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs">
            <div>
              <h4 className="font-bold text-slate-900 uppercase tracking-wide mb-1.5">
                Can I use my membership cards globally?
              </h4>
              <p className="text-slate-600 leading-relaxed">
                Yes. Your Costco membership card is fully valid at any of our hundreds of warehouses worldwide, including locations in Europe, Asia, Australia, and North America, as well as on Costco.com.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-slate-900 uppercase tracking-wide mb-1.5">
                How is the 2% Reward calculated?
              </h4>
              <p className="text-slate-600 leading-relaxed">
                For Executive Members, a 2% Reward is calculated on qualified pre-tax purchases made directly in our warehouses and on Costco.com. The Reward certificate is issued prior to your annual renewal month.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-slate-900 uppercase tracking-wide mb-1.5">
                What is the satisfaction guarantee?
              </h4>
              <p className="text-slate-600 leading-relaxed">
                We will refund your membership fee in full at any point during the year if you are not completely satisfied with your warehouse shopping experience. No questions. No fuss.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-slate-900 uppercase tracking-wide mb-1.5">
                Can I add additional members to my account?
              </h4>
              <p className="text-slate-600 leading-relaxed">
                Yes. Standard memberships allow one primary member and one free household card for any spouse, partner, or relative residing at the same physical residential address.
              </p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
