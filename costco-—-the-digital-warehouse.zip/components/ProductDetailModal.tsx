'use client';

import React from 'react';
import { Product } from '@/lib/data';
import { X, ShieldCheck, Truck, Star, Info, Check, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ProductDetailModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
}

export default function ProductDetailModal({
  product,
  onClose,
  onAddToCart,
}: ProductDetailModalProps) {
  if (!product) return null;

  return (
    <div className="fixed inset-0 bg-black/70 z-50 flex items-center justify-center p-4 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border-2 border-slate-300 w-full max-w-4xl max-h-[90vh] overflow-y-auto relative shadow-2xl rounded-none">
        
        {/* Top absolute header with close button */}
        <div className="sticky top-0 bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between z-10">
          <div className="flex items-center gap-2">
            <span className="font-mono text-xs font-bold text-slate-500 uppercase tracking-widest">
              COSTCO CATALOGUE · DEMO-001
            </span>
            {product.isKirkland && (
              <span className="bg-[#005691] text-white text-[9px] font-black uppercase tracking-widest px-1.5 py-0.2">
                Kirkland Signature
              </span>
            )}
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5 text-slate-800" />
          </button>
        </div>

        <div className="p-6 md:p-8 grid grid-cols-1 md:grid-cols-12 gap-8">
          
          {/* Left Column: Image and details */}
          <div className="md:col-span-5 flex flex-col items-center">
            <div className="relative border border-slate-200 bg-white p-4 w-full aspect-square flex items-center justify-center mb-4">
              <img
                src={product.image}
                alt={product.name}
                className="max-h-full max-w-full object-contain"
                referrerPolicy="no-referrer"
              />
              {product.isTreasureHunt && (
                <div className="absolute bottom-2 left-2 bg-yellow-500 text-slate-900 text-[10px] font-black uppercase tracking-wider px-2 py-0.5">
                  ★ TREASURE HUNT ITEM
                </div>
              )}
            </div>
            
            {/* Quick trust assurances */}
            <div className="border border-slate-200 bg-slate-50 p-4 w-full flex flex-col gap-2.5 text-left">
              <div className="flex items-center gap-2 text-xs text-slate-700">
                <ShieldCheck className="w-4 h-4 text-[#005691] shrink-0" />
                <div>
                  <strong className="text-slate-900">Costco Satisfaction Guarantee</strong>
                  <p className="text-[10px] text-slate-500">100% money back if you are not fully satisfied.</p>
                </div>
              </div>
              <div className="flex items-center gap-2 text-xs text-slate-700 border-t border-slate-200 pt-2.5">
                <Truck className="w-4 h-4 text-[#E31B23] shrink-0" />
                <div>
                  <strong className="text-slate-900">Warehouse Fulfilment</strong>
                  <p className="text-[10px] text-slate-500">Available in warehouse under aisle: {product.warehouseAisle}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Information, Pricing, Buy CTA */}
          <div className="md:col-span-7 flex flex-col text-left">
            
            {/* Brand and name */}
            <span className="text-xs font-black tracking-widest uppercase text-slate-500 mb-1">
              {product.brand}
            </span>
            <h2 className="text-2xl md:text-3xl font-black text-slate-900 leading-tight uppercase tracking-tight mb-3">
              {product.name}
            </h2>

            {/* Ratings & SKU */}
            <div className="flex flex-wrap items-center gap-4 border-b border-slate-100 pb-4 mb-4">
              <div className="flex items-center text-yellow-500">
                <Star className="w-4 h-4 fill-current" />
                <span className="text-sm font-extrabold text-slate-800 ml-1">{product.rating}</span>
                <span className="text-xs text-slate-500 ml-1">({product.reviewsCount} reviews)</span>
              </div>
              <span className="text-slate-300">|</span>
              <span className="text-xs font-mono text-slate-500 uppercase tracking-widest">
                ITEM ID: SKU-{product.id}042
              </span>
              <span className="text-slate-300">|</span>
              <span className="text-xs font-semibold text-[#005691]">
                {product.packSize}
              </span>
            </div>

            {/* Price Module */}
            <div className="bg-[#F2F2F2] border border-slate-300 p-5 mb-6 text-left">
              {product.previousPrice && (
                <div className="text-sm text-slate-500 line-through font-mono">
                  Regular Price: ${product.previousPrice.toFixed(2)}
                </div>
              )}
              
              <div className="flex items-baseline gap-2 mb-1">
                <span className="text-3xl md:text-4xl font-black font-mono text-slate-900 tracking-tight">
                  ${product.memberPrice.toFixed(2)}
                </span>
                <span className="text-xs font-bold text-slate-600 uppercase tracking-wider">
                  Member Price
                </span>
              </div>

              {product.savings && (
                <div className="text-sm font-black text-[#E31B23] uppercase tracking-wider mb-2">
                  YOUR SAVINGS: SAVE ${product.savings.toFixed(2)} (Instant Manufacturer Rebate)
                </div>
              )}

              <div className="text-[10px] text-slate-500 uppercase font-semibold leading-relaxed mt-2 border-t border-slate-300/60 pt-2">
                * Prices are member-only values. For non-members, a standard 5% surcharge is calculated at checkout.
              </div>
            </div>

            {/* Description */}
            <p className="text-sm text-slate-700 leading-relaxed mb-6">
              {product.description}
            </p>

            {/* Action CTAs */}
            <div className="flex flex-col sm:flex-row gap-3 mb-6">
              <button
                onClick={() => {
                  onAddToCart(product);
                  onClose();
                }}
                disabled={product.availability === 'OUT OF STOCK'}
                className="flex-1 bg-[#E31B23] hover:bg-red-700 disabled:bg-slate-300 text-white font-extrabold tracking-widest uppercase py-4 px-6 text-center transition-colors text-sm cursor-pointer"
              >
                {product.availability === 'OUT OF STOCK' ? 'OUT OF STOCK' : 'ADD TO WAREHOUSE CART'}
              </button>
            </div>

            {/* Specs Table */}
            <div className="border border-slate-200">
              <div className="bg-slate-100 px-4 py-2 border-b border-slate-200 text-xs font-bold uppercase tracking-wider">
                Product Specifications
              </div>
              <table className="w-full text-xs">
                <tbody>
                  {Object.entries(product.specs).map(([key, val], idx) => (
                    <tr
                      key={key}
                      className={cn(
                        "border-b border-slate-200",
                        idx % 2 === 0 ? "bg-white" : "bg-slate-50/50"
                      )}
                    >
                      <td className="px-4 py-2.5 font-bold text-slate-700 uppercase tracking-wide w-1/3">
                        {key}
                      </td>
                      <td className="px-4 py-2.5 text-slate-900 font-mono">
                        {val}
                      </td>
                    </tr>
                  ))}
                  <tr className="bg-white">
                    <td className="px-4 py-2.5 font-bold text-slate-700 uppercase tracking-wide">
                      Satisfaction Warranty
                    </td>
                    <td className="px-4 py-2.5 text-slate-900">
                      {product.warranty || 'Costco standard 100% satisfaction guarantee'}
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
