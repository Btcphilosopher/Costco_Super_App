'use client';

import React from 'react';
import { Product, KIRKLAND_STORIES } from '@/lib/data';
import { ShieldAlert, BookOpen, Layers, CheckCircle, ArrowRight, Star, ShoppingCart } from 'lucide-react';
import { cn } from '@/lib/utils';

interface KirklandSectionProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
}

export default function KirklandSection({
  products,
  onAddToCart,
  onSelectProduct,
}: KirklandSectionProps) {
  // Extract products belonging to Kirkland Signature
  const kirklandProducts = products.filter(p => p.isKirkland);

  return (
    <div className="bg-white py-14 px-6 border-b border-slate-200">
      <div className="max-w-7xl mx-auto">
        
        {/* Editorial Brand Header */}
        <div className="border-b-4 border-slate-900 pb-6 mb-12 flex flex-col md:flex-row justify-between items-start md:items-end gap-6 text-left">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="w-8 h-1.5 bg-[#005691]" />
              <span className="w-8 h-1.5 bg-[#E31B23]" />
              <span className="text-xs font-black uppercase tracking-widest text-slate-500 ml-1">
                The Kirkland Institution
              </span>
            </div>
            <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tight text-slate-900 leading-none">
              KIRKLAND SIGNATURE
            </h2>
            <p className="text-slate-600 text-sm md:text-base mt-2 max-w-xl">
              Our signature private label is built with one unwavering rule: deliver equal or superior quality than the leading national brand, at a significantly reduced price.
            </p>
          </div>
          <div className="bg-[#005691] text-white px-4 py-3 text-xs font-bold uppercase tracking-widest">
            Verified Premium Standard
          </div>
        </div>

        {/* Editorial Stories Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16 text-left">
          {KIRKLAND_STORIES.map((story, idx) => (
            <div key={idx} className="border border-slate-200 p-6 flex flex-col justify-between h-full hover:shadow-md transition-shadow">
              <div>
                <span className="text-xs font-mono font-bold text-slate-400 block mb-2">
                  0{idx + 1}. BRAND EDITORIAL
                </span>
                <h3 className="text-lg font-black uppercase text-slate-900 tracking-tight leading-snug mb-1">
                  {story.title}
                </h3>
                <h4 className="text-xs font-bold uppercase text-[#005691] mb-4">
                  {story.subtitle}
                </h4>
                <p className="text-slate-600 text-xs leading-relaxed whitespace-pre-line">
                  {story.content}
                </p>
              </div>

              <div className="border-t border-slate-100 pt-4 mt-6 flex items-center justify-between">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                  Costco Quality Lab
                </span>
                <span className="text-xs text-slate-400 font-bold uppercase">
                  Verified ✓
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Curation Shelf */}
        <div className="bg-slate-50 border border-slate-200 p-8 text-left mb-8">
          <h3 className="text-xl font-extrabold uppercase text-slate-900 tracking-tight mb-6 flex items-center gap-2">
            <Layers className="w-5 h-5 text-[#005691]" />
            THE KIRKLAND PRIVATE PALLET SHELF
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {kirklandProducts.map((product) => (
              <div key={product.id} className="bg-white border border-slate-200 p-4 flex flex-col justify-between group relative hover:border-slate-400 transition-colors">
                
                {/* Product top */}
                <div>
                  <div className="aspect-square w-full bg-white relative flex items-center justify-center border border-slate-100 p-2 mb-4 cursor-pointer" onClick={() => onSelectProduct(product)}>
                    <img
                      src={product.image}
                      alt={product.name}
                      className="max-h-full max-w-full object-contain"
                      referrerPolicy="no-referrer"
                    />
                  </div>

                  <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400 block mb-0.5">
                    {product.brand}
                  </span>
                  <h4 className="text-sm font-bold uppercase text-slate-900 line-clamp-2 leading-tight mb-2 cursor-pointer hover:text-[#005691]" onClick={() => onSelectProduct(product)}>
                    {product.name}
                  </h4>

                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-xs font-semibold text-slate-500">{product.packSize}</span>
                    <span className="text-slate-300">·</span>
                    <div className="flex items-center text-yellow-500">
                      <Star className="w-3 h-3 fill-current" />
                      <span className="text-xs font-bold text-slate-700 ml-0.5">{product.rating}</span>
                    </div>
                  </div>
                </div>

                {/* Product bottom pricing & buy */}
                <div className="border-t border-slate-100 pt-4 flex flex-col">
                  <div className="flex justify-between items-baseline mb-3 text-left">
                    <span className="text-lg font-black font-mono text-slate-900">
                      ${product.memberPrice.toFixed(2)}
                    </span>
                    <span className="text-[9px] font-bold text-slate-400 uppercase">
                      Member Price
                    </span>
                  </div>

                  <div className="flex gap-1">
                    <button
                      onClick={() => onSelectProduct(product)}
                      className="flex-1 border border-slate-200 hover:border-slate-400 text-[10px] font-bold uppercase tracking-wider py-2 cursor-pointer"
                    >
                      Specs
                    </button>
                    <button
                      onClick={() => onAddToCart(product)}
                      className="bg-[#005691] hover:bg-[#003f6b] text-white text-[10px] font-black uppercase tracking-wider px-3 py-2 flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <ShoppingCart className="w-3 h-3" />
                      Add
                    </button>
                  </div>
                </div>

              </div>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
