'use client';

import React, { useState } from 'react';
import { TRAVEL_PACKAGES, TravelPackage } from '@/lib/data';
import { Plane, Compass, Sparkles, Check, DollarSign, Calendar } from 'lucide-react';
import { cn } from '@/lib/utils';

interface TravelSectionProps {
  onBookPackage: (packageName: string, price: number) => void;
}

export default function TravelSection({ onBookPackage }: TravelSectionProps) {
  const [activePackage, setActivePackage] = useState<TravelPackage | null>(null);
  const [successBooking, setSuccessBooking] = useState(false);

  const handleBookSubmit = (pkg: TravelPackage) => {
    onBookPackage(pkg.title, pkg.price);
    setActivePackage(pkg);
    setSuccessBooking(true);
    setTimeout(() => {
      setSuccessBooking(false);
      setActivePackage(null);
    }, 2500);
  };

  return (
    <div className="bg-white py-14 px-6 border-b border-slate-200 text-left">
      <div className="max-w-7xl mx-auto">
        
        {/* Visual Editorial Header */}
        <div className="border-b-4 border-[#005691] pb-6 mb-12 flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
          <div>
            <div className="flex items-center gap-1.5 text-xs font-black uppercase tracking-widest text-[#005691] mb-2">
              <Compass className="w-4 h-4 text-orange-500 animate-spin" style={{ animationDuration: '20s' }} />
              Exclusive Global Excursions
            </div>
            <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tight text-slate-900 leading-none">
              COSTCO TRAVEL
            </h2>
            <p className="text-slate-600 text-sm mt-2 max-w-xl">
              We compile flights, five-star resorts, private transfers, and rental SUVs into complete, pre-vetted wholesale packages for our members. Less fuss. Extraordinary rates.
            </p>
          </div>
          <div className="bg-[#1F1F1F] text-white px-4 py-3 text-xs font-bold uppercase tracking-widest font-mono">
            Executive 2% cash back applies
          </div>
        </div>

        {/* Travel Packages List Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {TRAVEL_PACKAGES.map((pkg) => (
            <div
              key={pkg.id}
              className="bg-slate-50 border border-slate-200 flex flex-col justify-between group overflow-hidden hover:shadow-lg transition-all"
            >
              <div>
                {/* Hero imagery */}
                <div className="relative h-60 w-full overflow-hidden bg-slate-200">
                  <img
                    src={pkg.image}
                    alt={pkg.title}
                    className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-2 left-2 bg-slate-900/90 text-white text-[10px] font-black uppercase tracking-widest px-3 py-1">
                    {pkg.destination}
                  </div>
                </div>

                <div className="p-6">
                  <span className="text-[10px] font-bold text-[#005691] uppercase tracking-widest block mb-1">
                    {pkg.duration}
                  </span>
                  
                  <h3 className="text-xl font-extrabold uppercase text-slate-900 tracking-tight leading-tight mb-3">
                    {pkg.title}
                  </h3>

                  <p className="text-xs text-slate-500 leading-relaxed mb-6">
                    {pkg.description}
                  </p>

                  {/* Highlights section */}
                  <div className="border-t border-slate-200 pt-4 mb-4">
                    <h4 className="text-[9px] font-black uppercase tracking-widest text-slate-400 mb-3">
                      Package Inclusions
                    </h4>
                    <ul className="flex flex-col gap-2.5 text-xs text-slate-700">
                      {pkg.includes.map((inc, index) => (
                        <li key={index} className="flex items-start gap-2">
                          <Check className="w-3.5 h-3.5 text-green-600 shrink-0 mt-0.5" />
                          <span>{inc}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>

              {/* Bottom booking row */}
              <div className="border-t border-slate-200 p-6 bg-slate-100/50 flex flex-col justify-between">
                <div className="flex justify-between items-end mb-4">
                  <div className="text-left">
                    <span className="text-[10px] font-bold text-slate-400 uppercase block">
                      Member Package Price
                    </span>
                    <span className="text-2xl font-black font-mono text-slate-900">
                      ${pkg.price.toLocaleString()}
                    </span>
                    <span className="text-xs text-slate-500 font-semibold"> / person</span>
                  </div>

                  <span className="text-xs text-green-600 font-bold uppercase tracking-wider bg-green-50 px-2 py-0.5">
                    No Resort Fees
                  </span>
                </div>

                <div className="bg-white border border-slate-200 p-3 mb-4 text-[10px] text-slate-600 leading-normal text-left font-medium">
                  {pkg.savingNotes}
                </div>

                <button
                  onClick={() => handleBookSubmit(pkg)}
                  className="w-full bg-[#E31B23] hover:bg-red-700 text-white font-extrabold text-xs uppercase tracking-widest py-3 text-center cursor-pointer transition-colors"
                >
                  Request Booking Callback
                </button>
              </div>

            </div>
          ))}
        </div>

        {/* Floating Success Indicator for booking */}
        {successBooking && activePackage && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
            <div className="bg-white border-2 border-slate-300 p-8 max-w-sm text-center shadow-2xl">
              <Check className="w-10 h-10 text-green-600 mx-auto mb-4" />
              <h3 className="text-lg font-black uppercase text-slate-900">
                CALLBACK REQUEST SECURED
              </h3>
              <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                A Costco Travel specialist will call your registered phone number within 4 business hours to finalize flight selection for: 
                <strong className="text-slate-950 block mt-1 uppercase">{activePackage.title}</strong>
              </p>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
