'use client';

import React, { useState } from 'react';
import { WAREHOUSES, Warehouse } from '@/lib/data';
import { Search, MapPin, Fuel, Eye, Calendar, Clock, Phone, Navigation, Check, ShoppingBag } from 'lucide-react';
import { cn } from '@/lib/utils';

interface WarehouseFinderProps {
  onSelectWarehouse: (warehouse: Warehouse) => void;
  selectedWarehouse: Warehouse;
  warehouseMode: boolean;
  setWarehouseMode: (mode: boolean) => void;
}

export default function WarehouseFinder({
  onSelectWarehouse,
  selectedWarehouse,
  warehouseMode,
  setWarehouseMode,
}: WarehouseFinderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchedWarehouses, setSearchedWarehouses] = useState<Warehouse[]>(WAREHOUSES);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) {
      setSearchedWarehouses(WAREHOUSES);
      return;
    }
    const filtered = WAREHOUSES.filter(
      wh =>
        wh.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        wh.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
        wh.state.toLowerCase().includes(searchQuery.toLowerCase()) ||
        wh.zipCode.includes(searchQuery)
    );
    setSearchedWarehouses(filtered);
  };

  const handleUseCurrentLocation = () => {
    // Select the first one as closest for demo simulation
    if (WAREHOUSES.length > 0) {
      onSelectWarehouse(WAREHOUSES[0]);
    }
  };

  return (
    <div className="bg-[#F2F2F2] py-14 px-6 border-b border-slate-200 text-left">
      <div className="max-w-7xl mx-auto">
        
        {/* Title / Description */}
        <div className="border-b border-slate-300 pb-6 mb-8 flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
          <div>
            <h2 className="text-3xl font-black uppercase tracking-tight text-slate-900">
              FIND A WAREHOUSE
            </h2>
            <p className="text-slate-500 text-xs mt-1">
              Select your local warehouse to calculate regional pricing, local fuel rates, and food court inventory.
            </p>
          </div>

          {/* Local Shopping Mode Controller */}
          <div className="bg-white border border-slate-300 p-4 shrink-0 flex items-center justify-between gap-6 w-full md:w-auto">
            <div className="text-left">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">
                Warehouse Configuration
              </span>
              <span className="text-sm font-black text-slate-900 uppercase">
                Shop This Warehouse Mode
              </span>
              <p className="text-[10px] text-slate-500">
                Filters catalog strictly by local Seattle/SF inventory.
              </p>
            </div>
            
            <button
              onClick={() => setWarehouseMode(!warehouseMode)}
              className={cn(
                "px-4 py-2 text-xs font-black uppercase tracking-wider transition-all cursor-pointer border",
                warehouseMode
                  ? "bg-[#E31B23] border-[#E31B23] text-white"
                  : "bg-slate-100 border-slate-300 text-slate-600 hover:bg-slate-200"
              )}
            >
              {warehouseMode ? 'ACTIVE ✓' : 'ACTIVATE'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Left: Locator Form and List */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            
            {/* Locator Form */}
            <form onSubmit={handleSearch} className="bg-white border border-slate-300 p-6 shadow-sm">
              <h3 className="text-sm font-bold uppercase tracking-wider text-slate-900 mb-3">
                Search Warehouses
              </h3>
              
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <input
                    type="text"
                    placeholder="Enter Postcode, City, or State..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-[#F2F2F2] border border-slate-300 focus:border-slate-500 focus:bg-white text-sm px-4 py-2.5 pl-10 focus:outline-none"
                  />
                  <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3.5" />
                </div>
                <button
                  type="submit"
                  className="bg-[#005691] hover:bg-[#003f6b] text-white font-extrabold text-xs uppercase tracking-widest px-5 py-2.5 cursor-pointer"
                >
                  Locate
                </button>
              </div>

              <button
                type="button"
                onClick={handleUseCurrentLocation}
                className="mt-3 text-xs text-[#005691] font-bold uppercase tracking-wider hover:underline flex items-center gap-1.5 cursor-pointer"
              >
                <Navigation className="w-3.5 h-3.5" />
                Use My Current Location
              </button>
            </form>

            {/* Warehouse List */}
            <div className="flex flex-col gap-4 max-h-[500px] overflow-y-auto">
              {searchedWarehouses.map((wh) => {
                const isSelected = selectedWarehouse.id === wh.id;
                return (
                  <div
                    key={wh.id}
                    onClick={() => onSelectWarehouse(wh)}
                    className={cn(
                      "bg-white border p-6 text-left transition-all cursor-pointer",
                      isSelected
                        ? "border-[#005691] ring-1 ring-[#005691]/25 bg-blue-50/5"
                        : "border-slate-300 hover:border-slate-400"
                    )}
                  >
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h4 className="font-extrabold text-base text-slate-900 uppercase">
                          {wh.name} {wh.number}
                        </h4>
                        <p className="text-slate-500 text-xs mt-0.5">
                          {wh.address}, {wh.city}, {wh.state} {wh.zipCode}
                        </p>
                      </div>
                      {isSelected && (
                        <span className="bg-[#005691] text-white text-[9px] font-black uppercase tracking-wider px-2 py-0.5">
                          ACTIVE WHS
                        </span>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-4 border-t border-slate-100 pt-4 mt-4 text-xs text-slate-600">
                      <div>
                        <div className="flex items-center gap-1.5 font-bold uppercase tracking-wider text-slate-400 text-[10px]">
                          <Clock className="w-3.5 h-3.5" />
                          Hours Today
                        </div>
                        <div className="mt-1 font-mono text-slate-800">{wh.hours.weekdays}</div>
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5 font-bold uppercase tracking-wider text-slate-400 text-[10px]">
                          <Phone className="w-3.5 h-3.5" />
                          Contact Phone
                        </div>
                        <div className="mt-1 font-mono text-slate-800">{wh.phone}</div>
                      </div>
                    </div>

                    {/* Services row */}
                    <div className="flex flex-wrap gap-2 mt-4 pt-4 border-t border-slate-100">
                      {wh.services.gasStation && (
                        <span className="bg-slate-100 text-slate-700 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 border border-slate-200">
                          ⛽ Fuel Station
                        </span>
                      )}
                      {wh.services.foodCourt && (
                        <span className="bg-slate-100 text-slate-700 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 border border-slate-200">
                          🍕 Food Court
                        </span>
                      )}
                      {wh.services.tireCenter && (
                        <span className="bg-slate-100 text-slate-700 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 border border-slate-200">
                          🚗 Tire Center
                        </span>
                      )}
                    </div>

                  </div>
                );
              })}
            </div>

          </div>

          {/* Right: Map / Logistics Display */}
          <div className="lg:col-span-7 bg-[#1F1F1F] border border-slate-800 flex flex-col relative text-left">
            {/* Map viewports - Logistics Grid layout */}
            <div className="flex-1 bg-[#222] p-6 flex flex-col justify-between relative overflow-hidden h-[400px]">
              
              {/* Simulated Map Grid layout */}
              <div className="absolute inset-0 opacity-15 pointer-events-none">
                <div className="absolute inset-0" style={{
                  backgroundImage: `radial-gradient(#ffffff 1px, transparent 1px)`,
                  backgroundSize: '24px 24px'
                }} />
              </div>

              {/* Title & Logistics details */}
              <div className="relative z-10 flex justify-between items-start">
                <div className="bg-slate-900/90 border border-slate-800 p-4">
                  <span className="text-[9px] font-black uppercase text-yellow-500 tracking-widest block">
                    ACTIVE SATELLITE RADAR
                  </span>
                  <span className="text-sm font-bold text-white uppercase font-mono">
                    FULFILMENT COORDINATES: {selectedWarehouse.zipCode}
                  </span>
                </div>

                <div className="bg-slate-900/90 border border-slate-800 p-4 text-right">
                  <span className="text-[9px] font-black uppercase text-slate-400 tracking-widest block">
                    Fulfilment Zone
                  </span>
                  <span className="text-xs font-bold text-green-400 font-mono">
                    REGIONAL ROUTE: SECURE
                  </span>
                </div>
              </div>

              {/* Simulated Warehouses on Map Grid */}
              <div className="relative z-10 flex justify-center items-center h-48 w-full border border-dashed border-slate-800">
                
                {/* Pacific Northwest simulated line */}
                <div className="absolute top-1/4 left-1/4 flex flex-col items-center">
                  <div className={cn(
                    "w-4 h-4 rounded-full flex items-center justify-center transition-all",
                    selectedWarehouse.id === 'wh-001' ? 'bg-[#E31B23] animate-ping scale-110' : 'bg-[#005691]'
                  )} />
                  <span className="text-[9px] font-bold font-mono text-slate-400 mt-1 uppercase">Seattle Whs #001</span>
                </div>

                {/* Portland simulated line */}
                <div className="absolute top-2/4 left-2/4 flex flex-col items-center">
                  <div className={cn(
                    "w-4 h-4 rounded-full flex items-center justify-center transition-all",
                    selectedWarehouse.id === 'wh-122' ? 'bg-[#E31B23] animate-ping scale-110' : 'bg-[#005691]'
                  )} />
                  <span className="text-[9px] font-bold font-mono text-slate-400 mt-1 uppercase">Portland Whs #122</span>
                </div>

                {/* San Francisco simulated line */}
                <div className="absolute bottom-1/4 left-1/3 flex flex-col items-center">
                  <div className={cn(
                    "w-4 h-4 rounded-full flex items-center justify-center transition-all",
                    selectedWarehouse.id === 'wh-550' ? 'bg-[#E31B23] animate-ping scale-110' : 'bg-[#005691]'
                  )} />
                  <span className="text-[9px] font-bold font-mono text-slate-400 mt-1 uppercase">SOMA SF Whs #550</span>
                </div>

                <span className="text-[10px] text-slate-600 font-mono absolute bottom-2 font-semibold">
                  * SIMULATED LOGISTIC RADAR — DISTANCES NOT TO SCALE
                </span>
              </div>

              {/* Selected warehouse services dashboard */}
              <div className="relative z-10 bg-slate-900 border border-slate-800 p-6 grid grid-cols-2 sm:grid-cols-3 gap-4">
                <div>
                  <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest block">Opening Hours</span>
                  <span className="text-xs text-white font-semibold font-mono">{selectedWarehouse.hours.weekdays}</span>
                </div>
                <div>
                  <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest block">Fuel Rates (Regular)</span>
                  <span className="text-xs text-green-400 font-semibold font-mono">
                    {selectedWarehouse.services.gasStation ? '$2.89 / gallon' : 'No Gas Station'}
                  </span>
                </div>
                <div>
                  <span className="text-[9px] font-bold text-slate-500 uppercase tracking-widest block">Pharmacy Status</span>
                  <span className="text-xs text-white font-semibold uppercase">
                    {selectedWarehouse.services.pharmacy ? 'OPEN' : 'UNAVAILABLE'}
                  </span>
                </div>
              </div>

            </div>
          </div>

        </div>

      </div>
    </div>
  );
}
