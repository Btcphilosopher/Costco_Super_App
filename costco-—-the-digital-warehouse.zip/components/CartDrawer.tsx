'use client';

import React, { useState } from 'react';
import { Product } from '@/lib/data';
import { X, ShoppingBag, Plus, Minus, CreditCard, Home, Truck, Check, HelpCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface CartItem {
  product: Product;
  quantity: number;
}

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  cart: CartItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onClearCart: () => void;
  onPlaceOrder: (items: { name: string; quantity: number; price: number }[], total: number) => void;
}

export default function CartDrawer({
  isOpen,
  onClose,
  cart,
  onUpdateQuantity,
  onClearCart,
  onPlaceOrder,
}: CartDrawerProps) {
  const [checkoutStep, setCheckoutStep] = useState<'cart' | 'signin' | 'delivery' | 'payment' | 'review'>('cart');
  
  // Checkout form states
  const [userEmail, setUserEmail] = useState('tom@ahyx.org');
  const [shippingAddress, setShippingAddress] = useState('1042 Pallet Way');
  const [shippingCity, setShippingCity] = useState('Seattle');
  const [shippingState, setShippingState] = useState('WA');
  const [shippingZip, setShippingZip] = useState('98134');
  const [cardHolder, setCardHolder] = useState('Tom Member');
  const [cardNumber, setCardNumber] = useState('4111 2222 3333 4444');
  const [cardExpiry, setCardExpiry] = useState('12/29');
  const [cardCvv, setCardCvv] = useState('042');

  if (!isOpen) return null;

  // Calculate prices
  const subtotal = cart.reduce((sum, item) => sum + item.product.memberPrice * item.quantity, 0);
  const savings = cart.reduce((sum, item) => sum + (item.product.savings || 0) * item.quantity, 0);
  const shippingFee = subtotal > 150 ? 0 : 15.00;
  const estimatedTax = subtotal * 0.085; // 8.5%
  const grandTotal = subtotal + shippingFee + estimatedTax;

  const handleCheckoutSubmit = () => {
    const formattedItems = cart.map(item => ({
      name: item.product.name,
      quantity: item.quantity,
      price: item.product.memberPrice,
    }));

    onPlaceOrder(formattedItems, grandTotal);
    onClearCart();
    setCheckoutStep('cart');
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex justify-end backdrop-blur-xs">
      
      {/* Drawer canvas */}
      <div className="bg-white border-l-2 border-slate-300 w-full max-w-md h-full flex flex-col justify-between shadow-2xl text-left">
        
        {/* Header bar */}
        <div className="p-4 bg-slate-900 text-white flex justify-between items-center shrink-0">
          <div className="flex items-center gap-2">
            <ShoppingBag className="w-5 h-5 text-[#E31B23]" />
            <span className="font-extrabold text-sm uppercase tracking-wider">
              Warehouse Cart & Checkout
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-slate-800 rounded-sm cursor-pointer"
          >
            <X className="w-5 h-5 text-slate-300" />
          </button>
        </div>

        {/* Steps Progress Header if checking out */}
        {checkoutStep !== 'cart' && (
          <div className="bg-slate-100 border-b border-slate-200 px-4 py-2 flex justify-between items-center text-[10px] font-black uppercase tracking-widest text-slate-500 shrink-0 select-none">
            <span className={checkoutStep === 'signin' ? 'text-[#005691]' : ''}>1. IDENTIFY</span>
            <span>→</span>
            <span className={checkoutStep === 'delivery' ? 'text-[#005691]' : ''}>2. LOGISTICS</span>
            <span>→</span>
            <span className={checkoutStep === 'payment' ? 'text-[#005691]' : ''}>3. PAYMENT</span>
            <span>→</span>
            <span className={checkoutStep === 'review' ? 'text-[#005691]' : ''}>4. CONFIRM</span>
          </div>
        )}

        {/* Dynamic step body */}
        <div className="flex-1 p-6 overflow-y-auto">
          {checkoutStep === 'cart' && (
            /* Cart Items List View */
            <div className="flex flex-col h-full justify-between">
              <div>
                <h3 className="text-xs font-black uppercase text-slate-400 tracking-widest mb-4 border-b border-slate-100 pb-2">
                  Pallet Allocation ({cart.length} items)
                </h3>

                {cart.length === 0 ? (
                  <div className="text-center py-20 text-slate-400 text-xs font-semibold">
                    Your shopping cart is currently empty.<br />
                    Select bulk pallets from the catalog to load them!
                  </div>
                ) : (
                  <div className="flex flex-col gap-4">
                    {cart.map((item) => (
                      <div key={item.product.id} className="flex gap-4 border-b border-slate-100 pb-4">
                        <div className="w-16 h-16 bg-white border border-slate-200 shrink-0 p-1 flex items-center justify-center">
                          <img
                            src={item.product.image}
                            alt={item.product.name}
                            className="max-h-full max-w-full object-contain"
                          />
                        </div>

                        <div className="flex-1 flex flex-col justify-between text-xs text-left">
                          <div>
                            <strong className="text-[10px] text-slate-400 uppercase tracking-wide block">
                              {item.product.brand}
                            </strong>
                            <h4 className="font-bold text-slate-900 uppercase leading-snug line-clamp-1">
                              {item.product.name}
                            </h4>
                            <span className="text-slate-500 text-[10px]">{item.product.packSize}</span>
                          </div>

                          <div className="flex justify-between items-center mt-2">
                            <span className="font-mono font-bold text-slate-900 text-sm">
                              ${(item.product.memberPrice * item.quantity).toFixed(2)}
                            </span>

                            {/* Qty incrementors */}
                            <div className="flex items-center gap-2">
                              <button
                                onClick={() => onUpdateQuantity(item.product.id, -1)}
                                className="w-6 h-6 border border-slate-300 rounded-full flex items-center justify-center hover:bg-slate-100 font-bold"
                              >
                                <Minus className="w-3 h-3 text-slate-600" />
                              </button>
                              <span className="font-mono text-slate-900 font-bold w-4 text-center">
                                {item.quantity}
                              </span>
                              <button
                                onClick={() => onUpdateQuantity(item.product.id, 1)}
                                className="w-6 h-6 border border-slate-300 rounded-full flex items-center justify-center hover:bg-slate-100 font-bold"
                              >
                                <Plus className="w-3 h-3 text-slate-600" />
                              </button>
                            </div>
                          </div>
                        </div>

                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {checkoutStep === 'signin' && (
            /* Step 1: Sign in Identity */
            <div className="flex flex-col gap-4">
              <h3 className="text-sm font-black uppercase text-slate-900 tracking-tight mb-2">
                Step 1: Member Identity Verification
              </h3>
              
              <div className="text-xs">
                <label className="block text-slate-700 font-bold uppercase mb-1">
                  Registered Email Address
                </label>
                <input
                  type="email"
                  value={userEmail}
                  onChange={(e) => setUserEmail(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 p-2.5 outline-none font-mono text-sm"
                />
              </div>

              <div className="bg-slate-100 p-4 border border-slate-200 text-slate-600 text-[11px] leading-relaxed">
                We verified your active membership account based on: 
                <strong className="text-slate-900 block font-mono">WHS-104-928-301 (EXECUTIVE CARD)</strong>
                Qualified to earn 2% cash back rewards on this checkout.
              </div>

              <button
                onClick={() => setCheckoutStep('delivery')}
                className="bg-[#005691] hover:bg-[#003f6b] text-white font-extrabold uppercase tracking-widest text-xs py-3 text-center cursor-pointer mt-4"
              >
                Continue to Logistics Setup
              </button>
            </div>
          )}

          {checkoutStep === 'delivery' && (
            /* Step 2: Logistics / Delivery Address */
            <div className="flex flex-col gap-4 text-xs text-left">
              <h3 className="text-sm font-black uppercase text-slate-900 tracking-tight mb-2">
                Step 2: Logistics & Dispatch Address
              </h3>

              <div>
                <label className="block text-slate-700 font-bold uppercase mb-1">Shipping Address</label>
                <input
                  type="text"
                  value={shippingAddress}
                  onChange={(e) => setShippingAddress(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 p-2 text-sm"
                />
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div className="col-span-2">
                  <label className="block text-slate-700 font-bold uppercase mb-1">City</label>
                  <input
                    type="text"
                    value={shippingCity}
                    onChange={(e) => setShippingCity(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 p-2 text-sm"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold uppercase mb-1">State</label>
                  <input
                    type="text"
                    value={shippingState}
                    onChange={(e) => setShippingState(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 p-2 text-sm"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-700 font-bold uppercase mb-1">Postal Zip Code</label>
                <input
                  type="text"
                  value={shippingZip}
                  onChange={(e) => setShippingZip(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 p-2 font-mono text-sm"
                />
              </div>

              <div className="bg-blue-50 border border-blue-100 p-4 text-[#005691] leading-relaxed flex items-start gap-2">
                <Truck className="w-5 h-5 shrink-0 mt-0.5" />
                <span className="text-[11px] font-semibold">
                  Standard 2-Day Freight Delivery available. Surcharge waived for bulk pallet orders exceeding $150.
                </span>
              </div>

              <div className="flex gap-2 mt-4">
                <button
                  onClick={() => setCheckoutStep('signin')}
                  className="border border-slate-300 text-slate-700 font-extrabold uppercase tracking-widest py-3 px-4 text-xs hover:bg-slate-50 cursor-pointer"
                >
                  Back
                </button>
                <button
                  onClick={() => setCheckoutStep('payment')}
                  className="flex-1 bg-[#005691] hover:bg-[#003f6b] text-white font-extrabold uppercase tracking-widest text-xs py-3 text-center cursor-pointer"
                >
                  Continue to Payment
                </button>
              </div>
            </div>
          )}

          {checkoutStep === 'payment' && (
            /* Step 3: Payment details */
            <div className="flex flex-col gap-4 text-xs text-left">
              <h3 className="text-sm font-black uppercase text-slate-900 tracking-tight mb-2">
                Step 3: Secure Payment Portal
              </h3>

              <div>
                <label className="block text-slate-700 font-bold uppercase mb-1">Cardholder Name</label>
                <input
                  type="text"
                  value={cardHolder}
                  onChange={(e) => setCardHolder(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 p-2 text-sm"
                />
              </div>

              <div>
                <label className="block text-slate-700 font-bold uppercase mb-1">Credit Card Number</label>
                <input
                  type="text"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                  className="w-full bg-slate-50 border border-slate-300 p-2 font-mono text-sm"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-700 font-bold uppercase mb-1">Expiry Date</label>
                  <input
                    type="text"
                    value={cardExpiry}
                    onChange={(e) => setCardExpiry(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 p-2 font-mono text-sm"
                  />
                </div>
                <div>
                  <label className="block text-slate-700 font-bold uppercase mb-1">CVV Code</label>
                  <input
                    type="text"
                    value={cardCvv}
                    onChange={(e) => setCardCvv(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-300 p-2 font-mono text-sm"
                  />
                </div>
              </div>

              <div className="bg-slate-50 p-4 border border-slate-200 text-slate-500 leading-normal text-[11px] font-medium">
                * We implement secure credit token abstraction. We never store raw payment card data on our staging database servers.
              </div>

              <div className="flex gap-2 mt-4">
                <button
                  onClick={() => setCheckoutStep('delivery')}
                  className="border border-slate-300 text-slate-700 font-extrabold uppercase tracking-widest py-3 px-4 text-xs hover:bg-slate-50 cursor-pointer"
                >
                  Back
                </button>
                <button
                  onClick={() => setCheckoutStep('review')}
                  className="flex-1 bg-[#005691] hover:bg-[#003f6b] text-white font-extrabold uppercase tracking-widest text-xs py-3 text-center cursor-pointer"
                >
                  Review Order Summary
                </button>
              </div>
            </div>
          )}

          {checkoutStep === 'review' && (
            /* Step 4: Final Summary Review */
            <div className="flex flex-col gap-4 text-xs text-left">
              <h3 className="text-sm font-black uppercase text-slate-900 tracking-tight mb-2">
                Step 4: Final Invoice Confirmation
              </h3>

              <div className="bg-slate-50 p-4 border border-slate-200 flex flex-col gap-2 font-medium">
                <div>
                  <span className="text-slate-400 font-bold uppercase text-[9px] block">DELIVERY DISPATCH</span>
                  <span className="text-slate-800 font-semibold">{shippingAddress}, {shippingCity}, {shippingState} {shippingZip}</span>
                </div>
                <div className="border-t border-slate-200/60 pt-2">
                  <span className="text-slate-400 font-bold uppercase text-[9px] block">PAYMENT CARD METHOD</span>
                  <span className="text-slate-800 font-semibold font-mono">VISA Ending in {cardNumber.slice(-4)}</span>
                </div>
              </div>

              <div className="border-t border-slate-100 pt-4 mt-2">
                <span className="text-slate-500 font-bold uppercase text-[10px] block mb-2">Cart Itemized Allocation</span>
                <div className="flex flex-col gap-1.5 max-h-40 overflow-y-auto">
                  {cart.map(item => (
                    <div key={item.product.id} className="flex justify-between">
                      <span className="text-slate-600 font-medium">{item.quantity}x {item.product.name}</span>
                      <span className="font-mono font-bold text-slate-900">${(item.product.memberPrice * item.quantity).toFixed(2)}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-2 mt-4">
                <button
                  onClick={() => setCheckoutStep('payment')}
                  className="border border-slate-300 text-slate-700 font-extrabold uppercase tracking-widest py-3 px-4 text-xs hover:bg-slate-50 cursor-pointer"
                >
                  Back
                </button>
                <button
                  onClick={handleCheckoutSubmit}
                  className="flex-1 bg-[#E31B23] hover:bg-red-700 text-white font-extrabold uppercase tracking-widest text-xs py-3 text-center cursor-pointer"
                >
                  Authorize Bulk Shipment
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Pricing Subtotal Bottom Drawer Panel */}
        <div className="p-6 bg-slate-50 border-t border-slate-200 shrink-0 text-left font-medium">
          <div className="flex flex-col gap-2 text-xs text-slate-600 mb-4 border-b border-slate-200/80 pb-4">
            <div className="flex justify-between">
              <span>Items Subtotal:</span>
              <span className="font-mono font-bold text-slate-900">${subtotal.toFixed(2)}</span>
            </div>
            {savings > 0 && (
              <div className="flex justify-between text-[#E31B23] font-bold">
                <span>Instant Manufacturer Rebate:</span>
                <span className="font-mono">- ${savings.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between">
              <span>Freight Delivery:</span>
              <span className="font-mono">{shippingFee === 0 ? 'FREE ✓' : `$${shippingFee.toFixed(2)}`}</span>
            </div>
            <div className="flex justify-between">
              <span>Estimated Sales Taxes (8.5%):</span>
              <span className="font-mono">${estimatedTax.toFixed(2)}</span>
            </div>
          </div>

          <div className="flex justify-between items-baseline mb-6">
            <span className="font-black text-slate-950 uppercase tracking-wide">
              Invoice Grand Total
            </span>
            <span className="text-3xl font-black font-mono text-slate-900 tracking-tight">
              ${grandTotal.toFixed(2)}
            </span>
          </div>

          {checkoutStep === 'cart' && (
            <button
              onClick={() => setCheckoutStep('signin')}
              disabled={cart.length === 0}
              className="w-full bg-[#E31B23] hover:bg-red-700 disabled:bg-slate-300 text-white font-black uppercase tracking-widest text-xs py-4 text-center cursor-pointer transition-colors"
            >
              PROCEED TO SECURE CHECKOUT
            </button>
          )}
        </div>

      </div>
    </div>
  );
}
