'use client';

import React, { useState } from 'react';
import { Product } from '@/lib/data';
import { ShoppingCart, Star, Sparkles, Filter, ChevronDown, Check, ArrowRight, RefreshCcw } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion } from 'motion/react';

interface CostcoGridProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
  searchQuery: string;
  activeCategory: string;
  setActiveCategory: (cat: string) => void;
  warehouseMode: boolean;
}

export default function CostcoGrid({
  products,
  onAddToCart,
  onSelectProduct,
  searchQuery,
  activeCategory,
  setActiveCategory,
  warehouseMode,
}: CostcoGridProps) {
  // Local filter states
  const [filterKirklandOnly, setFilterKirklandOnly] = useState(false);
  const [filterSavingsOnly, setFilterSavingsOnly] = useState(false);
  const [sortBy, setSortBy] = useState<'default' | 'price-asc' | 'price-desc' | 'rating'>('default');

  // Categories list
  const categories = [
    { id: 'all', label: 'All Warehouse' },
    { id: 'Grocery', label: 'Grocery Pantry' },
    { id: 'Electronics', label: 'Electronics & Media' },
    { id: 'Home & Household', label: 'Home & Household' },
    { id: 'Treasure Hunt', label: 'Treasure Hunt' },
    { id: 'Apparel', label: 'Apparel' },
    { id: 'Pet Supplies', label: 'Pet Supplies' },
    { id: 'Health & Pharmacy', label: 'Health & Pharmacy' },
  ];

  // Process and filter the products list
  const filteredProducts = products.filter((product) => {
    // Search query matching
    const matchesSearch =
      product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
      product.description.toLowerCase().includes(searchQuery.toLowerCase());

    // Category matching
    const matchesCategory =
      activeCategory === 'all' || product.category === activeCategory;

    // Kirkland Signature filter
    const matchesKirkland = !filterKirklandOnly || product.isKirkland;

    // Savings / Deal filter
    const matchesSavings = !filterSavingsOnly || (product.savings && product.savings > 0);

    // Warehouse inventory filter (in warehouse mode, prioritize warehouse products)
    const matchesWarehouse = !warehouseMode || product.warehouseAvailability;

    return matchesSearch && matchesCategory && matchesKirkland && matchesSavings && matchesWarehouse;
  });

  // Sorting
  const sortedProducts = [...filteredProducts].sort((a, b) => {
    if (sortBy === 'price-asc') return a.memberPrice - b.memberPrice;
    if (sortBy === 'price-desc') return b.memberPrice - a.memberPrice;
    if (sortBy === 'rating') return b.rating - a.rating;
    return 0; // Default
  });

  // Reset all filters helper
  const handleResetFilters = () => {
    setFilterKirklandOnly(false);
    setFilterSavingsOnly(false);
    setSortBy('default');
    setActiveCategory('all');
  };

  return (
    <div className="py-10 bg-[#F2F2F2] px-6">
      <div className="max-w-7xl mx-auto">
        
        {/* Header and Controls Row */}
        <div className="bg-white border border-slate-200 p-6 mb-8 shadow-sm">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <div>
              <h2 className="text-xl font-extrabold uppercase tracking-tight text-slate-900 flex items-center gap-2">
                <span className="w-2.5 h-6 bg-[#005691]" />
                THE DIGITAL PALLET GRID
              </h2>
              <p className="text-slate-500 text-xs mt-1">
                Displaying {sortedProducts.length} curated, high-volume products direct from pallets.
              </p>
            </div>

            {/* Sorting controls */}
            <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
              <button
                onClick={() => setFilterKirklandOnly(!filterKirklandOnly)}
                className={cn(
                  "px-3 py-1.5 text-xs font-semibold uppercase tracking-wider transition-all border cursor-pointer",
                  filterKirklandOnly
                    ? "bg-[#005691] border-[#005691] text-white"
                    : "bg-white border-slate-300 text-slate-700 hover:border-slate-400"
                )}
              >
                Kirkland Signature
              </button>
              <button
                onClick={() => setFilterSavingsOnly(!filterSavingsOnly)}
                className={cn(
                  "px-3 py-1.5 text-xs font-semibold uppercase tracking-wider transition-all border cursor-pointer",
                  filterSavingsOnly
                    ? "bg-[#E31B23] border-[#E31B23] text-white"
                    : "bg-white border-slate-300 text-slate-700 hover:border-slate-400"
                )}
              >
                Instant Savings
              </button>
              
              <div className="relative">
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-white border border-slate-300 text-slate-700 text-xs font-semibold uppercase tracking-wider px-3 py-1.5 rounded-none outline-none appearance-none pr-8 cursor-pointer hover:border-slate-400"
                >
                  <option value="default">Default Palette</option>
                  <option value="price-asc">Price: Low to High</option>
                  <option value="price-desc">Price: High to Low</option>
                  <option value="rating">Top Rated</option>
                </select>
                <ChevronDown className="w-4 h-4 text-slate-500 absolute right-2.5 top-2.5 pointer-events-none" />
              </div>
            </div>
          </div>

          {/* Categories Tab Bar - Interactive button controls */}
          <div className="flex flex-wrap gap-1.5 border-t border-slate-100 pt-4">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                className={cn(
                  "px-4 py-2 text-xs font-semibold uppercase tracking-wider transition-all cursor-pointer border",
                  activeCategory === cat.id
                    ? "bg-slate-900 border-slate-900 text-white font-bold"
                    : "bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100 hover:text-slate-900"
                )}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Empty state if no products match */}
        {sortedProducts.length === 0 ? (
          <div className="bg-white border border-slate-200 p-12 text-center shadow-sm">
            <Filter className="w-12 h-12 text-slate-300 mx-auto mb-4" />
            <h3 className="text-lg font-bold text-slate-800 uppercase tracking-tight">No Pallets Matched Your Filters</h3>
            <p className="text-slate-500 text-xs mt-1 mb-6 max-w-sm mx-auto">
              We couldn&apos;t find any items in our current warehouse inventory matching those selections.
            </p>
            <button
              onClick={handleResetFilters}
              className="bg-[#005691] hover:bg-[#003f6b] text-white px-5 py-2.5 text-xs font-bold uppercase tracking-wider transition-colors cursor-pointer"
            >
              Reset All Filters
            </button>
          </div>
        ) : (
          /* The Costco Grid - Varying Card Scale layout */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-6 items-stretch">
            
            {sortedProducts.map((product, idx) => {
              // We vary card size intelligently based on index for the authentic "Treasure Hunt / Warehouse" asymmetry
              const isLargeCard = idx === 0 || (idx === 4 && sortedProducts.length > 4); // Double-column cards
              const isKirklandHighlight = product.isKirkland && idx % 3 === 2; // Editorial-style card background
              
              return (
                <div
                  key={product.id}
                  className={cn(
                    "bg-white border transition-all duration-150 flex flex-col justify-between group overflow-hidden relative",
                    isLargeCard 
                      ? "lg:col-span-8 border-slate-300 shadow-md" 
                      : "lg:col-span-4 border-slate-200 hover:border-slate-400 hover:shadow-sm",
                    isKirklandHighlight ? "bg-slate-50 border-blue-100" : ""
                  )}
                >
                  {/* Badge tags */}
                  <div className="absolute top-2 left-2 z-10 flex flex-col gap-1.5 items-start">
                    {product.isKirkland && (
                      <span className="bg-[#005691] text-white text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-none shadow-sm">
                        KIRKLAND SIGNATURE
                      </span>
                    )}
                    {product.isTreasureHunt && (
                      <span className="bg-yellow-500 text-slate-900 text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-none shadow-sm">
                        ★ TREASURE HUNT SPECIAL
                      </span>
                    )}
                    {product.savings && (
                      <span className="bg-[#E31B23] text-white text-[9px] font-black uppercase tracking-widest px-2 py-0.5 rounded-none shadow-sm">
                        INSTANT SAVINGS: SAVE ${product.savings}
                      </span>
                    )}
                  </div>

                  {/* Product top half details */}
                  <div className={cn(
                    "p-6 flex flex-col",
                    isLargeCard ? "lg:flex-row lg:gap-8 items-center h-full" : "h-full"
                  )}>
                    {/* Image Area with Zero-Broken-Image fallback policy */}
                    <div
                      onClick={() => onSelectProduct(product)}
                      className={cn(
                        "relative bg-white border border-slate-100 overflow-hidden shrink-0 cursor-pointer mb-4",
                        isLargeCard ? "w-full lg:w-72 aspect-square" : "w-full aspect-[4/3]"
                      )}
                    >
                      <img
                        src={product.image}
                        alt={product.name}
                        className="w-full h-full object-contain p-2 group-hover:scale-102 transition-transform duration-200"
                        referrerPolicy="no-referrer"
                        onError={(e) => {
                          e.currentTarget.style.display = 'none';
                        }}
                      />
                      {/* Styled CSS Fallback box */}
                      <div className="absolute inset-0 bg-[#E5E5E5] flex flex-col items-center justify-center p-4 text-center select-none pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity duration-200">
                        <span className="text-xs font-mono font-bold text-slate-600 uppercase tracking-widest mb-1">
                          {product.brand}
                        </span>
                        <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                          {product.packSize}
                        </span>
                      </div>
                    </div>

                    {/* Meta info area */}
                    <div className="flex-1 flex flex-col text-left justify-center w-full">
                      <div className="flex items-center gap-2 text-[11px] font-bold text-slate-500 tracking-wider uppercase mb-1">
                        <span>{product.brand}</span>
                        <span>·</span>
                        <span>{product.category}</span>
                      </div>

                      <h3
                        onClick={() => onSelectProduct(product)}
                        className={cn(
                          "font-black tracking-tight text-slate-900 uppercase cursor-pointer hover:text-[#005691] transition-colors leading-tight mb-2 text-wrap-balance",
                          isLargeCard ? "text-lg md:text-xl" : "text-base"
                        )}
                      >
                        {product.name}
                      </h3>

                      <div className="flex items-center gap-2 text-xs text-slate-500 mb-3">
                        <span className="font-semibold text-slate-800">{product.packSize}</span>
                        <span>|</span>
                        <span className="font-mono text-[11px]">{product.unitQuantity}</span>
                      </div>

                      {/* Ratings and availability */}
                      <div className="flex items-center gap-4 mb-4">
                        <div className="flex items-center text-yellow-500">
                          <Star className="w-3.5 h-3.5 fill-current" />
                          <span className="text-xs font-bold text-slate-800 ml-1">{product.rating}</span>
                          <span className="text-[10px] text-slate-400 font-mono ml-1">({product.reviewsCount})</span>
                        </div>
                        <span className={cn(
                          "text-[10px] font-bold tracking-wider px-1.5 py-0.5 font-mono",
                          product.availability === 'IN STOCK' ? 'text-green-600 bg-green-50' :
                          product.availability === 'LOW STOCK' ? 'text-amber-600 bg-amber-50' : 'text-red-600 bg-red-50'
                        )}>
                          {product.availability}
                        </span>
                      </div>

                      {/* Large Card special details */}
                      {isLargeCard && (
                        <p className="text-xs text-slate-600 mb-4 line-clamp-3 leading-relaxed hidden md:block">
                          {product.description}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Pricing and CTAs bottom block */}
                  <div className="border-t border-slate-100 p-6 bg-slate-50/50 flex flex-col justify-between">
                    <div className="flex justify-between items-end mb-4">
                      {/* Price labels */}
                      <div className="text-left">
                        {product.previousPrice && (
                          <div className="text-xs text-slate-500 line-through font-mono">
                            ${product.previousPrice.toFixed(2)}
                          </div>
                        )}
                        <div className="flex items-baseline gap-1.5">
                          <span className="text-2xl md:text-3xl font-black font-mono text-slate-900 tracking-tight">
                            ${product.memberPrice.toFixed(2)}
                          </span>
                          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                            Member Price
                          </span>
                        </div>
                        {product.savings && (
                          <span className="text-xs font-black text-[#E31B23] uppercase tracking-wider block mt-0.5">
                            Instant Savings: Save ${product.savings.toFixed(2)}
                          </span>
                        )}
                      </div>

                      {/* Fulfilment info */}
                      <div className="text-right text-[10px] text-slate-500 font-medium">
                        <div className="font-semibold text-slate-700">{product.deliveryIndicator}</div>
                        <div className="mt-0.5 font-mono">{product.warehouseAisle}</div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <button
                        onClick={() => onSelectProduct(product)}
                        className="flex-1 bg-white border border-slate-300 hover:border-slate-500 text-slate-800 text-xs font-extrabold uppercase tracking-widest py-3 text-center transition-colors cursor-pointer"
                      >
                        Specifications
                      </button>
                      <button
                        onClick={() => onAddToCart(product)}
                        disabled={product.availability === 'OUT OF STOCK'}
                        className="bg-[#E31B23] hover:bg-red-700 disabled:bg-slate-300 text-white font-extrabold text-xs uppercase tracking-widest px-4 py-3 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                      >
                        <ShoppingCart className="w-4 h-4" />
                        Add
                      </button>
                    </div>
                  </div>

                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
