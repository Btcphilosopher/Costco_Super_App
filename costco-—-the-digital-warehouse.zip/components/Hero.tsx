'use client';

import React from 'react';
import { ArrowRight, Compass, ShieldCheck, Sparkles, Tag } from 'lucide-react';
import { motion } from 'motion/react';

interface HeroProps {
  onShopNow: () => void;
  onSeeDeals: () => void;
  onOpenTreasureHunt: () => void;
}

export default function Hero({ onShopNow, onSeeDeals, onOpenTreasureHunt }: HeroProps) {
  return (
    <div className="relative bg-[#1F1F1F] text-white overflow-hidden border-b border-slate-300">
      {/* Structural geometric grid background to simulate industrial warehouse shelving */}
      <div className="absolute inset-0 opacity-15 pointer-events-none">
        <div className="absolute inset-0" style={{
          backgroundImage: `linear-gradient(to right, #ffffff 1px, transparent 1px), linear-gradient(to bottom, #ffffff 1px, transparent 1px)`,
          backgroundSize: '80px 80px'
        }} />
        {/* Abstract structural steel supports */}
        <div className="absolute top-0 left-1/4 w-[2px] h-full bg-white opacity-20" />
        <div className="absolute top-0 left-2/4 w-[2px] h-full bg-white opacity-25" />
        <div className="absolute top-0 left-3/4 w-[2px] h-full bg-white opacity-20" />
        <div className="absolute top-1/2 left-0 w-full h-[2px] bg-white opacity-30" />
      </div>

      {/* Decorative gradient scrim */}
      <div className="absolute inset-0 bg-gradient-to-r from-black via-black/85 to-transparent z-10" />

      {/* Hero background image - Sourced via Picsum with safe fallback */}
      <div className="absolute right-0 top-0 w-full lg:w-1/2 h-full opacity-40 lg:opacity-60 pointer-events-none">
        {/* Direct image tag with referrerPolicy */}
        <img
          src="https://images.unsplash.com/photo-1542838132-92c53300491e?w=1600&auto=format&fit=crop&q=80"
          alt="Costco Warehouse Shelving"
          className="w-full h-full object-cover object-center"
          referrerPolicy="no-referrer"
          onError={(e) => {
            // Soft fallback if image fails to load
            e.currentTarget.style.display = 'none';
          }}
        />
        {/* Stainless Steel / Concrete overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#1F1F1F] via-transparent to-transparent" />
      </div>

      {/* Content wrapper */}
      <div className="relative z-20 max-w-7xl mx-auto px-6 py-16 lg:py-24 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        {/* Left column: Text messaging */}
        <div className="lg:col-span-7 flex flex-col items-start text-left">
          {/* Warehouse tag */}
          <div className="inline-flex items-center gap-2 bg-[#E31B23] text-white px-3 py-1 text-xs font-bold uppercase tracking-widest mb-6 border border-red-500 rounded-none shadow-sm animate-pulse">
            <Tag className="w-3.5 h-3.5" />
            Kirkland Signature & Member Savings Event
          </div>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-black tracking-tight leading-none text-white uppercase text-wrap-balance mb-6">
            BIG SAVINGS.<br />
            <span className="text-[#005691]">BIGGER CHOICES.</span>
          </h1>

          <p className="text-slate-300 text-base md:text-lg max-w-xl mb-8 leading-relaxed">
            Member-only value on thousands of products, from everyday industrial bulk essentials to 
            high-end luxury items you didn&apos;t know you needed. Unpretentious. Permanent. Exceptional.
          </p>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-4 w-full sm:w-auto">
            <button
              onClick={onShopNow}
              className="bg-[#E31B23] hover:bg-red-700 text-white font-bold px-8 py-4 text-sm tracking-widest uppercase transition-all duration-150 rounded-none shadow-lg text-center flex items-center justify-center gap-2 cursor-pointer group"
            >
              Shop The Warehouse
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={onSeeDeals}
              className="bg-transparent border-2 border-white hover:bg-white hover:text-slate-900 text-white font-bold px-8 py-4 text-sm tracking-widest uppercase transition-all duration-150 rounded-none text-center cursor-pointer"
            >
              See Today&apos;s Deals
            </button>
          </div>

          {/* Quick core metrics / indicators */}
          <div className="grid grid-cols-3 gap-6 border-t border-slate-700/60 mt-12 pt-8 w-full max-w-xl">
            <div>
              <div className="text-2xl md:text-3xl font-black font-mono text-white tracking-tight">100%</div>
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-1">Satisfaction Guarantee</div>
            </div>
            <div>
              <div className="text-2xl md:text-3xl font-black font-mono text-[#005691] tracking-tight">2-DAY</div>
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-1">Standard Delivery</div>
            </div>
            <div>
              <div className="text-2xl md:text-3xl font-black font-mono text-white tracking-tight">2%</div>
              <div className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mt-1">Executive Cash Back</div>
            </div>
          </div>
        </div>

        {/* Right column: The Treasure Hunt Highlight Box */}
        <div className="lg:col-span-5">
          <div className="bg-[#2B2B2B] border border-slate-700 p-6 shadow-2xl relative group overflow-hidden">
            {/* Absolute indicator */}
            <div className="absolute top-0 right-0 bg-[#005691] text-white px-3 py-1 text-[10px] font-black uppercase tracking-wider">
              Treasure Hunt
            </div>

            <div className="flex items-center gap-2 text-yellow-500 mb-3">
              <Sparkles className="w-4 h-4 fill-current" />
              <span className="text-[11px] font-bold uppercase tracking-widest text-yellow-500">
                Unexpected Discoveries
              </span>
            </div>

            <h3 className="text-lg font-bold uppercase text-white mb-2 leading-snug">
              Lever Espresso Maker
            </h3>
            <p className="text-slate-400 text-xs mb-4">
              Imported directly from Milan, Italy. We came for paper towels and found an absolute luxury espresso masterpiece.
            </p>

            {/* Product teaser display */}
            <div className="relative aspect-video bg-[#1F1F1F] mb-4 border border-slate-700 overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1517142089942-ba376ce32a2e?w=500&auto=format&fit=crop&q=60"
                alt="La Pavoni lever espresso machine"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              <div className="absolute bottom-2 left-2 bg-slate-900/90 text-white px-2 py-1 font-mono text-sm font-bold border border-slate-700">
                $599.99 <span className="text-xs text-green-400 font-semibold font-sans">Save $150</span>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                SKU: PAV-LEVER-09
              </span>
              <button
                onClick={onOpenTreasureHunt}
                className="text-xs font-bold text-[#005691] hover:text-[#003f6b] flex items-center gap-1.5 transition-colors uppercase tracking-wider cursor-pointer"
              >
                Hunt For More →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
