'use client';

import React from 'react';
import { Product } from '@/lib/data';
import { Sparkles, ShoppingCart, Info, Star, Compass, AlertCircle, HelpCircle } from 'lucide-react';
import { cn } from '@/lib/utils';

interface TreasureHuntProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
}

export default function TreasureHunt({
  products,
  onAddToCart,
  onSelectProduct,
}: TreasureHuntProps) {
  // Filter products belonging to Treasure Hunt
  const huntProducts = products.filter(p => p.isTreasureHunt || p.id === '7' || p.id === '8' || p.id === '9');

  return (
    <div className="py-12 bg-slate-900 text-white px-6 border-b border-yellow-600 relative overflow-hidden">
      
      {/* Decorative starry / sparkle indicators */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-[#005691] opacity-10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-[#E31B23] opacity-10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto relative z-10">
        
        {/* Editorial Heading */}
        <div className="text-center mb-12 max-w-2xl mx-auto">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-yellow-500 text-slate-900 text-xs font-black uppercase tracking-widest mb-4">
            <Sparkles className="w-3.5 h-3.5 fill-current" />
            The Famous Costco Moment
          </div>
          <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tight leading-none mb-4">
            THE DIGITAL <span className="text-yellow-500">TREASURE HUNT</span>
          </h2>
          <p className="text-slate-400 text-sm md:text-base text-wrap-balance">
            &ldquo;You came for toilet paper. You discovered a professional level espresso machine.&rdquo;
            Browse our rotating selection of unexpected, seasonal luxury imports.
          </p>
        </div>

        {/* Highlight Banner / Story Section */}
        <div className="bg-[#1F1F1F] border border-slate-800 p-8 mb-12 text-left grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-7">
            <h3 className="text-xl md:text-2xl font-extrabold uppercase text-yellow-500 mb-2">
              WHY THE TREASURE HUNT WORKS
            </h3>
            <p className="text-slate-300 text-sm leading-relaxed mb-4">
              Costco does not employ traditional advertising. Instead, we use our immense global purchasing power to acquire limited quantities of ultra-premium goods—designer luggage, watches, top-tier audio, high-end Italian housewares—and pass the direct container savings straight to you.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 text-xs font-semibold uppercase tracking-wider text-slate-400">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-green-500" />
                Rotating Weekly Stocks
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-yellow-500" />
                Unbeatable Manufacturer Rebates
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-[#005691]" />
                100% Import Authenticity
              </div>
            </div>
          </div>
          
          <div className="lg:col-span-5 bg-yellow-500 text-slate-900 p-6 flex flex-col justify-center items-start text-left relative">
            <Compass className="w-12 h-12 text-slate-800/25 absolute top-4 right-4" />
            <h4 className="font-black text-sm uppercase tracking-widest mb-1 text-slate-900">
              WAREHOUSE ADVISORY
            </h4>
            <p className="text-xs text-slate-900/90 leading-relaxed font-semibold">
              These products sell out rapidly. Due to high volume demand and limited bulk containers, we cannot guarantee stock replenishments on endcaps. Buy it when you see it.
            </p>
          </div>
        </div>

        {/* Grid of Treasure Hunt items */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {huntProducts.map((product) => (
            <div
              key={product.id}
              className="bg-[#1F1F1F] border border-slate-800 flex flex-col justify-between group overflow-hidden relative transition-all hover:border-yellow-500 hover:shadow-2xl text-left"
            >
              {/* Product Card Top */}
              <div>
                <div className="relative aspect-video w-full bg-white overflow-hidden flex items-center justify-center p-2">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="max-h-full max-w-full object-contain group-hover:scale-102 transition-transform duration-300"
                    referrerPolicy="no-referrer"
                  />
                  {/* Overlay badge */}
                  <span className="absolute top-2 right-2 bg-yellow-500 text-slate-900 text-[9px] font-black uppercase tracking-widest px-2 py-0.5">
                    Import Highlight
                  </span>
                </div>

                <div className="p-6">
                  <div className="flex items-center gap-1.5 text-[10px] text-yellow-500 font-bold uppercase tracking-wider mb-1">
                    <span>{product.brand}</span>
                    <span>·</span>
                    <span>{product.category}</span>
                  </div>

                  <h4 className="text-lg font-bold uppercase text-white mb-2 leading-tight group-hover:text-yellow-500 transition-colors">
                    {product.name}
                  </h4>

                  <p className="text-xs text-slate-400 mb-4 line-clamp-2">
                    {product.description}
                  </p>

                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex text-yellow-500">
                      <Star className="w-3.5 h-3.5 fill-current" />
                      <span className="text-xs font-bold text-slate-200 ml-1">{product.rating}</span>
                    </div>
                    <span className="text-slate-600">·</span>
                    <span className="text-xs text-slate-400 font-mono">{product.packSize}</span>
                  </div>
                </div>
              </div>

              {/* Product Card Price & Action bottom */}
              <div className="border-t border-slate-800 p-6 bg-slate-950/40">
                <div className="flex justify-between items-end mb-4">
                  <div className="text-left">
                    {product.previousPrice && (
                      <span className="text-xs text-slate-500 line-through block font-mono">
                        ${product.previousPrice.toFixed(2)}
                      </span>
                    )}
                    <span className="text-2xl font-black font-mono text-white tracking-tight">
                      ${product.memberPrice.toFixed(2)}
                    </span>
                    <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider ml-1.5 align-super">
                      Member Price
                    </span>
                  </div>

                  <span className="text-[10px] font-bold text-slate-400 font-mono">
                    {product.warehouseAisle}
                  </span>
                </div>

                <div className="flex gap-2">
                  <button
                    onClick={() => onSelectProduct(product)}
                    className="flex-1 bg-transparent border border-slate-700 hover:border-slate-500 text-slate-300 text-xs font-bold uppercase tracking-wider py-2.5 transition-colors cursor-pointer"
                  >
                    View Specs
                  </button>
                  <button
                    onClick={() => onAddToCart(product)}
                    className="bg-[#E31B23] hover:bg-red-700 text-white font-extrabold text-xs uppercase tracking-widest px-4 py-2.5 flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <ShoppingCart className="w-3.5 h-3.5" />
                    Secure Box
                  </button>
                </div>
              </div>

            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
