'use client';

import React, { useState } from 'react';
import { SERVICES_DIRECTORY, CostcoService } from '@/lib/data';
import { Wrench, Shield, Check, Calendar, Activity, Info } from 'lucide-react';
import { cn } from '@/lib/utils';

interface ServicesSectionProps {
  onBookAppointment: (serviceName: string, date: string, time: string, warehouseName: string) => void;
  selectedWarehouseName: string;
}

export default function ServicesSection({
  onBookAppointment,
  selectedWarehouseName,
}: ServicesSectionProps) {
  const [activeService, setActiveService] = useState<CostcoService | null>(null);
  const [bookingDate, setBookingDate] = useState('');
  const [bookingTime, setBookingTime] = useState('10:00 AM');
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activeService || !bookingDate) return;
    
    onBookAppointment(activeService.name, bookingDate, bookingTime, selectedWarehouseName);
    setShowSuccessMessage(true);
    setTimeout(() => {
      setShowSuccessMessage(false);
      setActiveService(null);
      setBookingDate('');
    }, 2500);
  };

  return (
    <div className="bg-white py-14 px-6 border-b border-slate-200 text-left">
      <div className="max-w-7xl mx-auto">
        
        {/* Title row */}
        <div className="border-b-4 border-slate-900 pb-4 mb-10">
          <span className="text-xs font-black uppercase tracking-widest text-slate-500 block mb-1">
            Costco Business & Personal Utilities
          </span>
          <h2 className="text-3xl md:text-5xl font-black uppercase tracking-tight text-slate-900">
            WAREHOUSE SERVICES DIRECTORY
          </h2>
          <p className="text-slate-600 text-xs md:text-sm mt-1 max-w-xl">
            We operate fully equipped professional hubs inside our warehouses. As a member, you get access to licensed professionals and pre-negotiated auto insurance policies.
          </p>
        </div>

        {/* Services grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {SERVICES_DIRECTORY.map((srv) => (
            <div
              key={srv.id}
              className="bg-slate-50 border border-slate-200 p-8 flex flex-col justify-between hover:border-slate-400 hover:shadow-sm transition-all"
            >
              <div>
                <h3 className="text-xl font-black uppercase text-slate-900 tracking-tight mb-2">
                  {srv.name}
                </h3>
                <p className="text-slate-500 text-xs font-bold uppercase tracking-wider mb-4 text-[#005691]">
                  {srv.shortDescription}
                </p>
                <p className="text-slate-600 text-xs leading-relaxed mb-6">
                  {srv.longDescription}
                </p>

                <div className="border-t border-slate-200 pt-4 mb-6">
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-3">
                    Exclusive Member Benefits Included
                  </h4>
                  <ul className="flex flex-col gap-2.5 text-xs text-slate-700">
                    {srv.benefits.map((benefit, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-green-600 shrink-0 mt-0.5" />
                        <span>{benefit}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Booking trigger action */}
              <button
                onClick={() => setActiveService(srv)}
                className="w-full bg-[#005691] hover:bg-[#003f6b] text-white font-extrabold text-xs uppercase tracking-widest py-3 text-center cursor-pointer transition-colors"
              >
                {srv.ctaText}
              </button>
            </div>
          ))}
        </div>

        {/* Appointment Scheduler modal form */}
        {activeService && (
          <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
            <div className="bg-white border-2 border-slate-300 p-6 w-full max-w-md relative shadow-2xl">
              
              <button
                onClick={() => setActiveService(null)}
                className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>

              <div className="text-left mb-6">
                <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block mb-1">
                  SECURE APPOINTMENT PORTAL
                </span>
                <h3 className="text-lg font-black uppercase text-slate-900">
                  Book {activeService.name}
                </h3>
                <p className="text-xs text-slate-500 mt-1">
                  Scheduling at: <strong className="text-slate-900">{selectedWarehouseName} Warehouse</strong>
                </p>
              </div>

              {showSuccessMessage ? (
                <div className="bg-green-50 border border-green-200 p-6 text-center text-green-800">
                  <Check className="w-8 h-8 text-green-600 mx-auto mb-3" />
                  <h4 className="font-bold text-sm uppercase">Appointment Scheduled</h4>
                  <p className="text-xs text-green-600 mt-1">
                    Your spot is secure. Details synced to your My Costco dashboard.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleBookingSubmit} className="flex flex-col gap-4 text-xs">
                  <div>
                    <label className="block text-slate-700 font-bold uppercase tracking-wide mb-1.5">
                      Select Date
                    </label>
                    <input
                      type="date"
                      required
                      value={bookingDate}
                      onChange={(e) => setBookingDate(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 p-2.5 outline-none font-mono text-sm focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-bold uppercase tracking-wide mb-1.5">
                      Select Slot Time
                    </label>
                    <select
                      value={bookingTime}
                      onChange={(e) => setBookingTime(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 p-2.5 outline-none font-mono text-sm focus:bg-white cursor-pointer"
                    >
                      <option value="09:00 AM">09:00 AM</option>
                      <option value="10:30 AM">10:30 AM</option>
                      <option value="12:00 PM">12:00 PM</option>
                      <option value="02:00 PM">02:00 PM</option>
                      <option value="03:30 PM">03:30 PM</option>
                      <option value="05:00 PM">05:00 PM</option>
                    </select>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 p-4 text-[11px] text-slate-500 leading-normal">
                    * Optometrists and Automotive technicians are fully licensed. Please arrive 10 minutes prior to your slot with your physical membership card.
                  </div>

                  <button
                    type="submit"
                    className="bg-[#E31B23] hover:bg-red-700 text-white font-extrabold uppercase tracking-widest py-3 text-center cursor-pointer transition-colors"
                  >
                    Confirm Appointment Slot
                  </button>
                </form>
              )}

            </div>
          </div>
        )}

      </div>
    </div>
  );
}
