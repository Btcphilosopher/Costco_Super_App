'use client';

import React, { useState } from 'react';
import { Product } from '@/lib/data';
import { BarChart, Grid, PlusCircle, CheckCircle, RefreshCw, Sliders, DollarSign, EyeOff } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AdminPanelProps {
  products: Product[];
  onUpdateProductPrice: (productId: string, newPrice: number) => void;
  onUpdateProductAvailability: (productId: string, availability: 'IN STOCK' | 'LOW STOCK' | 'OUT OF STOCK') => void;
  ordersCount: number;
  totalSales: number;
}

export default function AdminPanel({
  products,
  onUpdateProductPrice,
  onUpdateProductAvailability,
  ordersCount,
  totalSales,
}: AdminPanelProps) {
  const [activeRole, setActiveRole] = useState<'merchandising' | 'analytics'>('merchandising');
  
  // States for interactive editing
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [tempPrice, setTempPrice] = useState<string>('');
  const [tempStatus, setTempStatus] = useState<'IN STOCK' | 'LOW STOCK' | 'OUT OF STOCK'>('IN STOCK');

  const startEditing = (product: Product) => {
    setEditingProductId(product.id);
    setTempPrice(product.memberPrice.toString());
    setTempStatus(product.availability);
  };

  const saveProductChanges = (productId: string) => {
    const parsedPrice = parseFloat(tempPrice);
    if (!isNaN(parsedPrice) && parsedPrice > 0) {
      onUpdateProductPrice(productId, parsedPrice);
    }
    onUpdateProductAvailability(productId, tempStatus);
    setEditingProductId(null);
  };

  // Simulated metrics
  const conversionRate = "3.24%";
  const averageBasket = (totalSales / (ordersCount || 1)).toFixed(2);

  return (
    <div className="bg-[#F2F2F2] py-14 px-6 border-b border-slate-200 text-left">
      <div className="max-w-7xl mx-auto">
        
        {/* Title row */}
        <div className="bg-white border border-slate-300 p-8 mb-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="text-left">
            <span className="text-xs font-black uppercase tracking-widest text-[#E31B23] block mb-1">
              Internal Corporate Console
            </span>
            <h2 className="text-3xl font-black uppercase tracking-tight text-slate-900 leading-none">
              MY COSTCO ADMIN PANEL
            </h2>
            <p className="text-slate-500 text-xs mt-1.5 max-w-xl">
              Manage product pricing, instant savings, warehouse inventory levels, and track business conversion metrics in real-time.
            </p>
          </div>

          {/* Role segmented toggle */}
          <div className="flex bg-slate-100 p-1 border border-slate-200">
            <button
              onClick={() => setActiveRole('merchandising')}
              className={cn(
                "px-4 py-2 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer",
                activeRole === 'merchandising' ? "bg-white text-slate-900 shadow-xs" : "text-slate-600 hover:text-slate-900"
              )}
            >
              Merchandising
            </button>
            <button
              onClick={() => setActiveRole('analytics')}
              className={cn(
                "px-4 py-2 text-xs font-bold uppercase tracking-wider transition-all cursor-pointer",
                activeRole === 'analytics' ? "bg-white text-slate-900 shadow-xs" : "text-slate-600 hover:text-slate-900"
              )}
            >
              Analytics
            </button>
          </div>
        </div>

        {activeRole === 'merchandising' ? (
          /* Merchandising Role Component */
          <div className="bg-white border border-slate-300 p-6 shadow-sm">
            <h3 className="text-sm font-black uppercase text-slate-900 tracking-tight mb-4 flex items-center gap-2">
              <Sliders className="w-4.5 h-4.5 text-[#005691]" />
              WAREHOUSE PALLET INVENTORY CONTROL
            </h3>
            
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="bg-slate-100 border-b border-slate-200 text-slate-600 uppercase font-black tracking-wider text-[10px]">
                    <th className="px-4 py-3">Product Description</th>
                    <th className="px-4 py-3 text-right">Pack Size</th>
                    <th className="px-4 py-3 text-right">Aisle Location</th>
                    <th className="px-4 py-3 text-right">Member Price</th>
                    <th className="px-4 py-3 text-right">Inventory Status</th>
                    <th className="px-4 py-3 text-right">Corporate Controls</th>
                  </tr>
                </thead>
                <tbody>
                  {products.map((product, index) => {
                    const isEditing = editingProductId === product.id;
                    return (
                      <tr
                        key={product.id}
                        className={cn(
                          "border-b border-slate-200 hover:bg-slate-50/50",
                          index % 2 === 1 ? "bg-slate-50/20" : "bg-white"
                        )}
                      >
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2">
                            <strong className="font-extrabold text-slate-900 uppercase">
                              {product.brand}
                            </strong>
                            <span className="text-slate-600 font-medium">{product.name}</span>
                          </div>
                        </td>
                        <td className="px-4 py-3 text-right font-semibold text-slate-600">
                          {product.packSize}
                        </td>
                        <td className="px-4 py-3 text-right font-mono text-slate-500">
                          {product.warehouseAisle}
                        </td>
                        <td className="px-4 py-3 text-right font-mono font-bold text-slate-900">
                          {isEditing ? (
                            <input
                              type="number"
                              step="0.01"
                              value={tempPrice}
                              onChange={(e) => setTempPrice(e.target.value)}
                              className="w-20 border border-slate-300 p-1 text-right font-mono"
                            />
                          ) : (
                            `$${product.memberPrice.toFixed(2)}`
                          )}
                        </td>
                        <td className="px-4 py-3 text-right">
                          {isEditing ? (
                            <select
                              value={tempStatus}
                              onChange={(e) => setTempStatus(e.target.value as any)}
                              className="border border-slate-300 p-1 font-mono text-xs cursor-pointer"
                            >
                              <option value="IN STOCK">IN STOCK</option>
                              <option value="LOW STOCK">LOW STOCK</option>
                              <option value="OUT OF STOCK">OUT OF STOCK</option>
                            </select>
                          ) : (
                            <span className={cn(
                              "font-bold px-1.5 py-0.5",
                              product.availability === 'IN STOCK' ? 'text-green-600 bg-green-50' :
                              product.availability === 'LOW STOCK' ? 'text-amber-600 bg-amber-50' : 'text-red-600 bg-red-50'
                            )}>
                              {product.availability}
                            </span>
                          )}
                        </td>
                        <td className="px-4 py-3 text-right">
                          {isEditing ? (
                            <div className="flex justify-end gap-1.5">
                              <button
                                onClick={() => saveProductChanges(product.id)}
                                className="bg-green-600 hover:bg-green-700 text-white font-extrabold uppercase px-2.5 py-1 tracking-wider cursor-pointer"
                              >
                                Save
                              </button>
                              <button
                                onClick={() => setEditingProductId(null)}
                                className="bg-slate-200 hover:bg-slate-300 text-slate-700 font-extrabold uppercase px-2.5 py-1 tracking-wider cursor-pointer"
                              >
                                X
                              </button>
                            </div>
                          ) : (
                            <button
                              onClick={() => startEditing(product)}
                              className="border border-slate-300 hover:border-slate-500 text-slate-700 font-extrabold uppercase px-2.5 py-1 tracking-wider cursor-pointer"
                            >
                              Edit
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        ) : (
          /* Sales Analytics Dashboard */
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <div className="bg-white border border-slate-300 p-6 shadow-sm">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Total Sales Revenue</span>
              <span className="text-3xl font-black font-mono text-slate-900 mt-2 block">
                ${totalSales.toFixed(2)}
              </span>
              <div className="w-full h-1.5 bg-slate-100 rounded-full mt-4 overflow-hidden">
                <div className="h-full bg-green-500 rounded-full" style={{ width: '65%' }} />
              </div>
              <span className="text-[10px] text-slate-500 font-medium block mt-2">65% of monthly corporate target.</span>
            </div>

            <div className="bg-white border border-slate-300 p-6 shadow-sm">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Order Invoices Count</span>
              <span className="text-3xl font-black font-mono text-slate-900 mt-2 block">
                {ordersCount}
              </span>
              <div className="w-full h-1.5 bg-slate-100 rounded-full mt-4 overflow-hidden">
                <div className="h-full bg-[#005691] rounded-full" style={{ width: '45%' }} />
              </div>
              <span className="text-[10px] text-slate-500 font-medium block mt-2">Includes both online and food court.</span>
            </div>

            <div className="bg-white border border-slate-300 p-6 shadow-sm">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Average Basket Size</span>
              <span className="text-3xl font-black font-mono text-slate-900 mt-2 block">
                ${averageBasket}
              </span>
              <div className="w-full h-1.5 bg-slate-100 rounded-full mt-4 overflow-hidden">
                <div className="h-full bg-yellow-500 rounded-full" style={{ width: '75%' }} />
              </div>
              <span className="text-[10px] text-slate-500 font-medium block mt-2">Reflects high-volume bulk purchase model.</span>
            </div>

            <div className="bg-white border border-slate-300 p-6 shadow-sm">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest block">Cart Conversion Rate</span>
              <span className="text-3xl font-black font-mono text-slate-900 mt-2 block">
                {conversionRate}
              </span>
              <div className="w-full h-1.5 bg-slate-100 rounded-full mt-4 overflow-hidden">
                <div className="h-full bg-[#E31B23] rounded-full" style={{ width: '80%' }} />
              </div>
              <span className="text-[10px] text-slate-500 font-medium block mt-2">Excellent performance compared to retail industry.</span>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
