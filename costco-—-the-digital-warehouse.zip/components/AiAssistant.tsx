'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Bot, Send, Sparkles, X, ChevronRight, CornerDownRight, RefreshCcw } from 'lucide-react';
import { cn } from '@/lib/utils';

interface AiAssistantProps {
  isOpen: boolean;
  onClose: () => void;
}

interface Message {
  role: 'user' | 'assistant' | 'system';
  text: string;
}

export default function AiAssistant({ isOpen, onClose }: AiAssistantProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      text: "Hello! I am your official Costco Digital Warehouse Shopping Assistant. I operate strictly on our current inventory list. Ask me about finding bulk recipes, picking a high-end OLED TV, or exploring Kirkland Signature savings!"
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const suggestedQueries = [
    { label: "Feed 20 People", prompt: "I need to feed 20 people this weekend from the warehouse. What bulk items should I buy?" },
    { label: "Kirkland Under $50", prompt: "Show me Kirkland Signature products under $50 and explain their value." },
    { label: "Bright Room TV", prompt: "I need a TV for a bright living room. What do you recommend?" },
  ];

  const handleSend = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMsg: Message = { role: 'user', text: textToSend };
    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/gemini', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt: textToSend, chatHistory: messages }),
      });

      const data = await response.json();
      
      if (response.ok && data.text) {
        setMessages((prev) => [...prev, { role: 'assistant', text: data.text }]);
      } else {
        setMessages((prev) => [
          ...prev,
          { role: 'assistant', text: "I apologize, our warehouse inventory queries are momentarily offline. Please try again in a second." }
        ]);
      }
    } catch (error) {
      console.error("AI Assistant Error:", error);
      setMessages((prev) => [
        ...prev,
        { role: 'assistant', text: "A communication error occurred connecting to our pricing servers. Please retry." }
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  // Scroll to bottom when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-y-0 right-0 w-full sm:w-96 bg-[#1F1F1F] text-white z-50 shadow-2xl flex flex-col justify-between border-l-2 border-slate-700">
      
      {/* Header bar */}
      <div className="p-4 bg-slate-900 border-b border-slate-800 flex justify-between items-center shrink-0">
        <div className="flex items-center gap-2 text-left">
          <Bot className="w-5 h-5 text-yellow-500" />
          <div>
            <h3 className="font-extrabold text-sm uppercase text-white tracking-wider flex items-center gap-1">
              WHS ASSISTANT
              <span className="text-[8px] bg-[#005691] px-1 py-0.2">GEMINI 3.8</span>
            </h3>
            <span className="text-[10px] text-slate-400 font-semibold uppercase">COSTCO-DESIGN-DEMO-001</span>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-1 hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Messages body */}
      <div className="flex-1 p-4 overflow-y-auto space-y-4 flex flex-col text-left">
        {messages.map((msg, idx) => (
          <div
            key={idx}
            className={cn(
              "p-3.5 text-xs leading-relaxed max-w-[85%] relative",
              msg.role === 'user'
                ? "bg-[#005691] text-white self-end border-l-4 border-blue-400"
                : "bg-[#2B2B2B] text-slate-200 self-start border-l-4 border-yellow-500"
            )}
          >
            {/* Simple Markdown Render Support */}
            <div className="whitespace-pre-line font-medium prose prose-invert prose-xs">
              {msg.text}
            </div>
            <span className="absolute bottom-1 right-2 text-[8px] text-slate-500 font-mono select-none">
              {msg.role === 'user' ? 'Member' : 'WHS'}
            </span>
          </div>
        ))}

        {isLoading && (
          <div className="p-3 bg-[#2B2B2B] text-slate-400 text-xs self-start italic border-l-4 border-yellow-500 flex items-center gap-2">
            <RefreshCcw className="w-3.5 h-3.5 animate-spin text-yellow-500" />
            Querying warehouse inventory...
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Prefilled Prompt Suggestions Shelf */}
      <div className="p-3 bg-slate-900 border-t border-slate-800 shrink-0 text-left">
        <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest block mb-2">
          Suggested Member Inquiries
        </span>
        <div className="flex flex-col gap-1.5">
          {suggestedQueries.map((q) => (
            <button
              key={q.label}
              onClick={() => handleSend(q.prompt)}
              disabled={isLoading}
              className="text-left text-xs bg-[#2B2B2B] hover:bg-slate-800 text-slate-200 hover:text-yellow-500 px-3 py-2 border border-slate-800 transition-colors cursor-pointer flex items-center justify-between"
            >
              <span className="font-semibold">{q.label}</span>
              <ChevronRight className="w-3.5 h-3.5 text-slate-500" />
            </button>
          ))}
        </div>
      </div>

      {/* Input controls */}
      <form
        onSubmit={(e) => {
          e.preventDefault();
          handleSend(input);
        }}
        className="p-3 bg-[#1F1F1F] border-t border-slate-800 shrink-0 flex gap-2"
      >
        <input
          type="text"
          placeholder="Ask about bulk, specs, or savings..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          disabled={isLoading}
          className="flex-1 bg-[#2B2B2B] border border-slate-700 focus:border-slate-500 px-3 py-2 text-xs text-white placeholder-slate-500 outline-none"
        />
        <button
          type="submit"
          disabled={isLoading || !input.trim()}
          className="bg-[#E31B23] hover:bg-red-700 disabled:bg-slate-800 p-2 text-white transition-colors cursor-pointer flex items-center justify-center shrink-0"
        >
          <Send className="w-4 h-4" />
        </button>
      </form>

    </div>
  );
}
