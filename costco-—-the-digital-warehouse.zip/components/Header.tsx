'use client';

import React, { useState } from 'react';
import { Search, ShoppingCart, User, MapPin, Grid, Layers, Compass } from 'lucide-react';
import { cn } from '@/lib/utils';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  cartCount: number;
  onOpenCart: () => void;
  onOpenAiAssistant: () => void;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  selectedWarehouseName: string;
  onOpenWarehouseSelector: () => void;
  warehouseMode: boolean;
}

export default function Header({
  activeTab,
  setActiveTab,
  cartCount,
  onOpenCart,
  onOpenAiAssistant,
  searchQuery,
  setSearchQuery,
  selectedWarehouseName,
  onOpenWarehouseSelector,
  warehouseMode,
}: HeaderProps) {
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);

  const navLinks = [
    { id: 'shop', label: 'Shop' },
    { id: 'deals', label: 'Deals' },
    { id: 'kirkland', label: 'Kirkland' },
    { id: 'membership', label: 'Membership' },
    { id: 'warehouse', label: 'Warehouse' },
    { id: 'services', label: 'Services' },
  ];

  const popularSearches = [
    'coffee',
    'Kirkland Signature',
    'TVs',
    'toilet paper',
    'pizza',
    'organic olive oil',
  ];

  return (
    <>
      {/* Top micro-banner */}
      <div className="bg-[#1F1F1F] text-white text-[11px] py-1 px-4 flex justify-between items-center border-b border-slate-800 tracking-wide select-none">
        <div className="flex items-center gap-3">
          <span className="font-semibold text-[#E31B23]">DEMO MODE</span>
          <span className="text-slate-400">|</span>
          <span className="text-slate-300 font-mono">COSTCO-DESIGN-DEMO-001</span>
        </div>
        <div className="flex items-center gap-4">
          <button 
            onClick={onOpenWarehouseSelector}
            className="hover:text-[#005691] transition-colors flex items-center gap-1.5 cursor-pointer text-slate-300 text-[11px]"
          >
            <MapPin className="w-3.5 h-3.5 text-[#E31B23]" />
            Warehouse: <strong className="text-white underline">{selectedWarehouseName}</strong>
            {warehouseMode && (
              <span className="bg-[#005691] text-[9px] px-1.5 py-0.2 rounded-sm font-semibold tracking-wider animate-pulse">
                LOCAL INVENTORY MODE
              </span>
            )}
          </button>
          <span className="text-slate-600">|</span>
          <button 
            onClick={onOpenAiAssistant}
            className="hover:text-red-400 font-medium text-white transition-colors cursor-pointer"
          >
            Ask AI Assistant
          </button>
        </div>
      </div>

      {/* Primary Top Bar Contract Header */}
      <header className="sticky top-0 z-40 bg-white border-b border-slate-200 shadow-sm px-6 py-4 flex items-center justify-between">
        {/* Zone 1: Brand title, one line */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('shop')}
            className="text-[28px] font-extrabold tracking-tighter text-[#E31B23] select-none hover:opacity-90 cursor-pointer font-serif flex items-center gap-1"
          >
            COSTCO
            <span className="text-[10px] font-mono tracking-widest text-slate-500 font-semibold align-super ml-1 border border-slate-300 px-1 rounded">
              WHS
            </span>
          </button>
        </div>

        {/* Zone 2: 4-6 nav links, 1-2 word labels, single-line */}
        <nav className="hidden lg:flex items-center gap-8 text-sm font-semibold uppercase tracking-wider text-slate-700">
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => setActiveTab(link.id)}
              className={cn(
                "hover:text-[#E31B23] transition-colors relative py-1 cursor-pointer whitespace-nowrap shrink-0",
                activeTab === link.id ? "text-[#005691] after:absolute after:bottom-[-4px] after:left-0 after:w-full after:h-[3px] after:bg-[#005691]" : ""
              )}
            >
              {link.label}
            </button>
          ))}
          {/* Secondary links bundled under clean 'More' selector */}
          <div className="relative group">
            <button className="hover:text-[#E31B23] py-1 cursor-pointer whitespace-nowrap shrink-0">
              More +
            </button>
            <div className="absolute top-full left-0 mt-2 bg-white border border-slate-200 shadow-lg rounded-sm py-2 w-48 hidden group-hover:block transition-all z-50">
              <button onClick={() => setActiveTab('travel')} className="w-full text-left px-4 py-2 hover:bg-slate-50 text-xs font-semibold uppercase text-slate-700 hover:text-[#E31B23]">
                Costco Travel
              </button>
              <button onClick={() => setActiveTab('food-court')} className="w-full text-left px-4 py-2 hover:bg-slate-50 text-xs font-semibold uppercase text-slate-700 hover:text-[#E31B23]">
                Food Court
              </button>
              <button onClick={() => setActiveTab('admin')} className="w-full text-left px-4 py-2 hover:bg-slate-50 text-xs font-semibold uppercase text-slate-700 hover:text-[#E31B23]">
                Whs Admin
              </button>
            </div>
          </div>
        </nav>

        {/* Search Bar - Nested beautifully in Header for ultimate accessibility */}
        <div className="hidden md:flex flex-1 max-w-md mx-8 relative">
          <div className="relative w-full">
            <input
              type="text"
              placeholder="What are you looking for?"
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setShowSearchDropdown(true);
              }}
              onFocus={() => setShowSearchDropdown(true)}
              className="w-full bg-[#F2F2F2] border border-slate-300 focus:border-slate-500 focus:bg-white text-slate-900 placeholder-slate-500 text-sm px-4 py-2 pl-10 focus:outline-none transition-all rounded-none"
            />
            <Search className="w-4 h-4 text-slate-500 absolute left-3 top-3" />
          </div>

          {/* Autocomplete dropdown */}
          {showSearchDropdown && (
            <div className="absolute top-full left-0 w-full bg-white border border-slate-200 shadow-xl mt-1 z-50 p-4">
              <div className="flex justify-between items-center mb-3">
                <span className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">
                  Popular Warehouse Queries
                </span>
                <button
                  onClick={() => setShowSearchDropdown(false)}
                  className="text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
                >
                  Close
                </button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {popularSearches.map((term) => (
                  <button
                    key={term}
                    onClick={() => {
                      setSearchQuery(term);
                      setShowSearchDropdown(false);
                      setActiveTab('shop');
                    }}
                    className="text-left text-xs text-slate-700 hover:bg-slate-100 hover:text-[#005691] px-2 py-1.5 transition-colors cursor-pointer border border-transparent hover:border-slate-200"
                  >
                    {term}
                  </button>
                ))}
              </div>
              <div className="border-t border-slate-100 mt-3 pt-3 flex justify-between items-center">
                <span className="text-[10px] text-slate-400">
                  Try asking the AI Shopping Assistant for complex queries.
                </span>
                <button
                  onClick={() => {
                    setShowSearchDropdown(false);
                    onOpenAiAssistant();
                  }}
                  className="text-xs font-bold text-[#005691] hover:underline cursor-pointer"
                >
                  Open AI →
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-4">
          <button
            onClick={() => setActiveTab('account')}
            className={cn(
              "flex items-center gap-1.5 px-3 py-2 border text-sm font-semibold hover:border-slate-400 hover:bg-slate-50 transition-colors cursor-pointer",
              activeTab === 'account' ? 'border-[#005691] text-[#005691] bg-blue-50/20' : 'border-slate-300 text-slate-700'
            )}
          >
            <User className="w-4 h-4 text-slate-500" />
            <span className="hidden sm:inline whitespace-nowrap">My Costco</span>
          </button>

          <button
            onClick={onOpenCart}
            className="bg-[#005691] hover:bg-[#003f6b] text-white px-4 py-2 flex items-center gap-2 font-bold text-sm tracking-wide transition-colors cursor-pointer relative"
          >
            <ShoppingCart className="w-4 h-4" />
            <span className="hidden sm:inline">Cart</span>
            <span className="bg-[#E31B23] text-white text-[10px] w-5 h-5 flex items-center justify-center rounded-full font-mono font-bold absolute -top-2 -right-2 border border-white">
              {cartCount}
            </span>
          </button>
        </div>
      </header>
    </>
  );
}
