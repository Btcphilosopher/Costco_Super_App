'use client';

import React, { useState, useEffect } from 'react';
import Header from '@/components/Header';
import Hero from '@/components/Hero';
import CostcoGrid from '@/components/CostcoGrid';
import ProductDetailModal from '@/components/ProductDetailModal';
import TreasureHunt from '@/components/TreasureHunt';
import KirklandSection from '@/components/KirklandSection';
import MembershipSection from '@/components/MembershipSection';
import WarehouseFinder from '@/components/WarehouseFinder';
import ServicesSection from '@/components/ServicesSection';
import TravelSection from '@/components/TravelSection';
import FoodCourt from '@/components/FoodCourt';
import AccountSection from '@/components/AccountSection';
import AdminPanel from '@/components/AdminPanel';
import AiAssistant from '@/components/AiAssistant';
import CartDrawer from '@/components/CartDrawer';
import { PRODUCTS, WAREHOUSES, Product, Warehouse, MembershipTier } from '@/lib/data';
import { Search, MapPin, User, ShoppingBag, Grid, HelpCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion } from 'motion/react';

interface CartItem {
  product: Product;
  quantity: number;
}

interface Order {
  id: string;
  date: string;
  items: { name: string; quantity: number; price: number }[];
  total: number;
  status: 'PLACED' | 'CONFIRMED' | 'PROCESSING' | 'PICKED' | 'PACKED' | 'SHIPPED' | 'OUT FOR DELIVERY' | 'DELIVERED';
  type: 'ONLINE' | 'FOOD_COURT';
}

interface Appointment {
  serviceName: string;
  date: string;
  time: string;
  warehouseName: string;
}

export default function Home() {
  // Global States
  const [activeTab, setActiveTab] = useState<string>('shop');
  const [cart, setCart] = useState<CartItem[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedWarehouse, setSelectedWarehouse] = useState<Warehouse>(WAREHOUSES[0]);
  const [warehouseMode, setWarehouseMode] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeCategory, setActiveCategory] = useState<string>('all');

  // Drawer / Modal triggers
  const [isCartOpen, setIsCartOpen] = useState<boolean>(false);
  const [isAiOpen, setIsAiOpen] = useState<boolean>(false);
  const [showWarehouseSelector, setShowWarehouseSelector] = useState<boolean>(false);

  // Dynamic products list (can be manipulated in Admin Panel)
  const [warehouseProducts, setWarehouseProducts] = useState<Product[]>(PRODUCTS);

  // Scheduled appointments state
  const [appointments, setAppointments] = useState<Appointment[]>([
    {
      serviceName: 'Costco Optical Center Eye Exam',
      date: '2026-10-10',
      time: '10:30 AM',
      warehouseName: 'Seattle Downtown'
    }
  ]);

  // Order history state with standard seed order for nice initial visual
  const [orders, setOrders] = useState<Order[]>([
    {
      id: '1042',
      date: '2026-10-01',
      items: [
        { name: 'LG 65" Class OLED C4 Series 4K Smart TV', quantity: 1, price: 1499.99 },
        { name: 'Kirkland Signature Colombian Supreme Coffee Beans (1.36 kg)', quantity: 2, price: 18.99 }
      ],
      total: 1537.97,
      status: 'SHIPPED',
      type: 'ONLINE'
    }
  ]);

  // Settle pricing metrics
  const totalSales = orders.reduce((sum, o) => sum + o.total, 0);

  // Synchronize search trigger across pages
  const handleSelectProduct = (product: Product) => {
    setSelectedProduct(product);
  };

  const handleAddToCart = (product: Product) => {
    setCart((prev) => {
      const existing = prev.find((item) => item.product.id === product.id);
      if (existing) {
        return prev.map((item) =>
          item.product.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { product, quantity: 1 }];
    });
    // Visual feedback trigger
    setIsCartOpen(true);
  };

  const handleUpdateCartQuantity = (productId: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.product.id === productId) {
            const nextQty = item.quantity + delta;
            return { ...item, quantity: nextQty };
          }
          return item;
        })
        .filter((item) => item.quantity > 0)
    );
  };

  const handleClearCart = () => {
    setCart([]);
  };

  // Place online order submission
  const handlePlaceOrder = (items: { name: string; quantity: number; price: number }[], total: number) => {
    const newOrder: Order = {
      id: (Math.floor(Math.random() * 9000) + 1000).toString(),
      date: new Date().toISOString().split('T')[0],
      items,
      total,
      status: 'PLACED',
      type: 'ONLINE'
    };
    setOrders((prev) => [newOrder, ...prev]);
    setActiveTab('account');
  };

  // Place food court order
  const handlePlaceFoodCourtOrder = (items: { name: string; quantity: number; price: number }[], total: number) => {
    const newOrder: Order = {
      id: (Math.floor(Math.random() * 900) + 100).toString(),
      date: new Date().toISOString().split('T')[0],
      items,
      total,
      status: 'CONFIRMED',
      type: 'FOOD_COURT'
    };
    setOrders((prev) => [newOrder, ...prev]);
  };

  // Book service appointments
  const handleBookAppointment = (serviceName: string, date: string, time: string, warehouseName: string) => {
    const newAppt: Appointment = {
      serviceName,
      date,
      time,
      warehouseName,
    };
    setAppointments((prev) => [...prev, newAppt]);
  };

  // Join membership card click
  const handleJoinMembership = (tier: MembershipTier) => {
    alert(`Thank you for choosing Costco! Joining the ${tier.name} tier is simulated successfully.`);
  };

  // Admin adjustments
  const handleUpdateProductPrice = (productId: string, newPrice: number) => {
    setWarehouseProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, memberPrice: newPrice } : p))
    );
  };

  const handleUpdateProductAvailability = (productId: string, availability: 'IN STOCK' | 'LOW STOCK' | 'OUT OF STOCK') => {
    setWarehouseProducts((prev) =>
      prev.map((p) => (p.id === productId ? { ...p, availability } : p))
    );
  };

  // Switch tab helper for mobile / desktop
  const handleNavigateToShop = () => {
    setActiveTab('shop');
    setActiveCategory('all');
    setSearchQuery('');
  };

  return (
    <div className="min-h-screen bg-[#F2F2F2] flex flex-col font-sans select-none antialiased text-slate-800">
      
      {/* Primary header compliance zones */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        cartCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenAiAssistant={() => setIsAiOpen(true)}
        searchQuery={searchQuery}
        setSearchQuery={setSearchQuery}
        selectedWarehouseName={selectedWarehouse.name}
        onOpenWarehouseSelector={() => setShowWarehouseSelector(true)}
        warehouseMode={warehouseMode}
      />

      {/* Main content body wrapper */}
      <main className="flex-1 pb-24 md:pb-12">
        {activeTab === 'shop' && (
          <>
            {/* Show hero composition strictly on front shop page */}
            <Hero
              onShopNow={handleNavigateToShop}
              onSeeDeals={() => {
                setActiveTab('deals');
              }}
              onOpenTreasureHunt={() => {
                setActiveTab('deals');
              }}
            />
            
            {/* Costco grid container */}
            <CostcoGrid
              products={warehouseProducts}
              onAddToCart={handleAddToCart}
              onSelectProduct={handleSelectProduct}
              searchQuery={searchQuery}
              activeCategory={activeCategory}
              setActiveCategory={setActiveCategory}
              warehouseMode={warehouseMode}
            />
          </>
        )}

        {activeTab === 'deals' && (
          <>
            {/* Rotate Costco Moment Treasure Hunt shelf in deals view */}
            <TreasureHunt
              products={warehouseProducts}
              onAddToCart={handleAddToCart}
              onSelectProduct={handleSelectProduct}
            />
            {/* Costco grid constrained by discounts */}
            <CostcoGrid
              products={warehouseProducts}
              onAddToCart={handleAddToCart}
              onSelectProduct={handleSelectProduct}
              searchQuery={searchQuery}
              activeCategory={activeCategory}
              setActiveCategory={setActiveCategory}
              warehouseMode={warehouseMode}
            />
          </>
        )}

        {activeTab === 'kirkland' && (
          <KirklandSection
            products={warehouseProducts}
            onAddToCart={handleAddToCart}
            onSelectProduct={handleSelectProduct}
          />
        )}

        {activeTab === 'membership' && (
          <MembershipSection onJoinTier={handleJoinMembership} />
        )}

        {activeTab === 'warehouse' && (
          <WarehouseFinder
            onSelectWarehouse={setSelectedWarehouse}
            selectedWarehouse={selectedWarehouse}
            warehouseMode={warehouseMode}
            setWarehouseMode={setWarehouseMode}
          />
        )}

        {activeTab === 'services' && (
          <ServicesSection
            onBookAppointment={handleBookAppointment}
            selectedWarehouseName={selectedWarehouse.name}
          />
        )}

        {activeTab === 'travel' && (
          <TravelSection
            onBookPackage={(pkgName, price) => {
              // Create an automated order history package for luxury tracking!
              const newOrder: Order = {
                id: (Math.floor(Math.random() * 9000) + 1000).toString(),
                date: new Date().toISOString().split('T')[0],
                items: [{ name: `Travel: ${pkgName}`, quantity: 1, price }],
                total: price,
                status: 'PLACED',
                type: 'ONLINE'
              };
              setOrders((prev) => [newOrder, ...prev]);
            }}
          />
        )}

        {activeTab === 'food-court' && (
          <FoodCourt
            onPlaceFoodCourtOrder={handlePlaceFoodCourtOrder}
          />
        )}

        {activeTab === 'account' && (
          <AccountSection
            orders={orders}
            appointments={appointments}
            activeCategory={activeCategory}
            onNavigateToShop={handleNavigateToShop}
          />
        )}

        {activeTab === 'admin' && (
          <AdminPanel
            products={warehouseProducts}
            onUpdateProductPrice={handleUpdateProductPrice}
            onUpdateProductAvailability={handleUpdateProductAvailability}
            ordersCount={orders.length}
            totalSales={totalSales}
          />
        )}
      </main>

      {/* FOOTER - Quiet, copyright, clean metadata, no telemetry engines */}
      <footer className="bg-[#1F1F1F] text-slate-400 text-xs py-8 px-6 border-t border-slate-800 text-left shrink-0">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex flex-col gap-1 items-center md:items-start">
            <span className="font-extrabold text-white text-sm font-serif tracking-tight uppercase">COSTCO WHOLESALE</span>
            <p className="text-[10px] text-slate-500 font-medium font-mono uppercase">DESIGN CLASSIC RETAIL SYSTEM · DEMO-001</p>
          </div>
          <div className="flex flex-wrap gap-6 text-[11px] font-semibold uppercase text-slate-400">
            <button onClick={() => setActiveTab('membership')} className="hover:text-white">Membership</button>
            <button onClick={() => setActiveTab('warehouse')} className="hover:text-white">Warehouse Finder</button>
            <button onClick={() => setActiveTab('services')} className="hover:text-white">Customer Support</button>
            <span className="text-slate-700">|</span>
            <span className="text-slate-500">© 2026 Costco Design Lab. Permanent & Verified.</span>
          </div>
        </div>
      </footer>

      {/* Sticky Bottom Navigation for mobile-only architecture viewports */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 shadow-xl py-2 px-4 flex justify-between items-center z-40 h-16 shrink-0">
        <button
          onClick={() => {
            setActiveTab('shop');
            setActiveCategory('all');
          }}
          className={cn(
            "flex flex-col items-center gap-1 flex-1 cursor-pointer",
            activeTab === 'shop' ? "text-[#005691]" : "text-slate-500"
          )}
        >
          <Grid className="w-5 h-5" />
          <span className="text-[10px] font-bold uppercase tracking-wider leading-none">Shop</span>
        </button>

        <button
          onClick={() => {
            setActiveTab('warehouse');
          }}
          className={cn(
            "flex flex-col items-center gap-1 flex-1 cursor-pointer",
            activeTab === 'warehouse' ? "text-[#005691]" : "text-slate-500"
          )}
        >
          <MapPin className="w-5 h-5" />
          <span className="text-[10px] font-bold uppercase tracking-wider leading-none">Warehouse</span>
        </button>

        <button
          onClick={() => setIsAiOpen(true)}
          className="flex flex-col items-center gap-1 flex-1 text-slate-500 cursor-pointer"
        >
          <Search className="w-5 h-5 text-slate-800" />
          <span className="text-[10px] font-bold uppercase tracking-wider leading-none">Ask AI</span>
        </button>

        <button
          onClick={() => setActiveTab('account')}
          className={cn(
            "flex flex-col items-center gap-1 flex-1 cursor-pointer",
            activeTab === 'account' ? "text-[#005691]" : "text-slate-500"
          )}
        >
          <User className="w-5 h-5" />
          <span className="text-[10px] font-bold uppercase tracking-wider leading-none">My Costco</span>
        </button>

        <button
          onClick={() => setIsCartOpen(true)}
          className="flex flex-col items-center gap-1 flex-1 text-slate-500 cursor-pointer relative"
        >
          <ShoppingBag className="w-5 h-5 text-[#E31B23]" />
          <span className="bg-[#E31B23] text-white text-[9px] w-4 h-4 flex items-center justify-center rounded-full font-bold absolute top-0.5 right-4 border border-white">
            {cart.reduce((sum, item) => sum + item.quantity, 0)}
          </span>
          <span className="text-[10px] font-bold uppercase tracking-wider leading-none text-slate-500">Cart</span>
        </button>
      </div>

      {/* Floating details modal subview popup */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
      />

      {/* Floating AI Assistant sliding panel */}
      <AiAssistant
        isOpen={isAiOpen}
        onClose={() => setIsAiOpen(false)}
      />

      {/* Checkout Sliding drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        cart={cart}
        onUpdateQuantity={handleUpdateCartQuantity}
        onClearCart={handleClearCart}
        onPlaceOrder={handlePlaceOrder}
      />

      {/* Local warehouse selector modal */}
      {showWarehouseSelector && (
        <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white border-2 border-slate-300 p-6 w-full max-w-md relative text-left">
            <button
              onClick={() => setShowWarehouseSelector(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-slate-600 font-bold"
            >
              ✕
            </button>
            <h3 className="text-base font-black uppercase text-slate-900 mb-4 border-b border-slate-100 pb-2 flex items-center gap-2">
              <MapPin className="w-4.5 h-4.5 text-[#E31B23]" />
              SELECT LOCAL WAREHOUSE
            </h3>
            <div className="flex flex-col gap-3">
              {WAREHOUSES.map((wh) => (
                <button
                  key={wh.id}
                  onClick={() => {
                    setSelectedWarehouse(wh);
                    setShowWarehouseSelector(false);
                  }}
                  className={cn(
                    "w-full text-left p-4 border transition-colors flex justify-between items-center cursor-pointer",
                    selectedWarehouse.id === wh.id
                      ? "bg-blue-50/20 border-[#005691] text-slate-900"
                      : "border-slate-200 hover:bg-slate-50"
                  )}
                >
                  <div>
                    <strong className="text-sm font-black uppercase tracking-tight block">
                      {wh.name} {wh.number}
                    </strong>
                    <span className="text-xs text-slate-500">{wh.address}, {wh.city}</span>
                  </div>
                  {selectedWarehouse.id === wh.id && (
                    <span className="bg-[#005691] text-white text-[9px] font-bold px-2 py-0.5 rounded-sm shrink-0">
                      SELECTED
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
