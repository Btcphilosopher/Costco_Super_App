import { GoogleGenAI, Type } from "@google/genai";
import { NextRequest, NextResponse } from "next/server";
import { PRODUCTS, MEMBERSHIP_TIERS, SERVICES_DIRECTORY } from "@/lib/data";

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    }
  }
});

export async function POST(req: NextRequest) {
  try {
    const { prompt, chatHistory = [] } = await req.json();

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 });
    }

    // Format products, membership, services into a concise context block
    const productsContext = PRODUCTS.map(p => `
ID: ${p.id}
Brand: ${p.brand}
Name: ${p.name}
Category: ${p.category}
Price: $${p.memberPrice} (Member Price) ${p.previousPrice ? `(Regular Price: $${p.previousPrice}, Save $${p.savings})` : ''}
Pack Size: ${p.packSize}
Aisle: ${p.warehouseAisle}
Rating: ${p.rating} (${p.reviewsCount} reviews)
Is Kirkland: ${p.isKirkland ? 'Yes' : 'No'}
Is Treasure Hunt Special: ${p.isTreasureHunt ? 'Yes' : 'No'}
Specs: ${JSON.stringify(p.specs)}
Description: ${p.description}
Warranty: ${p.warranty || 'Costco standard satisfaction guarantee'}
Availability: ${p.availability} (Warehouse: ${p.warehouseAvailability ? 'Available' : 'Online Only'})
    `).join('\n---\n');

    const membershipContext = MEMBERSHIP_TIERS.map(m => `
Tier: ${m.name}
Price: ${m.price} per year
Summary: ${m.subTitle}
Features: ${m.features.join(', ')}
    `).join('\n---\n');

    const servicesContext = SERVICES_DIRECTORY.map(s => `
Service: ${s.name}
Description: ${s.shortDescription}
Benefits: ${s.benefits.join(', ')}
    `).join('\n---\n');

    const systemInstruction = `
You are the official Costco Digital Warehouse Shopping Assistant.
Your goal is to help members shop, discover deals, learn about Kirkland Signature, choose membership tiers, and navigate services.

You must strictly operate using the provided Costco Design Demo (COSTCO-DESIGN-DEMO-001) dataset.
Do not fabricate products, specifications, or pricing.
If asked about a product or category that is not in the dataset, politely explain that you can only provide information about the current warehouse inventory, but offer to suggest related alternatives from the catalog.

Keep your tone helpful, practical, unpretentious, friendly, and slightly obsessive about value and bulk savings. Always highlight how much they can save or why Kirkland Signature offers incredible quality.

Here is the official Costco Design Demo (COSTCO-DESIGN-DEMO-001) catalog:

=== PRODUCTS ===
${productsContext}

=== MEMBERSHIP TIERS ===
${membershipContext}

=== SERVICES ===
${servicesContext}

When answering queries like:
- "I need to feed 20 people this weekend": recommend the bulk products like the Kirkland Organic Red Quinoa (2.04 kg) or Whole 18" Pizza ($9.95) from our Food Court, Colombian Supreme Whole Beans, etc.
- "I need a TV for a bright living room": recommend the LG 65" Class OLED C4 Series TV and explain its OLED self-lit pixel specs and concierge 2-year warranty.
- "Show me Kirkland products under $50": list the Kirkland Signature products that are under $50 (Olive oil, coffee, bath tissue, tee, daily vitamins, quinoa, dog food) and highlight their exceptional pricing and brand comparisons.

Format your responses in clean Markdown. Present product details in a beautifully formatted structure. Include actionable suggestions.
`;

    // Map history to standard contents format if provided, or simple list
    const response = await ai.models.generateContent({
      model: "gemini-3.8-flash",
      contents: [
        { role: "user", parts: [{ text: `Here is the Costco catalogue. Please answer my queries. \n\nQuery: ${prompt}` }] }
      ],
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    const reply = response.text || "I apologize, I am unable to process that request at this moment. How else can I assist you in the Digital Warehouse?";

    return NextResponse.json({ text: reply });

  } catch (error: any) {
    console.error("Gemini Assistant Route Error:", error);
    return NextResponse.json({
      error: "Failed to query the Costco Shopping Assistant.",
      details: error.message || String(error)
    }, { status: 500 });
  }
}
