package com.example.data.pricing

import com.example.data.model.ProductEntity

data class PricingBreakdown(
    val quantityCases: Int,
    val quantityPallets: Double,
    val baseUnitPrice: Double,
    val effectiveUnitPrice: Double,
    val tierLabel: String,
    val subtotal: Double,
    val volumeDiscountAmount: Double,
    val contractSavingsAmount: Double,
    val freightCost: Double,
    val taxAmount: Double,
    val totalLandedCost: Double,
    val unitLandedCost: Double
)

object PricingEngine {

    /**
     * Calculates volume pricing based on tier breaks and contract vs spot pricing.
     */
    fun calculateLandedCost(
        product: ProductEntity,
        quantityCases: Int,
        isContractMode: Boolean = true,
        isEnterpriseMember: Boolean = true,
        vatTaxRatePct: Double = 20.0
    ): PricingBreakdown {
        val cases = quantityCases.coerceAtLeast(1)
        val pallets = cases.toDouble() / product.palletQty.coerceAtLeast(1)

        // Determine Volume Tier Unit Price
        val (tierUnitPrice, tierName) = when {
            cases >= 500 -> product.tier5Price to "Tier 5 (500+ cases)"
            cases >= 200 -> product.tier4Price to "Tier 4 (200-499 cases)"
            cases >= 50 -> product.tier3Price to "Tier 3 (50-199 cases)"
            cases >= 10 -> product.tier2Price to "Tier 2 (10-49 cases)"
            else -> product.tier1Price to "Tier 1 (1-9 cases)"
        }

        // Apply Contract or Spot adjustment
        val basePrice = if (isContractMode) product.contractPrice else product.spotPrice
        val chosenPrice = minOf(tierUnitPrice, basePrice)

        // Membership discount (e.g. 1.5% extra volume rebate for Enterprise Business Plus)
        val memberDiscountRate = if (isEnterpriseMember) 0.015 else 0.0
        val effectiveUnitPrice = chosenPrice * (1.0 - memberDiscountRate)

        val subtotal = effectiveUnitPrice * cases

        val volumeDiscountAmount = (product.tier1Price - effectiveUnitPrice).coerceAtLeast(0.0) * cases
        val contractSavingsAmount = ((product.spotPrice - product.contractPrice).coerceAtLeast(0.0)) * cases

        // Freight calculation based on pallet weight/volume abstraction
        val freightPerPallet = 45.0 // £45 per pallet
        val freightCost = (pallets * freightPerPallet).coerceAtLeast(15.0)

        // Tax (VAT)
        val taxAmount = (subtotal + freightCost) * (vatTaxRatePct / 100.0)

        val totalLanded = subtotal + freightCost + taxAmount
        val unitLanded = totalLanded / cases

        return PricingBreakdown(
            quantityCases = cases,
            quantityPallets = pallets,
            baseUnitPrice = product.tier1Price,
            effectiveUnitPrice = effectiveUnitPrice,
            tierLabel = tierName,
            subtotal = subtotal,
            volumeDiscountAmount = volumeDiscountAmount,
            contractSavingsAmount = contractSavingsAmount,
            freightCost = freightCost,
            taxAmount = taxAmount,
            totalLandedCost = totalLanded,
            unitLandedCost = unitLanded
        )
    }
}
