package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.*

@Database(
    entities = [
        ProductEntity::class,
        SupplierEntity::class,
        ContractEntity::class,
        RequisitionEntity::class,
        PurchaseOrderEntity::class,
        InventoryEntity::class,
        InvoiceEntity::class,
        ShipmentEntity::class,
        ApprovalEntity::class,
        AuditEventEntity::class,
        WarehouseEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class ProcurementDatabase : RoomDatabase() {
    abstract fun productDao(): ProductDao
    abstract fun supplierDao(): SupplierDao
    abstract fun contractDao(): ContractDao
    abstract fun requisitionDao(): RequisitionDao
    abstract fun poDao(): PurchaseOrderDao
    abstract fun inventoryDao(): InventoryDao
    abstract fun invoiceDao(): InvoiceDao
    abstract fun shipmentDao(): ShipmentDao
    abstract fun approvalDao(): ApprovalDao
    abstract fun auditDao(): AuditDao
    abstract fun warehouseDao(): WarehouseDao

    companion object {
        @Volatile
        private var INSTANCE: ProcurementDatabase? = null

        fun getDatabase(context: Context): ProcurementDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    ProcurementDatabase::class.java,
                    "costco_procurement_db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
