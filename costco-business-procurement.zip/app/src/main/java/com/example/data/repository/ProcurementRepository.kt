package com.example.data.repository

import com.example.data.db.ProcurementDatabase
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ProcurementRepository(private val db: ProcurementDatabase) {

    val allProducts: Flow<List<ProductEntity>> = db.productDao().getAllProducts()
    val allSuppliers: Flow<List<SupplierEntity>> = db.supplierDao().getAllSuppliers()
    val allContracts: Flow<List<ContractEntity>> = db.contractDao().getAllContracts()
    val allRequisitions: Flow<List<RequisitionEntity>> = db.requisitionDao().getAllRequisitions()
    val allPurchaseOrders: Flow<List<PurchaseOrderEntity>> = db.poDao().getAllPurchaseOrders()
    val allInvoices: Flow<List<InvoiceEntity>> = db.invoiceDao().getAllInvoices()
    val exceptionInvoices: Flow<List<InvoiceEntity>> = db.invoiceDao().getExceptions()
    val allShipments: Flow<List<ShipmentEntity>> = db.shipmentDao().getAllShipments()
    val pendingApprovals: Flow<List<ApprovalEntity>> = db.approvalDao().getPendingApprovals()
    val allApprovals: Flow<List<ApprovalEntity>> = db.approvalDao().getAllApprovals()
    val auditEvents: Flow<List<AuditEventEntity>> = db.auditDao().getRecentAuditEvents()
    val allWarehouses: Flow<List<WarehouseEntity>> = db.warehouseDao().getAllWarehouses()

    fun getInventoryByWarehouse(warehouseId: String): Flow<List<InventoryEntity>> {
        return db.inventoryDao().getInventoryByWarehouse(warehouseId)
    }

    fun getAllInventory(): Flow<List<InventoryEntity>> {
        return db.inventoryDao().getAllInventory()
    }

    suspend fun createRequisition(
        requester: String,
        department: String,
        warehouseId: String,
        warehouseName: String,
        itemCount: Int,
        estimatedValue: Double,
        priority: String,
        summaryItem: String
    ) = withContext(Dispatchers.IO) {
        val reqId = "PR-2027-" + (1000..9999).random()
        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
        val req = RequisitionEntity(
            requisitionId = reqId,
            requester = requester,
            department = department,
            warehouseId = warehouseId,
            warehouseName = warehouseName,
            itemCount = itemCount,
            estimatedValue = estimatedValue,
            status = "PENDING_APPROVAL",
            createdAt = dateStr,
            priority = priority,
            summaryItem = summaryItem
        )
        db.requisitionDao().insertRequisition(req)

        // Also add approval queue entry
        val app = ApprovalEntity(
            approvalId = "APP-" + (10000..99999).random(),
            type = "REQUISITION",
            refNumber = reqId,
            title = "Requisition: $summaryItem",
            requestedBy = requester,
            department = department,
            warehouse = warehouseName,
            amount = estimatedValue,
            createdAt = dateStr,
            status = "PENDING"
        )
        db.approvalDao().insertApproval(app)

        logAudit(
            user = requester,
            action = "REQUISITION_CREATED",
            refNumber = reqId,
            amount = estimatedValue,
            details = "Created requisition for $summaryItem ($itemCount cases)"
        )
    }

    suspend fun createPurchaseOrder(
        requisitionId: String,
        supplierId: String,
        supplierName: String,
        contractId: String,
        warehouseId: String,
        warehouseName: String,
        subtotal: Double,
        tax: Double,
        freight: Double,
        itemsSummary: String
    ) = withContext(Dispatchers.IO) {
        val poNumber = "PO-2027-" + (1000..9999).random()
        val total = subtotal + tax + freight
        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        val po = PurchaseOrderEntity(
            poNumber = poNumber,
            requisitionId = requisitionId,
            supplierId = supplierId,
            supplierName = supplierName,
            contractId = contractId,
            warehouseId = warehouseId,
            warehouseName = warehouseName,
            currency = "GBP",
            subtotal = subtotal,
            tax = tax,
            freight = freight,
            total = total,
            status = "APPROVED",
            createdAt = dateStr,
            estimatedDelivery = "2027-10-12",
            itemsSummary = itemsSummary
        )
        db.poDao().insertPO(po)

        logAudit(
            user = "procurement.manager",
            action = "PURCHASE_ORDER_ISSUED",
            refNumber = poNumber,
            amount = total,
            details = "Issued PO to $supplierName for $itemsSummary"
        )
    }

    suspend fun updateApprovalStatus(approvalId: String, refNumber: String, isApproved: Boolean, user: String) = withContext(Dispatchers.IO) {
        val newStatus = if (isApproved) "APPROVED" else "REJECTED"
        db.approvalDao().updateApprovalStatus(approvalId, newStatus)

        // If it was a PO or Requisition, update the underlying entity status
        if (refNumber.startsWith("PO-")) {
            val poStatus = if (isApproved) "ISSUED" else "REJECTED"
            db.poDao().updatePOStatus(refNumber, poStatus)
        }

        logAudit(
            user = user,
            action = if (isApproved) "APPROVAL_GRANTED" else "APPROVAL_REJECTED",
            refNumber = refNumber,
            amount = 0.0,
            details = "Approval $approvalId $newStatus for $refNumber"
        )
    }

    suspend fun resolveInvoiceException(invoiceId: String, newStatus: String, user: String) = withContext(Dispatchers.IO) {
        db.invoiceDao().updateInvoiceMatchStatus(invoiceId, newStatus)
        logAudit(
            user = user,
            action = "INVOICE_EXCEPTION_RESOLVED",
            refNumber = invoiceId,
            amount = 0.0,
            details = "Exception resolved -> $newStatus"
        )
    }

    suspend fun logAudit(user: String, action: String, refNumber: String, amount: Double, details: String) {
        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
        db.auditDao().insertAudit(
            AuditEventEntity(
                timestamp = dateStr,
                user = user,
                action = action,
                refNumber = refNumber,
                amount = amount,
                details = details
            )
        )
    }

    suspend fun seedDatabaseIfEmpty() = withContext(Dispatchers.IO) {
        // Seed initial B2B demo dataset if empty
        val existingProducts = db.productDao().getProductBySku("ENT-PAPER-004821")
        if (existingProducts != null) return@withContext

        // Products
        val products = listOf(
            ProductEntity(
                sku = "ENT-PAPER-004821",
                name = "Kirkland Business Heavy-Duty 2-Ply Paper Towels",
                category = ProductCategory.OPERATIONS.name,
                subcategory = "Paper & Janitorial",
                manufacturer = "Kirkland Signature Commercial",
                supplierId = "SUP-00100",
                supplierName = "Global Packaging & Paper Ltd",
                caseQty = 12,
                palletQty = 48,
                leadTimeDays = 2,
                minOrderCases = 10,
                contractPrice = 31.90,
                spotPrice = 35.40,
                tier1Price = 42.00,
                tier2Price = 39.50,
                tier3Price = 36.80,
                tier4Price = 34.20,
                tier5Price = 31.90,
                unit = "case",
                warehouseAvailability = "London, Manchester, Birmingham, Leeds, Glasgow",
                certifications = "FSC Certified, 100% Recyclable",
                substitutionRules = "Auto-substitute with ENT-PAPER-004822 if stock < 20 cases"
            ),
            ProductEntity(
                sku = "ENT-FOOD-008912",
                name = "Prime Angus Beef Ribeye Steaks (Center-Cut, Fresh)",
                category = ProductCategory.FOOD.name,
                subcategory = "Meat & Poultry",
                manufacturer = "Northstar Meats Ltd",
                supplierId = "SUP-004821",
                supplierName = "Northstar Foods Ltd",
                caseQty = 6,
                palletQty = 32,
                leadTimeDays = 1,
                minOrderCases = 5,
                contractPrice = 142.50,
                spotPrice = 158.00,
                tier1Price = 168.00,
                tier2Price = 159.00,
                tier3Price = 152.00,
                tier4Price = 146.00,
                tier5Price = 142.50,
                unit = "case (12kg)",
                warehouseAvailability = "All 14 Regional Warehouses",
                certifications = "Red Tractor Certified, Halal Available",
                substitutionRules = "Strict specification - No substitution allowed"
            ),
            ProductEntity(
                sku = "ENT-FOOD-003310",
                name = "Kirkland Signature Extra Virgin Olive Oil 5L Commercial",
                category = ProductCategory.FOOD.name,
                subcategory = "Packaged Food",
                manufacturer = "Kirkland Signature",
                supplierId = "SUP-00210",
                supplierName = "Mediterranean Imports Co",
                caseQty = 4,
                palletQty = 60,
                leadTimeDays = 3,
                minOrderCases = 15,
                contractPrice = 52.80,
                spotPrice = 59.90,
                tier1Price = 64.00,
                tier2Price = 60.50,
                tier3Price = 56.00,
                tier4Price = 54.00,
                tier5Price = 52.80,
                unit = "case (4x5L)",
                warehouseAvailability = "London, Manchester, Bristol",
                certifications = "DOP Cold Pressed",
                substitutionRules = "Allow 3L cans if 5L out of stock"
            ),
            ProductEntity(
                sku = "ENT-TECH-009941",
                name = "Enterprise Touchscreen Order Terminal 15.6\" IP65",
                category = ProductCategory.TECHNOLOGY.name,
                subcategory = "Hardware & POS",
                manufacturer = "AeroPos Systems",
                supplierId = "SUP-00305",
                supplierName = "Aero Technology Distribution",
                caseQty = 1,
                palletQty = 20,
                leadTimeDays = 5,
                minOrderCases = 2,
                contractPrice = 420.00,
                spotPrice = 485.00,
                tier1Price = 520.00,
                tier2Price = 480.00,
                tier3Price = 450.00,
                tier4Price = 430.00,
                tier5Price = 420.00,
                unit = "unit",
                warehouseAvailability = "Birmingham Central Distribution",
                certifications = "CE, FCC, Energy Star 8.0",
                substitutionRules = "Upgrade to Pro 17\" at same contract price if backordered"
            ),
            ProductEntity(
                sku = "ENT-FAC-001200",
                name = "Industrial Multi-Surface Disinfectant Cleaner 20L Drum",
                category = ProductCategory.OPERATIONS.name,
                subcategory = "Cleaning & Janitorial",
                manufacturer = "Ecolab Pro",
                supplierId = "SUP-00100",
                supplierName = "Global Packaging & Paper Ltd",
                caseQty = 1,
                palletQty = 24,
                leadTimeDays = 2,
                minOrderCases = 4,
                contractPrice = 38.40,
                spotPrice = 44.00,
                tier1Price = 48.00,
                tier2Price = 44.50,
                tier3Price = 42.00,
                tier4Price = 39.80,
                tier5Price = 38.40,
                unit = "20L drum",
                warehouseAvailability = "All Warehouses",
                certifications = "EN1276 Certified Hospital Grade",
                substitutionRules = "Pro-Chem 20L accepted as equal"
            ),
            ProductEntity(
                sku = "ENT-HOSP-007720",
                name = "Commercial Stainless Steel Prep Table 1800x700mm",
                category = ProductCategory.HOSPITALITY.name,
                subcategory = "Kitchen Equipment",
                manufacturer = "Vortex Steel Works",
                supplierId = "SUP-00512",
                supplierName = "Vortex Commercial Catering",
                caseQty = 1,
                palletQty = 8,
                leadTimeDays = 4,
                minOrderCases = 1,
                contractPrice = 285.00,
                spotPrice = 330.00,
                tier1Price = 350.00,
                tier2Price = 325.00,
                tier3Price = 305.00,
                tier4Price = 292.00,
                tier5Price = 285.00,
                unit = "unit",
                warehouseAvailability = "Manchester & Leeds Warehouses",
                certifications = "NSF Listed 304 Food-Grade Stainless",
                substitutionRules = "Requires approval for dimensional changes"
            )
        )
        db.productDao().insertProducts(products)

        // Warehouses
        val warehouses = listOf(
            WarehouseEntity("WH-LDN-01", "London Heathrow Hub 104", "London", 84, 34, 284500.0, 182, 4200000.0, "12 / 16"),
            WarehouseEntity("WH-MAN-01", "Manchester Logistics Park", "Manchester", 78, 22, 198000.0, 142, 3100000.0, "10 / 12"),
            WarehouseEntity("WH-BHX-01", "Birmingham Central DC", "Birmingham", 91, 41, 350000.0, 210, 5600000.0, "14 / 16"),
            WarehouseEntity("WH-LDS-01", "Leeds Enterprise Depot", "Leeds", 65, 18, 120000.0, 95, 2200000.0, "8 / 10"),
            WarehouseEntity("WH-GLA-01", "Glasgow Freight Gateway", "Glasgow", 72, 15, 145000.0, 88, 1950000.0, "8 / 10")
        )
        db.warehouseDao().insertWarehouses(warehouses)

        // Suppliers
        val suppliers = listOf(
            SupplierEntity("SUP-004821", "Northstar Foods Ltd", "Northstar Meat & Produce Corp UK", "Food & Beverage", 92, 96.4, 98.2, 4800000.0, 42, "PREFERRED", "Net 30"),
            SupplierEntity("SUP-00100", "Global Packaging & Paper Ltd", "Global Packaging Holdings PLC", "Operations & Janitorial", 88, 94.1, 96.5, 2150000.0, 28, "ACTIVE", "Net 60"),
            SupplierEntity("SUP-00210", "Mediterranean Imports Co", "MedImports Trading Ltd", "Food & Beverage", 95, 98.0, 99.1, 1840000.0, 16, "PREFERRED", "2/10 Net 30"),
            SupplierEntity("SUP-00305", "Aero Technology Distribution", "AeroTech B2B Solutions Ltd", "Technology & IT", 85, 91.5, 94.0, 920000.0, 9, "ACTIVE", "Net 30"),
            SupplierEntity("SUP-00512", "Vortex Commercial Catering", "Vortex Catering Equipment Ltd", "Hospitality & Kitchen", 90, 95.8, 97.2, 1450000.0, 14, "ACTIVE", "Net 45")
        )
        db.supplierDao().insertSuppliers(suppliers)

        // Contracts
        val contracts = listOf(
            ContractEntity("CT-2027-001842", "Northstar Annual Food & Meat Agreement FY27", "SUP-004821", "Northstar Foods Ltd", 4800000.0, 3620000.0, "2027-01-01", "2027-12-31", "ACTIVE", 96.5, 2.5, 89),
            ContractEntity("CT-2027-000491", "Global Paper & Packaging Master Supply Contract", "SUP-00100", "Global Packaging & Paper Ltd", 2500000.0, 1980000.0, "2026-06-01", "2027-11-30", "EXPIRING_SOON", 94.0, 1.8, 28),
            ContractEntity("CT-2027-003310", "MedImports Specialty Food & Oils Master Tier", "SUP-00210", "Mediterranean Imports Co", 2000000.0, 1450000.0, "2027-03-01", "2028-02-28", "ACTIVE", 98.0, 3.0, 148)
        )
        db.contractDao().insertContracts(contracts)

        // Requisitions
        val requisitions = listOf(
            RequisitionEntity("PR-2027-004821", "Sarah Williams", "Operations & Kitchen", "WH-MAN-01", "Manchester Logistics Park", 2400, 82560.0, "PENDING_APPROVAL", "2027-10-02 08:30", "URGENT", "Kirkland Paper Towels & Prime Ribeye Steaks"),
            RequisitionEntity("PR-2027-004822", "David Chen", "Hospitality Services", "WH-LDN-01", "London Heathrow Hub 104", 500, 26400.0, "APPROVED", "2027-10-01 14:15", "NORMAL", "Kirkland EVOO 5L Commercial Cases"),
            RequisitionEntity("PR-2027-004823", "Marcus Brody", "Facilities & IT", "WH-BHX-01", "Birmingham Central DC", 25, 10500.0, "PENDING_APPROVAL", "2027-10-03 07:10", "CRITICAL", "Enterprise Touchscreen POS Terminals")
        )
        for (req in requisitions) {
            db.requisitionDao().insertRequisition(req)
        }

        // Purchase Orders
        val purchaseOrders = listOf(
            PurchaseOrderEntity("PO-2027-004821", "PR-2027-004821", "SUP-004821", "Northstar Foods Ltd", "CT-2027-001842", "WH-MAN-01", "Manchester Logistics Park", "GBP", 79600.0, 15920.0, 1200.0, 96720.0, "SHIPPED", "2027-10-01", "2027-10-04", "500 cases Ribeye Steaks & 100 cases Olive Oil"),
            PurchaseOrderEntity("PO-2027-003310", "PR-2027-004822", "SUP-00100", "Global Packaging & Paper Ltd", "CT-2027-000491", "WH-LDN-01", "London Heathrow Hub 104", "GBP", 38280.0, 7656.0, 850.0, 46786.0, "ISSUED", "2027-10-02", "2027-10-05", "1200 cases Kirkland Heavy Duty Paper Towels"),
            PurchaseOrderEntity("PO-2027-001190", "PR-2027-004819", "SUP-00512", "Vortex Commercial Catering", "CT-2027-00512", "WH-BHX-01", "Birmingham Central DC", "GBP", 28500.0, 5700.0, 1100.0, 35300.0, "DELIVERED", "2027-09-28", "2027-10-02", "100 units Commercial Stainless Prep Tables")
        )
        for (po in purchaseOrders) {
            db.poDao().insertPO(po)
        }

        // Invoices & 3-Way Matching
        val invoices = listOf(
            InvoiceEntity("INV-2027-008912", "PO-2027-004821", "SUP-004821", "Northstar Foods Ltd", 96720.0, 96720.0, 96720.0, 0.0, "MATCHED", "2027-10-30"),
            InvoiceEntity("INV-2027-009104", "PO-2027-003310", "SUP-00100", "Global Packaging & Paper Ltd", 46786.0, 44136.0, 46786.0, 2650.0, "EXCEPTION", "2027-11-02", "Price variance +£2,650 on freight surcharge (Unapproved in PO)"),
            InvoiceEntity("INV-2027-007800", "PO-2027-001190", "SUP-00512", "Vortex Commercial Catering", 35300.0, 35300.0, 35300.0, 0.0, "APPROVED_PAYMENT", "2027-10-28")
        )
        db.invoiceDao().insertInvoices(invoices)

        // Inventory
        val inventoryItems = listOf(
            InventoryEntity(sku = "ENT-PAPER-004821", productName = "Kirkland Heavy-Duty Paper Towels", warehouseId = "WH-LDN-01", category = "Operations", onHand = 420, onOrder = 1200, allocated = 180, available = 240, safetyStock = 100, reorderPoint = 300, eoq = 800, daysOfSupply = 18, stockoutRisk = "LOW"),
            InventoryEntity(sku = "ENT-FOOD-008912", productName = "Prime Angus Beef Ribeye Steaks", warehouseId = "WH-MAN-01", category = "Food", onHand = 18, onOrder = 500, allocated = 15, available = 3, safetyStock = 20, reorderPoint = 35, eoq = 250, daysOfSupply = 4, stockoutRisk = "HIGH"),
            InventoryEntity(sku = "ENT-FOOD-003310", productName = "Kirkland EVOO 5L Commercial", warehouseId = "WH-BHX-01", category = "Food", onHand = 310, onOrder = 0, allocated = 90, available = 220, safetyStock = 50, reorderPoint = 100, eoq = 300, daysOfSupply = 24, stockoutRisk = "LOW")
        )
        db.inventoryDao().insertInventory(inventoryItems)

        // Shipments
        val shipments = listOf(
            ShipmentEntity("SHP-88421", "PO-2027-004821", "DHL Supply Chain Logistics", "ROAD", "Northstar Abattoir Leeds", "WH-MAN-01 Manchester", "2027-10-04 11:00", "IN_TRANSIT", true),
            ShipmentEntity("SHP-88422", "PO-2027-003310", "Kuehne+Nagel Freight", "ROAD", "Paper Mills Kent", "WH-LDN-01 London", "2027-10-05 09:30", "DISPATCHED", false)
        )
        db.shipmentDao().insertShipments(shipments)

        // Approvals
        val approvals = listOf(
            ApprovalEntity("APP-10492", "PURCHASE_ORDER", "PO-2027-004821", "PO Approval: £96,720 - Northstar Foods", "Sarah Williams", "Operations & Kitchen", "Manchester Hub", 96720.0, "2027-10-02 09:15", "PENDING"),
            ApprovalEntity("APP-10493", "REQUISITION", "PR-2027-004823", "Requisition: Enterprise Touchscreen POS Terminals", "Marcus Brody", "Facilities & IT", "Birmingham DC", 10500.0, "2027-10-03 07:10", "PENDING")
        )
        for (app in approvals) {
            db.approvalDao().insertApproval(app)
        }

        // Audit Events
        logAudit(
            user = "system.initializer",
            action = "DEMO_DATASET_LOADED",
            refNumber = "COSTCO-B2B-DEMO-001",
            amount = 18400000.0,
            details = "Initialized ACME Hospitality Group FY2027 Procurement Operating System"
        )
    }
}
