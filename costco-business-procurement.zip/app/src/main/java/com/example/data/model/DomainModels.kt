package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ProductCategory(val displayName: String) {
    FOOD("Food & Beverage"),
    OPERATIONS("Operations & Janitorial"),
    TECHNOLOGY("Technology & IT"),
    FACILITIES("Facilities & MRO"),
    HOSPITALITY("Hospitality & Kitchen"),
    CONSTRUCTION("Construction & Safety")
}

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey val sku: String,
    val name: String,
    val category: String,
    val subcategory: String,
    val manufacturer: String,
    val supplierId: String,
    val supplierName: String,
    val caseQty: Int,
    val palletQty: Int,
    val leadTimeDays: Int,
    val minOrderCases: Int,
    val contractPrice: Double,
    val spotPrice: Double,
    val tier1Price: Double, // 1-9
    val tier2Price: Double, // 10-49
    val tier3Price: Double, // 50-199
    val tier4Price: Double, // 200-499
    val tier5Price: Double, // 500+
    val unit: String,
    val warehouseAvailability: String,
    val certifications: String,
    val substitutionRules: String
)

@Entity(tableName = "suppliers")
data class SupplierEntity(
    @PrimaryKey val supplierId: String,
    val name: String,
    val legalName: String,
    val categories: String,
    val riskScore: Int,
    val onTimeDeliveryRate: Double,
    val fillRate: Double,
    val spendYtd: Double,
    val openPOsCount: Int,
    val status: String,
    val paymentTerms: String
)

@Entity(tableName = "contracts")
data class ContractEntity(
    @PrimaryKey val contractId: String,
    val title: String,
    val supplierId: String,
    val supplierName: String,
    val annualCommitment: Double,
    val currentSpend: Double,
    val validFrom: String,
    val validTo: String,
    val status: String,
    val slaOnTimePct: Double,
    val rebateRatePct: Double,
    val daysUntilExpiry: Int
)

@Entity(tableName = "requisitions")
data class RequisitionEntity(
    @PrimaryKey val requisitionId: String,
    val requester: String,
    val department: String,
    val warehouseId: String,
    val warehouseName: String,
    val itemCount: Int,
    val estimatedValue: Double,
    val status: String,
    val createdAt: String,
    val priority: String,
    val summaryItem: String
)

@Entity(tableName = "purchase_orders")
data class PurchaseOrderEntity(
    @PrimaryKey val poNumber: String,
    val requisitionId: String,
    val supplierId: String,
    val supplierName: String,
    val contractId: String,
    val warehouseId: String,
    val warehouseName: String,
    val currency: String = "GBP",
    val subtotal: Double,
    val tax: Double,
    val freight: Double,
    val total: Double,
    val status: String,
    val createdAt: String,
    val estimatedDelivery: String,
    val itemsSummary: String
)

@Entity(tableName = "inventory_items")
data class InventoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sku: String,
    val productName: String,
    val warehouseId: String,
    val category: String,
    val onHand: Int,
    val onOrder: Int,
    val allocated: Int,
    val available: Int,
    val safetyStock: Int,
    val reorderPoint: Int,
    val eoq: Int,
    val daysOfSupply: Int,
    val stockoutRisk: String
)

@Entity(tableName = "invoices")
data class InvoiceEntity(
    @PrimaryKey val invoiceId: String,
    val poNumber: String,
    val supplierId: String,
    val supplierName: String,
    val poAmount: Double,
    val goodsReceiptAmount: Double,
    val invoiceAmount: Double,
    val variance: Double,
    val matchStatus: String,
    val dueDate: String,
    val exceptionReason: String? = null
)

@Entity(tableName = "shipments")
data class ShipmentEntity(
    @PrimaryKey val shipmentId: String,
    val poNumber: String,
    val carrier: String,
    val mode: String,
    val origin: String,
    val destination: String,
    val eta: String,
    val status: String,
    val temperatureControl: Boolean
)

@Entity(tableName = "approvals")
data class ApprovalEntity(
    @PrimaryKey val approvalId: String,
    val type: String,
    val refNumber: String,
    val title: String,
    val requestedBy: String,
    val department: String,
    val warehouse: String,
    val amount: Double,
    val createdAt: String,
    val status: String
)

@Entity(tableName = "audit_events")
data class AuditEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: String,
    val user: String,
    val action: String,
    val refNumber: String,
    val amount: Double,
    val details: String
)

@Entity(tableName = "warehouses")
data class WarehouseEntity(
    @PrimaryKey val warehouseId: String,
    val name: String,
    val location: String,
    val capacityPercent: Int,
    val inboundShipments: Int,
    val todayReceiving: Double,
    val openOrders: Int,
    val totalInventory: Double,
    val staffedBays: String
)
