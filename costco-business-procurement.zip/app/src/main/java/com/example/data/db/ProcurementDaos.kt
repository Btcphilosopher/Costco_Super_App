package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ProductDao {
    @Query("SELECT * FROM products")
    fun getAllProducts(): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE category = :category")
    fun getProductsByCategory(category: String): Flow<List<ProductEntity>>

    @Query("SELECT * FROM products WHERE sku = :sku")
    suspend fun getProductBySku(sku: String): ProductEntity?

    @Query("SELECT * FROM products WHERE name LIKE '%' || :query || '%' OR sku LIKE '%' || :query || '%'")
    fun searchProducts(query: String): Flow<List<ProductEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProducts(products: List<ProductEntity>)
}

@Dao
interface SupplierDao {
    @Query("SELECT * FROM suppliers ORDER BY spendYtd DESC")
    fun getAllSuppliers(): Flow<List<SupplierEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSuppliers(suppliers: List<SupplierEntity>)
}

@Dao
interface ContractDao {
    @Query("SELECT * FROM contracts ORDER BY daysUntilExpiry ASC")
    fun getAllContracts(): Flow<List<ContractEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContracts(contracts: List<ContractEntity>)
}

@Dao
interface RequisitionDao {
    @Query("SELECT * FROM requisitions ORDER BY createdAt DESC")
    fun getAllRequisitions(): Flow<List<RequisitionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRequisition(requisition: RequisitionEntity)

    @Update
    suspend fun updateRequisition(requisition: RequisitionEntity)
}

@Dao
interface PurchaseOrderDao {
    @Query("SELECT * FROM purchase_orders ORDER BY createdAt DESC")
    fun getAllPurchaseOrders(): Flow<List<PurchaseOrderEntity>>

    @Query("SELECT * FROM purchase_orders WHERE poNumber = :poNumber")
    suspend fun getPOByNumber(poNumber: String): PurchaseOrderEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPO(po: PurchaseOrderEntity)

    @Update
    suspend fun updatePO(po: PurchaseOrderEntity)

    @Query("UPDATE purchase_orders SET status = :status WHERE poNumber = :poNumber")
    suspend fun updatePOStatus(poNumber: String, status: String)
}

@Dao
interface InventoryDao {
    @Query("SELECT * FROM inventory_items WHERE warehouseId = :warehouseId")
    fun getInventoryByWarehouse(warehouseId: String): Flow<List<InventoryEntity>>

    @Query("SELECT * FROM inventory_items")
    fun getAllInventory(): Flow<List<InventoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInventory(items: List<InventoryEntity>)
}

@Dao
interface InvoiceDao {
    @Query("SELECT * FROM invoices ORDER BY dueDate ASC")
    fun getAllInvoices(): Flow<List<InvoiceEntity>>

    @Query("SELECT * FROM invoices WHERE matchStatus = 'EXCEPTION'")
    fun getExceptions(): Flow<List<InvoiceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoices(invoices: List<InvoiceEntity>)

    @Query("UPDATE invoices SET matchStatus = :status WHERE invoiceId = :invoiceId")
    suspend fun updateInvoiceMatchStatus(invoiceId: String, status: String)
}

@Dao
interface ShipmentDao {
    @Query("SELECT * FROM shipments")
    fun getAllShipments(): Flow<List<ShipmentEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShipments(shipments: List<ShipmentEntity>)
}

@Dao
interface ApprovalDao {
    @Query("SELECT * FROM approvals WHERE status = 'PENDING'")
    fun getPendingApprovals(): Flow<List<ApprovalEntity>>

    @Query("SELECT * FROM approvals ORDER BY createdAt DESC")
    fun getAllApprovals(): Flow<List<ApprovalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApproval(approval: ApprovalEntity)

    @Query("UPDATE approvals SET status = :status WHERE approvalId = :approvalId")
    suspend fun updateApprovalStatus(approvalId: String, status: String)
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audit_events ORDER BY id DESC LIMIT 50")
    fun getRecentAuditEvents(): Flow<List<AuditEventEntity>>

    @Insert
    suspend fun insertAudit(event: AuditEventEntity)
}

@Dao
interface WarehouseDao {
    @Query("SELECT * FROM warehouses")
    fun getAllWarehouses(): Flow<List<WarehouseEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWarehouses(warehouses: List<WarehouseEntity>)
}
