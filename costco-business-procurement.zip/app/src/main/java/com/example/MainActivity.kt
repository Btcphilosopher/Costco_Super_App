package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.components.AppShell
import com.example.ui.theme.CostcoBusinessTheme
import com.example.ui.viewmodel.ProcurementViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: ProcurementViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      CostcoBusinessTheme {
        AppShell(viewModel = viewModel)
      }
    }
  }
}
