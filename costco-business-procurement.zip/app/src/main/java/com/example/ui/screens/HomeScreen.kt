package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Warehouse
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.ExecutiveMetricCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProcurementViewModel

@Composable
fun HomeScreen(
    viewModel: ProcurementViewModel,
    onNavigate: (String) -> Unit
) {
    val pendingApprovals by viewModel.pendingApprovals.collectAsState()
    val openPOs by viewModel.purchaseOrders.collectAsState()
    val invoices by viewModel.invoices.collectAsState()
    val auditEvents by viewModel.auditEvents.collectAsState()
    val selectedOrg by viewModel.selectedOrg.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()

    val openInvoicesTotal = invoices.filter { it.matchStatus == "EXCEPTION" || it.matchStatus == "VALIDATING" }
        .sumOf { it.invoiceAmount }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Executive Header
        item {
            Column {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column {
                        Text(
                            text = "GOOD MORNING. HERE IS YOUR PROCUREMENT POSITION.",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp,
                                color = CostcoDeepNavy
                            )
                        )
                        Text(
                            text = "$selectedOrg • FY2027 Operating Budget • 14 Regional Warehouses",
                            style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
                        )
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(CostcoRed)
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "DEMO MODE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Black,
                                color = Color.White
                            )
                        )
                    }
                }
            }
        }

        // Executive Hero Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp),
                shape = RoundedCornerShape(8.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = R.drawable.b2b_bulk_banner_1791022613268),
                        contentDescription = "B2B Banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(CostcoDeepNavy.copy(alpha = 0.75f))
                    )
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "COSTCO BUSINESS PROCUREMENT OS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = CostcoRed,
                                fontWeight = FontWeight.Black
                            )
                        )
                        Text(
                            text = "BUY BETTER. BUY IN VOLUME. CONTROL THE WHOLE FLOW.",
                            style = MaterialTheme.typography.titleLarge.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Black
                            )
                        )
                        Text(
                            text = "Direct warehouse volume tiering & contract price optimization active",
                            style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.85f))
                        )
                    }
                }
            }
        }

        // Executive Metrics Grid (2x4)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ExecutiveMetricCard(
                        title = "Total Spend",
                        value = "${currency}18.4M",
                        subtitle = "YTD Contract & Spot",
                        modifier = Modifier.weight(1f)
                    ) { onNavigate("SPEND") }

                    ExecutiveMetricCard(
                        title = "Open POs",
                        value = "${openPOs.size + 1280}",
                        subtitle = "Across 14 Warehouses",
                        modifier = Modifier.weight(1f)
                    ) { onNavigate("PURCHASE_ORDERS") }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ExecutiveMetricCard(
                        title = "Pending Approvals",
                        value = "${pendingApprovals.size}",
                        subtitle = "Requires Manager Action",
                        valueColor = CostcoRed,
                        modifier = Modifier.weight(1f)
                    ) { onNavigate("APPROVALS") }

                    ExecutiveMetricCard(
                        title = "Active Suppliers",
                        value = "418",
                        subtitle = "96.4% On-Time SLA",
                        modifier = Modifier.weight(1f)
                    ) { onNavigate("SUPPLIERS") }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ExecutiveMetricCard(
                        title = "Contract Coverage",
                        value = "87%",
                        subtitle = "Target: >85%",
                        valueColor = SuccessGreen,
                        modifier = Modifier.weight(1f)
                    ) { onNavigate("CONTRACTS") }

                    ExecutiveMetricCard(
                        title = "Savings Identified",
                        value = "${currency}1.28M",
                        subtitle = "Costco Volume Tiering",
                        valueColor = SuccessGreen,
                        modifier = Modifier.weight(1f)
                    ) { onNavigate("SPEND") }
                }
            }
        }

        // Quick Workflows Section
        item {
            SectionHeader(title = "Core Procurement Actions")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { onNavigate("CATALOGUE") },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = CostcoDeepNavy),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("Search Catalogue", style = MaterialTheme.typography.labelSmall)
                }
                Button(
                    onClick = { onNavigate("PROCUREMENT") },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = CostcoBlue),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("New Requisition", style = MaterialTheme.typography.labelSmall)
                }
                Button(
                    onClick = { onNavigate("INVOICES") },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = CostcoRed),
                    shape = RoundedCornerShape(6.dp)
                ) {
                    Text("3-Way Match", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        // Recent Audit Feed
        item {
            SectionHeader(title = "Audit & System Event Log", actionText = "View All") { onNavigate("ADMIN") }
        }

        items(auditEvents.take(5)) { audit ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(6.dp)
            ) {
                Row(
                    modifier = Modifier
                        .padding(12.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = audit.action,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CostcoDeepNavy
                                )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = audit.refNumber,
                                style = MaterialTheme.typography.labelSmall.copy(color = CostcoBlue)
                            )
                        }
                        Text(
                            text = audit.details,
                            style = MaterialTheme.typography.bodySmall.copy(color = WarehouseGrey)
                        )
                    }
                    Text(
                        text = audit.timestamp.takeLast(8),
                        style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey)
                    )
                }
            }
        }
    }
}
