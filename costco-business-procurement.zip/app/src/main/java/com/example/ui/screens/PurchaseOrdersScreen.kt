package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PurchaseOrderEntity
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProcurementViewModel

@Composable
fun PurchaseOrdersScreen(viewModel: ProcurementViewModel) {
    val purchaseOrders by viewModel.purchaseOrders.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()
    var selectedPO by remember { mutableStateOf<PurchaseOrderEntity?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "PURCHASE ORDERS CONTROL CENTRE",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
                color = CostcoDeepNavy
            )
        )
        Text(
            text = "Full PO Lifecycle: Draft → Issued → Shipped → Received → Closed",
            style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
        )

        Spacer(modifier = Modifier.height(16.dp))

        SectionHeader(title = "Issued Purchase Orders (${purchaseOrders.size})")

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(purchaseOrders) { po ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = po.poNumber,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    color = CostcoDeepNavy
                                )
                            )
                            StatusBadge(status = po.status)
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = po.itemsSummary,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )

                        Text(
                            text = "Supplier: ${po.supplierName} • Destination: ${po.warehouseName}",
                            style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(BackgroundLight)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("SUBTOTAL", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text("${currency}${String.format("%.2f", po.subtotal)}", style = MaterialTheme.typography.bodySmall)
                            }
                            Column {
                                Text("FREIGHT / TAX", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text("${currency}${String.format("%.2f", po.freight + po.tax)}", style = MaterialTheme.typography.bodySmall)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("LANDED TOTAL", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text(
                                    text = "${currency}${String.format("%.2f", po.total)}",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = CostcoDeepNavy
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Requisition Ref: ${po.requisitionId}", style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey))
                            Text("Est. Delivery: ${po.estimatedDelivery}", style = MaterialTheme.typography.bodySmall.copy(color = CostcoBlue, fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }
    }
}
