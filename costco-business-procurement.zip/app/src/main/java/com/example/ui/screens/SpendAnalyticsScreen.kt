package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ExecutiveMetricCard
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProcurementViewModel

@Composable
fun SpendAnalyticsScreen(viewModel: ProcurementViewModel) {
    val currency by viewModel.selectedCurrency.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "SPEND ANALYTICS & MULTIDIMENSIONAL CUBE",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
                color = CostcoDeepNavy
            )
        )
        Text(
            text = "Trace Total Spend → Category → Supplier → Warehouse → PO → Invoice",
            style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ExecutiveMetricCard(
                        title = "Addressable Spend",
                        value = "${currency}18.42M",
                        subtitle = "FY2027 YTD",
                        modifier = Modifier.weight(1f)
                    )
                    ExecutiveMetricCard(
                        title = "Contracted Spend",
                        value = "${currency}16.03M",
                        subtitle = "87% Coverage Rate",
                        valueColor = SuccessGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ExecutiveMetricCard(
                        title = "Total Savings",
                        value = "${currency}1.28M",
                        subtitle = "Negotiated & Volume",
                        valueColor = SuccessGreen,
                        modifier = Modifier.weight(1f)
                    )
                    ExecutiveMetricCard(
                        title = "Maverick Spend",
                        value = "${currency}240K",
                        subtitle = "Target: <1.5%",
                        valueColor = CostcoRed,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            item {
                SectionHeader(title = "Spend Breakdown By Category")
            }

            item {
                val categories = listOf(
                    Triple("Food & Beverage", "${currency}11.23M", 0.61f),
                    Triple("Operations & Janitorial", "${currency}3.31M", 0.18f),
                    Triple("Hospitality & Kitchen", "${currency}1.84M", 0.10f),
                    Triple("Technology & IT", "${currency}1.10M", 0.06f),
                    Triple("Facilities & MRO", "${currency}0.94M", 0.05f)
                )

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        categories.forEach { (catName, amount, pct) ->
                            Column {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(catName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = CostcoDeepNavy))
                                    Text("$amount (${(pct * 100).toInt()}%)", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Black))
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { pct },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(8.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = CostcoBlue,
                                    trackColor = BackgroundLight
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
