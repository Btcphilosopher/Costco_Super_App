package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.ai.AiAssistantBottomSheet
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProcurementViewModel

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Home : Screen("HOME", "Home", Icons.Default.Home)
    object Procurement : Screen("PROCUREMENT", "Requisitions", Icons.Default.Assignment)
    object Catalogue : Screen("CATALOGUE", "Catalogue", Icons.Default.Storefront)
    object Suppliers : Screen("SUPPLIERS", "Suppliers", Icons.Default.Business)
    object Contracts : Screen("CONTRACTS", "Contracts", Icons.Default.Description)
    object PurchaseOrders : Screen("PURCHASE_ORDERS", "Orders", Icons.Default.Receipt)
    object Warehouse : Screen("WAREHOUSE", "Warehouse", Icons.Default.Warehouse)
    object Logistics : Screen("LOGISTICS", "Logistics", Icons.Default.LocalShipping)
    object Invoices : Screen("INVOICES", "3-Way Match", Icons.Default.FactCheck)
    object Spend : Screen("SPEND", "Analytics", Icons.Default.BarChart)
    object Approvals : Screen("APPROVALS", "Approvals", Icons.Default.Verified)
    object Admin : Screen("ADMIN", "Admin", Icons.Default.AdminPanelSettings)
}

val primaryNavItems = listOf(
    Screen.Home,
    Screen.Catalogue,
    Screen.Procurement,
    Screen.PurchaseOrders,
    Screen.Warehouse,
    Screen.Invoices,
    Screen.Approvals,
    Screen.Admin
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppShell(viewModel: ProcurementViewModel) {
    var currentRoute by remember { mutableStateOf("HOME") }
    var showAiSheet by remember { mutableStateOf(false) }

    val selectedOrg by viewModel.selectedOrg.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()
    val pendingApprovals by viewModel.pendingApprovals.collectAsState()

    var showOrgMenu by remember { mutableStateOf(false) }
    var showCurrencyMenu by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "COSTCO BUSINESS",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp,
                                color = Color.White
                            )
                        )
                        Text(
                            text = "Enterprise Procurement OS",
                            style = MaterialTheme.typography.labelSmall.copy(color = Color.White.copy(alpha = 0.8f))
                        )
                    }
                },
                actions = {
                    // Org Selector
                    Box {
                        TextButton(onClick = { showOrgMenu = true }) {
                            Text(
                                text = selectedOrg.take(16) + "...",
                                style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontWeight = FontWeight.Bold)
                            )
                        }
                        DropdownMenu(
                            expanded = showOrgMenu,
                            onDismissRequest = { showOrgMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("ACME Hospitality Group") },
                                onClick = {
                                    viewModel.setOrg("ACME Hospitality Group")
                                    showOrgMenu = false
                                }
                            )
                            DropdownMenuItem(
                                text = { Text("ACME Enterprise Group") },
                                onClick = {
                                    viewModel.setOrg("ACME Enterprise Group")
                                    showOrgMenu = false
                                }
                            )
                        }
                    }

                    // Currency Selector
                    Box {
                        TextButton(onClick = { showCurrencyMenu = true }) {
                            Text(
                                text = currency,
                                style = MaterialTheme.typography.titleSmall.copy(color = Color.White, fontWeight = FontWeight.Black)
                            )
                        }
                        DropdownMenu(
                            expanded = showCurrencyMenu,
                            onDismissRequest = { showCurrencyMenu = false }
                        ) {
                            DropdownMenuItem(text = { Text("£ (GBP)") }, onClick = { viewModel.setCurrency("£"); showCurrencyMenu = false })
                            DropdownMenuItem(text = { Text("$ (USD)") }, onClick = { viewModel.setCurrency("$"); showCurrencyMenu = false })
                            DropdownMenuItem(text = { Text("€ (EUR)") }, onClick = { viewModel.setCurrency("€"); showCurrencyMenu = false })
                        }
                    }

                    // AI Assistant Button
                    IconButton(onClick = { showAiSheet = true }) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI Assistant",
                            tint = CostcoRed
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CostcoDeepNavy,
                    titleContentColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = CostcoDeepNavy,
                contentColor = Color.White
            ) {
                primaryNavItems.take(5).forEach { screen ->
                    val isSelected = currentRoute == screen.route
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { currentRoute = screen.route },
                        icon = {
                            if (screen.route == "APPROVALS" && pendingApprovals.isNotEmpty()) {
                                BadgedBox(badge = { Badge { Text("${pendingApprovals.size}") } }) {
                                    Icon(screen.icon, contentDescription = screen.title)
                                }
                            } else {
                                Icon(screen.icon, contentDescription = screen.title)
                            }
                        },
                        label = {
                            Text(
                                text = screen.title,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Black else FontWeight.Normal
                                )
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = CostcoDeepNavy,
                            selectedTextColor = Color.White,
                            indicatorColor = Color.White,
                            unselectedIconColor = Color.White.copy(alpha = 0.7f),
                            unselectedTextColor = Color.White.copy(alpha = 0.7f)
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
        ) {
            when (currentRoute) {
                "HOME" -> HomeScreen(viewModel, onNavigate = { currentRoute = it })
                "CATALOGUE" -> CatalogueScreen(viewModel, onNavigateToRequisition = { currentRoute = it })
                "PROCUREMENT" -> ProcurementScreen(viewModel, onNavigateToPO = { currentRoute = it })
                "SUPPLIERS" -> SuppliersScreen(viewModel)
                "CONTRACTS" -> ContractsScreen(viewModel)
                "PURCHASE_ORDERS" -> PurchaseOrdersScreen(viewModel)
                "WAREHOUSE" -> WarehouseInventoryScreen(viewModel, onNavigateToReq = { currentRoute = it })
                "LOGISTICS" -> DeliveriesLogisticsScreen(viewModel)
                "INVOICES" -> InvoicesMatchingScreen(viewModel)
                "SPEND" -> SpendAnalyticsScreen(viewModel)
                "APPROVALS" -> ApprovalsScreen(viewModel)
                "ADMIN" -> AdminSettingsScreen(viewModel)
                else -> HomeScreen(viewModel, onNavigate = { currentRoute = it })
            }
        }

        if (showAiSheet) {
            AiAssistantBottomSheet(
                viewModel = viewModel,
                onDismiss = { showAiSheet = false }
            )
        }
    }
}
