package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProductCategory
import com.example.data.model.ProductEntity
import com.example.data.pricing.PricingEngine
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProcurementViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CatalogueScreen(
    viewModel: ProcurementViewModel,
    onNavigateToRequisition: (String) -> Unit
) {
    val products by viewModel.products.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()

    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var showReqModal by remember { mutableStateOf(false) }
    var selectedProductForReq by remember { mutableStateOf<ProductEntity?>(null) }
    var reqCases by remember { mutableIntStateOf(50) }

    val filteredProducts = products.filter { prod ->
        (selectedCategory == null || prod.category == selectedCategory) &&
        (searchQuery.isBlank() || prod.name.contains(searchQuery, ignoreCase = true) || prod.sku.contains(searchQuery, ignoreCase = true))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Search & Header
        Text(
            text = "ENTERPRISE BULK CATALOGUE",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
                color = CostcoDeepNavy
            )
        )
        Text(
            text = "Warehouse Direct Tiered Volume Pricing & Landed Cost Engine",
            style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by SKU, Product Name, Category...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Category Filter Chips
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                FilterChip(
                    selected = selectedCategory == null,
                    onClick = { selectedCategory = null },
                    label = { Text("All Categories") }
                )
            }
            items(ProductCategory.values()) { cat ->
                FilterChip(
                    selected = selectedCategory == cat.name,
                    onClick = { selectedCategory = cat.name },
                    label = { Text(cat.displayName) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Catalogue Items List
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(filteredProducts) { product ->
                ProductBulkCard(
                    product = product,
                    currency = currency,
                    onAddToReq = { p, cases ->
                        selectedProductForReq = p
                        reqCases = cases
                        showReqModal = true
                    }
                )
            }
        }
    }

    // Modal to create requisition from product card
    if (showReqModal && selectedProductForReq != null) {
        val prod = selectedProductForReq!!
        val pricing = PricingEngine.calculateLandedCost(prod, reqCases)

        AlertDialog(
            onDismissRequest = { showReqModal = false },
            title = {
                Text(
                    text = "CREATE REQUISITION",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Black, color = CostcoDeepNavy)
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(text = prod.name, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    Text(text = "SKU: ${prod.sku} • Supplier: ${prod.supplierName}", style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey))

                    Divider()

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Order Volume:", style = MaterialTheme.typography.bodySmall)
                        Text("$reqCases cases (${String.format("%.1f", pricing.quantityPallets)} pallets)", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Active Tier Rate:", style = MaterialTheme.typography.bodySmall)
                        Text("${currency}${String.format("%.2f", pricing.effectiveUnitPrice)} / case", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = CostcoBlue))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Freight & Landed Total:", style = MaterialTheme.typography.bodySmall)
                        Text("${currency}${String.format("%.2f", pricing.totalLandedCost)}", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Black, color = CostcoDeepNavy))
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.createRequisition(
                            requester = "Sarah Williams",
                            department = "Kitchen & Operations",
                            warehouseId = "WH-MAN-01",
                            warehouseName = "Manchester Logistics Park",
                            itemCount = reqCases,
                            estimatedValue = pricing.totalLandedCost,
                            priority = "NORMAL",
                            summaryItem = "${prod.name} ($reqCases cases)"
                        )
                        showReqModal = false
                        onNavigateToRequisition("PROCUREMENT")
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CostcoDeepNavy)
                ) {
                    Text("Submit Requisition")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReqModal = false }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun ProductBulkCard(
    product: ProductEntity,
    currency: String,
    onAddToReq: (ProductEntity, Int) -> Unit
) {
    var qtyCases by remember { mutableIntStateOf(50) }
    val pricing = PricingEngine.calculateLandedCost(product, qtyCases)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: SKU & Category
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(CostcoBlue.copy(alpha = 0.1f))
                        .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = product.sku,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = CostcoBlue
                        )
                    )
                }
                Text(
                    text = product.category,
                    style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = product.name,
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = CostcoDeepNavy
                )
            )

            Text(
                text = "Mfr: ${product.manufacturer} • Supplier: ${product.supplierName}",
                style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Pricing Spot vs Contract
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(BackgroundLight)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("CONTRACT PRICE", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                    Text(
                        text = "${currency}${String.format("%.2f", product.contractPrice)} / ${product.unit}",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Black,
                            color = CostcoDeepNavy
                        )
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("SPOT PRICE", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                    Text(
                        text = "${currency}${String.format("%.2f", product.spotPrice)}",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = SteelGrey,
                            fontWeight = FontWeight.Bold
                        )
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(SuccessGreen.copy(alpha = 0.15f))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "SAVE ${currency}${String.format("%.2f", product.spotPrice - product.contractPrice)}/unit",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Black,
                            color = SuccessGreen
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Volume Tier Table
            Text(
                text = "COSTCO VOLUME TIER SCHEDULE",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = CostcoDeepNavy
                )
            )
            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
            ) {
                val tiers = listOf(
                    "1-9" to product.tier1Price,
                    "10-49" to product.tier2Price,
                    "50-199" to product.tier3Price,
                    "200-499" to product.tier4Price,
                    "500+" to product.tier5Price
                )
                tiers.forEach { (qty, price) ->
                    val isActive = when (qty) {
                        "1-9" -> qtyCases in 1..9
                        "10-49" -> qtyCases in 10..49
                        "50-199" -> qtyCases in 50..199
                        "200-499" -> qtyCases in 200..499
                        "500+" -> qtyCases >= 500
                        else -> false
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .background(if (isActive) CostcoBlue.copy(alpha = 0.2f) else Color.Transparent)
                            .padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = qty,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = if (isActive) FontWeight.Black else FontWeight.Normal,
                                color = if (isActive) CostcoDeepNavy else SteelGrey
                            )
                        )
                        Text(
                            text = "${currency}${String.format("%.2f", price)}",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = if (isActive) FontWeight.Black else FontWeight.Bold,
                                color = if (isActive) CostcoDeepNavy else WarehouseGrey
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Interactive Volume Calculator & Add to Requisition
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Quantity Stepper
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = { if (qtyCases > 10) qtyCases -= 10 },
                        modifier = Modifier
                            .size(32.dp)
                            .border(1.dp, SteelGrey, RoundedCornerShape(4.dp))
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(16.dp))
                    }

                    Text(
                        text = "$qtyCases cases",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                        modifier = Modifier.padding(horizontal = 12.dp)
                    )

                    IconButton(
                        onClick = { qtyCases += 10 },
                        modifier = Modifier
                            .size(32.dp)
                            .border(1.dp, SteelGrey, RoundedCornerShape(4.dp))
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(16.dp))
                    }
                }

                // Landed Cost & Button
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Landed Total: ${currency}${String.format("%.2f", pricing.totalLandedCost)}",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Black,
                            color = CostcoDeepNavy
                        )
                    )
                    Text(
                        text = "Freight: ${currency}${String.format("%.0f", pricing.freightCost)} • Tax: ${currency}${String.format("%.0f", pricing.taxAmount)}",
                        style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Button(
                onClick = { onAddToReq(product, qtyCases) },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = CostcoDeepNavy),
                shape = RoundedCornerShape(6.dp)
            ) {
                Icon(Icons.Default.ShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Create Requisition For $qtyCases Cases")
            }
        }
    }
}
