package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.ExecutiveMetricCard
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProcurementViewModel

@Composable
fun WarehouseInventoryScreen(
    viewModel: ProcurementViewModel,
    onNavigateToReq: (String) -> Unit
) {
    val warehouses by viewModel.warehouses.collectAsState()
    val inventory by viewModel.inventory.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()

    var selectedWarehouse by remember { mutableStateOf(warehouses.firstOrNull()) }

    LaunchedEffect(warehouses) {
        if (selectedWarehouse == null && warehouses.isNotEmpty()) {
            selectedWarehouse = warehouses.first()
        }
    }

    val activeWh = selectedWarehouse ?: warehouses.firstOrNull() ?: return

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Warehouse Selector Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "COSTCO WAREHOUSE MODE: ${activeWh.name.uppercase()}",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp,
                        color = CostcoDeepNavy
                    )
                )
                Text(
                    text = "Dock-to-Dispatch Visual Pipeline & Automated Reorder Rules",
                    style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Warehouse Location Filter Chips
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(warehouses) { wh ->
                FilterChip(
                    selected = selectedWarehouse?.warehouseId == wh.warehouseId,
                    onClick = { selectedWarehouse = wh },
                    label = { Text(wh.location) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Warehouse Banner Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Box(modifier = Modifier.fillMaxSize()) {
                        Image(
                            painter = painterResource(id = R.drawable.warehouse_banner_1791022592671),
                            contentDescription = "Warehouse Banner",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(CostcoDeepNavy.copy(alpha = 0.8f))
                        )
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "${activeWh.name} (${activeWh.warehouseId})",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    color = Color.White,
                                    fontWeight = FontWeight.Black
                                )
                            )
                            Text(
                                text = "Capacity: ${activeWh.capacityPercent}% • Staffed Bays: ${activeWh.staffedBays} • Inventory: ${currency}${String.format("%.1fM", activeWh.totalInventory / 1000000.0)}",
                                style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.85f))
                            )
                        }
                    }
                }
            }

            // Visual Pipeline: DOCK → RECEIVING → STORAGE → PICKING → DISPATCH
            item {
                SectionHeader(title = "Physical Warehouse Operations Pipeline")
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val stages = listOf(
                            "DOCK" to "14 Trucks",
                            "RECEIVING" to "${activeWh.inboundShipments} Shipments",
                            "STORAGE" to "${activeWh.capacityPercent}% Full",
                            "PICKING" to "48 Active",
                            "DISPATCH" to "${activeWh.openOrders} Orders"
                        )
                        stages.forEachIndexed { idx, (stage, subtitle) ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = stage,
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = CostcoDeepNavy
                                    )
                                )
                                Text(
                                    text = subtitle,
                                    style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey, fontSize = 10.sp)
                                )
                            }
                            if (idx < stages.size - 1) {
                                Icon(
                                    Icons.Default.ArrowForward,
                                    contentDescription = null,
                                    tint = CostcoBlue,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Inventory Intelligence Table
            item {
                SectionHeader(title = "Inventory Intelligence & Stockout Risk")
            }

            items(inventory) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = item.productName,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = CostcoDeepNavy
                                    )
                                )
                                Text(
                                    text = "SKU: ${item.sku} • Category: ${item.category}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
                                )
                            }
                            StatusBadge(status = item.stockoutRisk)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(BackgroundLight)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("ON HAND", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text("${item.onHand} cases", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                            }
                            Column {
                                Text("ON ORDER", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text("${item.onOrder} cases", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = CostcoBlue))
                            }
                            Column {
                                Text("ALLOCATED", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text("${item.allocated} cases", style = MaterialTheme.typography.bodySmall)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("SAFETY STOCK", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text("${item.safetyStock} cases", style = MaterialTheme.typography.bodySmall)
                            }
                        }

                        if (item.stockoutRisk == "HIGH") {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(CostcoRed.copy(alpha = 0.1f))
                                    .padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "AUTOMATED REORDER RECOMMENDATION",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            fontWeight = FontWeight.Black,
                                            color = CostcoRed
                                        )
                                    )
                                    Text(
                                        text = "Current stock (${item.onHand} cases) < Safety Threshold (${item.safetyStock}). System recommends reordering ${item.eoq} cases.",
                                        style = MaterialTheme.typography.bodySmall.copy(color = WarehouseGrey)
                                    )
                                }
                                Button(
                                    onClick = {
                                        viewModel.createRequisition(
                                            requester = "Inventory Rules Engine",
                                            department = "Warehouse Operations",
                                            warehouseId = activeWh.warehouseId,
                                            warehouseName = activeWh.name,
                                            itemCount = item.eoq,
                                            estimatedValue = item.eoq * 142.50,
                                            priority = "CRITICAL",
                                            summaryItem = "Auto-Reorder ${item.productName} (${item.eoq} cases)"
                                        )
                                        onNavigateToReq("PROCUREMENT")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CostcoRed),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text("Auto-Reorder ${item.eoq}", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
