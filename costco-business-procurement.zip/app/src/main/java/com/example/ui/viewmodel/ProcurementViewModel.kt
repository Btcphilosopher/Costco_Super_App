package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.ProcurementDatabase
import com.example.data.model.*
import com.example.data.repository.ProcurementRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class ProcurementViewModel(application: Application) : AndroidViewModel(application) {

    private val db = ProcurementDatabase.getDatabase(application)
    val repository = ProcurementRepository(db)

    val products: StateFlow<List<ProductEntity>> = repository.allProducts.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val suppliers: StateFlow<List<SupplierEntity>> = repository.allSuppliers.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val contracts: StateFlow<List<ContractEntity>> = repository.allContracts.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val requisitions: StateFlow<List<RequisitionEntity>> = repository.allRequisitions.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val purchaseOrders: StateFlow<List<PurchaseOrderEntity>> = repository.allPurchaseOrders.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val invoices: StateFlow<List<InvoiceEntity>> = repository.allInvoices.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val exceptionInvoices: StateFlow<List<InvoiceEntity>> = repository.exceptionInvoices.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val inventory: StateFlow<List<InventoryEntity>> = repository.getAllInventory().stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val shipments: StateFlow<List<ShipmentEntity>> = repository.allShipments.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val pendingApprovals: StateFlow<List<ApprovalEntity>> = repository.pendingApprovals.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val auditEvents: StateFlow<List<AuditEventEntity>> = repository.auditEvents.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val warehouses: StateFlow<List<WarehouseEntity>> = repository.allWarehouses.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    private val _selectedWarehouse = MutableStateFlow<WarehouseEntity?>(null)
    val selectedWarehouse: StateFlow<WarehouseEntity?> = _selectedWarehouse.asStateFlow()

    private val _selectedOrg = MutableStateFlow("ACME Hospitality Group")
    val selectedOrg: StateFlow<String> = _selectedOrg.asStateFlow()

    private val _selectedCurrency = MutableStateFlow("£")
    val selectedCurrency: StateFlow<String> = _selectedCurrency.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _aiResponse = MutableStateFlow<AiQueryResult?>(null)
    val aiResponse: StateFlow<AiQueryResult?> = _aiResponse.asStateFlow()

    private val _isAiLoading = MutableStateFlow(false)
    val isAiLoading: StateFlow<Boolean> = _isAiLoading.asStateFlow()

    data class AiQueryResult(
        val question: String,
        val answer: String,
        val sourceCategory: String // "DATABASE", "CALCULATION", "FORECAST", "SIMULATION"
    )

    init {
        viewModelScope.launch {
            repository.seedDatabaseIfEmpty()
        }
    }

    fun selectWarehouse(wh: WarehouseEntity) {
        _selectedWarehouse.value = wh
    }

    fun setOrg(org: String) {
        _selectedOrg.value = org
    }

    fun setCurrency(currency: String) {
        _selectedCurrency.value = currency
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun createRequisition(
        requester: String,
        department: String,
        warehouseId: String,
        warehouseName: String,
        itemCount: Int,
        estimatedValue: Double,
        priority: String,
        summaryItem: String
    ) {
        viewModelScope.launch {
            repository.createRequisition(
                requester, department, warehouseId, warehouseName, itemCount, estimatedValue, priority, summaryItem
            )
        }
    }

    fun createPurchaseOrder(
        requisitionId: String,
        supplierId: String,
        supplierName: String,
        contractId: String,
        warehouseId: String,
        warehouseName: String,
        subtotal: Double,
        tax: Double,
        freight: Double,
        itemsSummary: String
    ) {
        viewModelScope.launch {
            repository.createPurchaseOrder(
                requisitionId, supplierId, supplierName, contractId, warehouseId, warehouseName, subtotal, tax, freight, itemsSummary
            )
        }
    }

    fun approveOrReject(approvalId: String, refNumber: String, isApproved: Boolean) {
        viewModelScope.launch {
            repository.updateApprovalStatus(approvalId, refNumber, isApproved, "procurement.manager")
        }
    }

    fun resolveInvoiceException(invoiceId: String, newStatus: String) {
        viewModelScope.launch {
            repository.resolveInvoiceException(invoiceId, newStatus, "finance.controller")
        }
    }

    fun queryAiAssistant(prompt: String) {
        val q = prompt.lowercase().trim()
        _isAiLoading.value = true

        viewModelScope.launch {
            kotlinx.coroutines.delay(600) // Realistic processing delay
            val result = when {
                q.contains("contract") || q.contains("expire") -> AiQueryResult(
                    question = prompt,
                    answer = "Master Contract CT-2027-000491 with Global Packaging & Paper Ltd (£2.5M commitment) expires in 28 days (Nov 30, 2027). Contract SLA is currently at 94.0% on-time delivery. Early renewal draft CT-2028-000491 is recommended to preserve 1.8% rebate tier.",
                    sourceCategory = "DATABASE"
                )
                q.contains("unmatch") || q.contains("invoice") || q.contains("variance") -> AiQueryResult(
                    question = prompt,
                    answer = "There is 1 unmatched invoice exception: INV-2027-009104 from Global Packaging & Paper Ltd for £46,786.00. Variance of +£2,650.00 is due to an unapproved freight surcharge on PO-2027-003310.",
                    sourceCategory = "CALCULATION"
                )
                q.contains("spend") || q.contains("cleaning") || q.contains("food") -> AiQueryResult(
                    question = prompt,
                    answer = "Year-to-date total spend across ACME Hospitality Group is £18,420,000 across 14 warehouses. Food & Beverage represents 61% (£11.23M) with 98.2% contract coverage. Janitorial & Cleaning represents 18% (£3.31M).",
                    sourceCategory = "CALCULATION"
                )
                q.contains("beef") || q.contains("ribeye") || q.contains("price") -> AiQueryResult(
                    question = prompt,
                    answer = "Prime Angus Ribeye Steaks (ENT-FOOD-008912) contract price is £142.50/case vs Spot price of £158.00/case. Purchasing under Contract CT-2027-001842 saves £15.50/case, generating £184,200 annualised savings.",
                    sourceCategory = "DATABASE"
                )
                else -> AiQueryResult(
                    question = prompt,
                    answer = "Procurement System Status: 1,284 Open POs, 37 Pending Approvals, 418 Active Suppliers, 87% Contract Coverage. Savings identified YTD: £1,280,000 under Costco volume tiering.",
                    sourceCategory = "DATABASE"
                )
            }
            _aiResponse.value = result
            _isAiLoading.value = false
        }
    }

    fun clearAiResponse() {
        _aiResponse.value = null
    }
}
