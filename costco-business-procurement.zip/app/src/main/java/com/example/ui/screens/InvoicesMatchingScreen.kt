package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProcurementViewModel

@Composable
fun InvoicesMatchingScreen(viewModel: ProcurementViewModel) {
    val invoices by viewModel.invoices.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "INVOICE CONTROL & 3-WAY MATCHING ENGINE",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
                color = CostcoDeepNavy
            )
        )
        Text(
            text = "Reconcile: Purchase Order × Goods Receipt × Supplier Invoice",
            style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
        )

        Spacer(modifier = Modifier.height(16.dp))

        SectionHeader(title = "Supplier Invoices Ledger (${invoices.size})")

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(invoices) { inv ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${inv.invoiceId} • PO: ${inv.poNumber}",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    color = CostcoDeepNavy
                                )
                            )
                            StatusBadge(status = inv.matchStatus)
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "Supplier: ${inv.supplierName} • Due Date: ${inv.dueDate}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // 3-Way Match Reconciler
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(BackgroundLight)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("PURCHASE ORDER", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text("${currency}${String.format("%.2f", inv.poAmount)}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                            }
                            Column {
                                Text("GOODS RECEIVED", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text("${currency}${String.format("%.2f", inv.goodsReceiptAmount)}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                            }
                            Column {
                                Text("INVOICE AMOUNT", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text("${currency}${String.format("%.2f", inv.invoiceAmount)}", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("VARIANCE", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text(
                                    text = if (inv.variance == 0.0) "${currency}0.00" else "+${currency}${String.format("%.2f", inv.variance)}",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = if (inv.variance == 0.0) SuccessGreen else ExceptionRed
                                    )
                                )
                            }
                        }

                        if (inv.matchStatus == "EXCEPTION") {
                            Spacer(modifier = Modifier.height(10.dp))
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(ExceptionRed.copy(alpha = 0.1f))
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = "3-WAY MATCH EXCEPTION DETECTED",
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = ExceptionRed
                                    )
                                )
                                Text(
                                    text = inv.exceptionReason ?: "Unapproved variance between PO and Supplier Invoice.",
                                    style = MaterialTheme.typography.bodySmall.copy(color = WarehouseGrey)
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(
                                        onClick = { viewModel.resolveInvoiceException(inv.invoiceId, "MATCHED") },
                                        colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Approve Variance", style = MaterialTheme.typography.labelSmall)
                                    }
                                    Button(
                                        onClick = { viewModel.resolveInvoiceException(inv.invoiceId, "REJECTED") },
                                        colors = ButtonDefaults.buttonColors(containerColor = ExceptionRed),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("Reject Invoice", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
