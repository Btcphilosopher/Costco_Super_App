package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProcurementViewModel

@Composable
fun AdminSettingsScreen(viewModel: ProcurementViewModel) {
    val selectedOrg by viewModel.selectedOrg.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()

    var activeHorizon by remember { mutableStateOf("1 MONTH") }
    var simulationResult by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "ADMINISTRATION & PROCUREMENT SIMULATOR",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
                color = CostcoDeepNavy
            )
        )
        Text(
            text = "Enterprise Membership, Approval Threshold Rules & Deterministic Scenario Engine",
            style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
        )

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            // Enterprise Membership Profile
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("ENTERPRISE MEMBERSHIP TIER", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(CostcoDeepNavy)
                                    .padding(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("ENTERPRISE BUSINESS PLUS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Black, color = Color.White))
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(selectedOrg, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = CostcoDeepNavy))
                        Text("Authorized Buyers: 48 • Warehouse Accounts: 14 • Currency: $currency (GBP)", style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey))
                    }
                }
            }

            // Approval Threshold Policy
            item {
                SectionHeader(title = "Configurable Approval Threshold Rules")
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("£0 – £5,000", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = CostcoDeepNavy))
                            Text("Department Manager Approval", style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey))
                        }
                        Divider()
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("£5,000 – £50,000", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = CostcoDeepNavy))
                            Text("Manager + Procurement Director", style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey))
                        }
                        Divider()
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("£50,000+", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = CostcoRed))
                            Text("Procurement + Finance + Executive Board", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = CostcoRed))
                        }
                    }
                }
            }

            // Scenario Simulator
            item {
                SectionHeader(title = "Deterministic Procurement Simulator")
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("SIMULATION HORIZON", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("1 DAY", "1 WEEK", "1 MONTH", "1 YEAR").forEach { horizon ->
                                FilterChip(
                                    selected = activeHorizon == horizon,
                                    onClick = { activeHorizon = horizon },
                                    label = { Text(horizon) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = {
                                simulationResult = when (activeHorizon) {
                                    "1 DAY" -> "Simulated 1-Day Horizon: 42 Inbound Trucks Received, £284K Invoice Processing, 0 Stockout Incidents."
                                    "1 WEEK" -> "Simulated 1-Week Horizon: £1.2M Spend Processed, Supplier On-Time SLA 96.8%, Estimated Volume Rebate +£18,400."
                                    "1 MONTH" -> "Simulated 1-Month Horizon: £4.8M Total Spend, Scenario B (+15% Volume Shift) unlocks Tier 5 Bulk Pricing on 48 SKUs saving £142,000."
                                    else -> "Simulated 1-Year Horizon: £24M Projected Spend, Full Contract Consolidation yields £1.85M Landed Cost Savings."
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CostcoDeepNavy),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("Run Deterministic Simulation ($activeHorizon)")
                        }

                        if (simulationResult != null) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(BackgroundLight)
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = simulationResult!!,
                                    style = MaterialTheme.typography.bodyMedium.copy(color = WarehouseGrey, lineHeight = 20.sp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
