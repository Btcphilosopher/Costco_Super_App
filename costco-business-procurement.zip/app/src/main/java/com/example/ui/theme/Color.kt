package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Costco Business Enterprise Color Palette
val CostcoDeepNavy = Color(0xFF002D62)
val CostcoBlue = Color(0xFF005DAA)
val CostcoRed = Color(0xFFE31837)
val WarehouseGrey = Color(0xFF1E242B)
val SteelGrey = Color(0xFF64748B)
val CardboardTone = Color(0xFFF4EFEA)
val SurfaceLight = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF1F5F9)
val SurfaceVariantLight = Color(0xFFE2E8F0)
val SuccessGreen = Color(0xFF16A34A)
val WarningAmber = Color(0xFFD97706)
val ExceptionRed = Color(0xFFDC2626)

val DarkBackground = Color(0xFF0F172A)
val DarkSurface = Color(0xFF1E293B)
val DarkSurfaceVariant = Color(0xFF334155)
