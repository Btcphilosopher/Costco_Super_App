package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProcurementViewModel

@Composable
fun ContractsScreen(viewModel: ProcurementViewModel) {
    val contracts by viewModel.contracts.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "ENTERPRISE PROCUREMENT CONTRACTS",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
                color = CostcoDeepNavy
            )
        )
        Text(
            text = "Commitments, Volume Tier Schedules, Rebates & Expiration Lifecycle",
            style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
        )

        Spacer(modifier = Modifier.height(16.dp))

        SectionHeader(title = "Master Service & Supply Contracts")

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(contracts) { ct ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = ct.contractId,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = CostcoDeepNavy
                                    )
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                if (ct.daysUntilExpiry <= 30) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(CostcoRed.copy(alpha = 0.15f))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = "EXPIRES IN ${ct.daysUntilExpiry} DAYS",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                fontWeight = FontWeight.Black,
                                                color = CostcoRed
                                            )
                                        )
                                    }
                                }
                            }
                            StatusBadge(status = ct.status)
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = ct.title,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )

                        Text(
                            text = "Supplier: ${ct.supplierName} • Validity: ${ct.validFrom} to ${ct.validTo}",
                            style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Spend Utilization Progress
                        val progress = (ct.currentSpend / ct.annualCommitment).toFloat().coerceIn(0f, 1f)
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("ANNUAL COMMITMENT UTILIZATION", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text(
                                    text = "${currency}${String.format("%.2fM", ct.currentSpend / 1000000.0)} / ${currency}${String.format("%.2fM", ct.annualCommitment / 1000000.0)} (${(progress * 100).toInt()}%)",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = CostcoDeepNavy)
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp)),
                                color = if (progress >= 0.8f) SuccessGreen else CostcoBlue,
                                trackColor = BackgroundLight
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Rebate Rate: ${ct.rebateRatePct}%", style = MaterialTheme.typography.bodySmall.copy(color = CostcoBlue, fontWeight = FontWeight.Bold))
                            Text("SLA Target: ${ct.slaOnTimePct}% On-Time", style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey))
                        }
                    }
                }
            }
        }
    }
}
