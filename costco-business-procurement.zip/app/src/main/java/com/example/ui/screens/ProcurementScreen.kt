package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProcurementViewModel

@Composable
fun ProcurementScreen(
    viewModel: ProcurementViewModel,
    onNavigateToPO: (String) -> Unit
) {
    val requisitions by viewModel.requisitions.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }

    var requesterName by remember { mutableStateOf("Sarah Williams") }
    var department by remember { mutableStateOf("Kitchen & Food Operations") }
    var summaryItem by remember { mutableStateOf("Kirkland Olive Oil & Paper Towels") }
    var itemCountText by remember { mutableStateOf("500") }
    var estimatedValText by remember { mutableStateOf("26400") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "PURCHASE REQUISITIONS & SOURCING",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        letterSpacing = 0.5.sp,
                        color = CostcoDeepNavy
                    )
                )
                Text(
                    text = "Request → Source → Compare → Approve → Order Workflow",
                    style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
                )
            }

            Button(
                onClick = { showCreateDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = CostcoDeepNavy),
                shape = RoundedCornerShape(6.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "New Requisition")
                Spacer(modifier = Modifier.width(4.dp))
                Text("New Requisition", style = MaterialTheme.typography.labelSmall)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        SectionHeader(title = "Active Requisitions Queue")

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(requisitions) { req ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = req.requisitionId,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Black,
                                    color = CostcoDeepNavy
                                )
                            )
                            StatusBadge(status = req.status)
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = req.summaryItem,
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )

                        Text(
                            text = "Requester: ${req.requester} • Dept: ${req.department} • Location: ${req.warehouseName}",
                            style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Est. Value: ${currency}${String.format("%.2f", req.estimatedValue)} (${req.itemCount} cases)",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = CostcoBlue
                                )
                            )

                            if (req.status == "APPROVED" || req.status == "PENDING_APPROVAL") {
                                Button(
                                    onClick = {
                                        viewModel.createPurchaseOrder(
                                            requisitionId = req.requisitionId,
                                            supplierId = "SUP-004821",
                                            supplierName = "Northstar Foods Ltd",
                                            contractId = "CT-2027-001842",
                                            warehouseId = req.warehouseId,
                                            warehouseName = req.warehouseName,
                                            subtotal = req.estimatedValue * 0.8,
                                            tax = req.estimatedValue * 0.16,
                                            freight = req.estimatedValue * 0.04,
                                            itemsSummary = req.summaryItem
                                        )
                                        onNavigateToPO("PURCHASE_ORDERS")
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = CostcoBlue),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text("Issue PO", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Create Purchase Requisition", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = CostcoDeepNavy)) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = requesterName,
                        onValueChange = { requesterName = it },
                        label = { Text("Requester Name") }
                    )
                    OutlinedTextField(
                        value = department,
                        onValueChange = { department = it },
                        label = { Text("Department") }
                    )
                    OutlinedTextField(
                        value = summaryItem,
                        onValueChange = { summaryItem = it },
                        label = { Text("Items Description") }
                    )
                    OutlinedTextField(
                        value = itemCountText,
                        onValueChange = { itemCountText = it },
                        label = { Text("Estimated Case Quantity") }
                    )
                    OutlinedTextField(
                        value = estimatedValText,
                        onValueChange = { estimatedValText = it },
                        label = { Text("Estimated Value (£)") }
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val cases = itemCountText.toIntOrNull() ?: 100
                        val valDouble = estimatedValText.toDoubleOrNull() ?: 5000.0
                        viewModel.createRequisition(
                            requester = requesterName,
                            department = department,
                            warehouseId = "WH-LDN-01",
                            warehouseName = "London Heathrow Hub 104",
                            itemCount = cases,
                            estimatedValue = valDouble,
                            priority = "NORMAL",
                            summaryItem = summaryItem
                        )
                        showCreateDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CostcoDeepNavy)
                ) {
                    Text("Submit Requisition")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }
}
