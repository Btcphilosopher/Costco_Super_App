package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ApprovalEntity
import com.example.ui.components.SectionHeader
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProcurementViewModel

@Composable
fun ApprovalsScreen(viewModel: ProcurementViewModel) {
    val pendingApprovals by viewModel.pendingApprovals.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()

    var selectedApprovalForConfirm by remember { mutableStateOf<ApprovalEntity?>(null) }
    var actionToConfirm by remember { mutableStateOf<Boolean?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        // Mobile Approval Headline
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(CostcoRed)
                .padding(16.dp)
        ) {
            Column {
                Text(
                    text = "${pendingApprovals.size + 35} APPROVALS REQUIRE YOUR ATTENTION",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                )
                Text(
                    text = "Executive & Manager Approval Chain • Multi-Threshold Policy Active",
                    style = MaterialTheme.typography.bodySmall.copy(color = Color.White.copy(alpha = 0.85f))
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        SectionHeader(title = "Pending Approvals Queue (${pendingApprovals.size})")

        if (pendingApprovals.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(BackgroundLight),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No pending approvals in queue. All requisitions & POs approved.",
                    style = MaterialTheme.typography.bodyMedium.copy(color = SteelGrey)
                )
            }
        } else {
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(pendingApprovals) { app ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${app.refNumber} (${app.type})",
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Black,
                                        color = CostcoDeepNavy
                                    )
                                )
                                Text(
                                    text = "${currency}${String.format("%.2f", app.amount)}",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        color = CostcoRed
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = app.title,
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )

                            Text(
                                text = "Requested By: ${app.requestedBy} • Dept: ${app.department} • Location: ${app.warehouse}",
                                style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Button(
                                    onClick = {
                                        selectedApprovalForConfirm = app
                                        actionToConfirm = true
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = SuccessGreen),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Approve", style = MaterialTheme.typography.labelSmall)
                                }

                                Button(
                                    onClick = {
                                        selectedApprovalForConfirm = app
                                        actionToConfirm = false
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ExceptionRed),
                                    shape = RoundedCornerShape(4.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reject", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (selectedApprovalForConfirm != null && actionToConfirm != null) {
        val app = selectedApprovalForConfirm!!
        val isApprove = actionToConfirm!!

        AlertDialog(
            onDismissRequest = {
                selectedApprovalForConfirm = null
                actionToConfirm = null
            },
            title = {
                Text(
                    text = if (isApprove) "Confirm Approval" else "Confirm Rejection",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Black,
                        color = if (isApprove) SuccessGreen else ExceptionRed
                    )
                )
            },
            text = {
                Text(
                    text = "Are you sure you want to ${if (isApprove) "approve" else "reject"} ${app.refNumber} for ${currency}${String.format("%.2f", app.amount)}?",
                    style = MaterialTheme.typography.bodyMedium
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.approveOrReject(app.approvalId, app.refNumber, isApprove)
                        selectedApprovalForConfirm = null
                        actionToConfirm = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isApprove) SuccessGreen else ExceptionRed
                    )
                ) {
                    Text(if (isApprove) "Yes, Approve" else "Yes, Reject")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    selectedApprovalForConfirm = null
                    actionToConfirm = null
                }) {
                    Text("Cancel")
                }
            }
        )
    }
}
