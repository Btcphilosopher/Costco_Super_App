package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*
import com.example.ui.viewmodel.ProcurementViewModel

@Composable
fun SuppliersScreen(viewModel: ProcurementViewModel) {
    val suppliers by viewModel.suppliers.collectAsState()
    val currency by viewModel.selectedCurrency.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "SUPPLIER MANAGEMENT & PERFORMANCE SCORECARDS",
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp,
                color = CostcoDeepNavy
            )
        )
        Text(
            text = "Objective Operational Performance SLA & Risk Monitoring",
            style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
        )

        Spacer(modifier = Modifier.height(16.dp))

        SectionHeader(title = "Qualified Supplier Registry (${suppliers.size})")

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(suppliers) { sup ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = sup.name,
                                    style = MaterialTheme.typography.titleSmall.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = CostcoDeepNavy
                                    )
                                )
                                Text(
                                    text = "${sup.legalName} • ID: ${sup.supplierId}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
                                )
                            }
                            StatusBadge(status = sup.status)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Scorecard Metrics Row
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(BackgroundLight)
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("ON-TIME SLA", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text(
                                    text = "${sup.onTimeDeliveryRate}%",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        color = if (sup.onTimeDeliveryRate >= 95.0) SuccessGreen else WarningAmber
                                    )
                                )
                            }

                            Column {
                                Text("FILL RATE", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text(
                                    text = "${sup.fillRate}%",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        color = CostcoBlue
                                    )
                                )
                            }

                            Column {
                                Text("RISK SCORE", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text(
                                    text = "${sup.riskScore}/100",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        color = if (sup.riskScore >= 90) SuccessGreen else CostcoDeepNavy
                                    )
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text("SPEND YTD", style = MaterialTheme.typography.labelSmall.copy(color = SteelGrey))
                                Text(
                                    text = "${currency}${String.format("%.1fM", sup.spendYtd / 1000000.0)}",
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontWeight = FontWeight.Black,
                                        color = CostcoDeepNavy
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "Categories: ${sup.categories} • Payment Terms: ${sup.paymentTerms} • Open POs: ${sup.openPOsCount}",
                            style = MaterialTheme.typography.bodySmall.copy(color = SteelGrey)
                        )
                    }
                }
            }
        }
    }
}
